import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import { RealtimeEvent, RealtimeEventType, RealtimeEventPayloads } from '../types';
import { useAuth } from './AuthContext';

type EventListener<T extends RealtimeEventType = RealtimeEventType> = (
  event: RealtimeEvent<T>
) => void;

interface RealtimeContextType {
  isConnected: boolean;
  isReconnecting: boolean;
  connectionStatus: 'connected' | 'reconnecting' | 'disconnected';
  lastSyncTime: Date | null;
  latestActivity: string | null;
  subscribe: <T extends RealtimeEventType>(type: T, listener: EventListener<T>) => () => void;
  reconnectNow: () => void;
}

const RealtimeContext = createContext<RealtimeContextType | undefined>(undefined);

export const RealtimeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'reconnecting' | 'disconnected'>('disconnected');
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  const [latestActivity, setLatestActivity] = useState<string | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const listenersRef = useRef<Map<RealtimeEventType, Set<EventListener<any>>>>(new Map());
  const isManuallyClosedRef = useRef(false);

  const notifyListeners = useCallback((event: RealtimeEvent<any>) => {
    const listeners = listenersRef.current.get(event.type);
    if (listeners) {
      listeners.forEach((listener) => {
        try {
          listener(event);
        } catch (err) {
          console.error(`Error in realtime listener for ${event.type}:`, err);
        }
      });
    }

    // Update human-readable activity log
    if (event.type === 'LOAN_CREATED') {
      const data = event.data as RealtimeEventPayloads['LOAN_CREATED'];
      setLatestActivity(`Yangi ijara: "${data.book.title}" (${data.loan.memberName})`);
    } else if (event.type === 'LOAN_RETURNED') {
      const data = event.data as RealtimeEventPayloads['LOAN_RETURNED'];
      setLatestActivity(`Kitob qaytarildi: "${data.book.title}"`);
    } else if (event.type === 'BOOK_CREATED') {
      const data = event.data as RealtimeEventPayloads['BOOK_CREATED'];
      setLatestActivity(`Yangi kitob qo'shildi: "${data.book.title}"`);
    } else if (event.type === 'BOOK_UPDATED') {
      const data = event.data as RealtimeEventPayloads['BOOK_UPDATED'];
      setLatestActivity(`Nusxalar yangilandi: "${data.book.title}" (${data.book.availableCopies} ta)`);
    } else if (event.type === 'BOOK_DELETED') {
      setLatestActivity(`Kitob o'chirildi`);
    } else if (event.type === 'MEMBER_CREATED') {
      const data = event.data as RealtimeEventPayloads['MEMBER_CREATED'];
      setLatestActivity(`Yangi a'zo qo'shildi: ${data.member.name}`);
    }
  }, []);

  const connect = useCallback(() => {
    if (wsRef.current && (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)) {
      return;
    }

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        setIsReconnecting(false);
        setConnectionStatus('connected');
        setLastSyncTime(new Date());

        // Send identity if user logged in
        if (user) {
          ws.send(
            JSON.stringify({
              type: 'IDENTIFY',
              userId: user.id,
              libraryId: user.libraryId,
            })
          );
        }
      };

      ws.onmessage = (msgEvent) => {
        try {
          const parsed: RealtimeEvent<any> = JSON.parse(msgEvent.data);
          if (parsed && parsed.type) {
            setLastSyncTime(new Date());
            notifyListeners(parsed);
          }
        } catch (err) {
          console.warn('[Realtime] Failed to parse message:', err);
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        if (!isManuallyClosedRef.current) {
          setIsReconnecting(true);
          setConnectionStatus('reconnecting');
          // Reconnect with backoff
          if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = setTimeout(() => {
            connect();
          }, 2500);
        } else {
          setConnectionStatus('disconnected');
        }
      };

      ws.onerror = (err) => {
        console.warn('[Realtime] WebSocket error:', err);
        ws.close();
      };
    } catch (err) {
      console.error('[Realtime] Connection initialization failed:', err);
      setIsConnected(false);
      setIsReconnecting(true);
      setConnectionStatus('reconnecting');
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 3000);
    }
  }, [notifyListeners, user]);

  const reconnectNow = useCallback(() => {
    if (wsRef.current) {
      wsRef.current.close();
    }
    connect();
  }, [connect]);

  // Subscribe to specific event
  const subscribe = useCallback(<T extends RealtimeEventType>(type: T, listener: EventListener<T>) => {
    if (!listenersRef.current.has(type)) {
      listenersRef.current.set(type, new Set());
    }
    listenersRef.current.get(type)!.add(listener);

    return () => {
      const set = listenersRef.current.get(type);
      if (set) {
        set.delete(listener);
      }
    };
  }, []);

  useEffect(() => {
    isManuallyClosedRef.current = false;
    connect();

    return () => {
      isManuallyClosedRef.current = true;
      if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  // Update identification on user change
  useEffect(() => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && user) {
      wsRef.current.send(
        JSON.stringify({
          type: 'IDENTIFY',
          userId: user.id,
          libraryId: user.libraryId,
        })
      );
    }
  }, [user]);

  return (
    <RealtimeContext.Provider
      value={{
        isConnected,
        isReconnecting,
        connectionStatus,
        lastSyncTime,
        latestActivity,
        subscribe,
        reconnectNow,
      }}
    >
      {children}
    </RealtimeContext.Provider>
  );
};

export const useRealtime = () => {
  const context = useContext(RealtimeContext);
  if (!context) {
    throw new Error('useRealtime must be used within a RealtimeProvider');
  }
  return context;
};
