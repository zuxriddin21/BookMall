import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, DbLibrary } from '../types';
import { api } from '../services/api';
import { initialUsers, initialLibraries } from '../../server/db';

interface AuthContextType {
  currentUser: User;
  allUsers: User[];
  activeLibrary: DbLibrary;
  allLibraries: DbLibrary[];
  activeAppView: 'admin' | 'member';
  setActiveAppView: (view: 'admin' | 'member') => void;
  showAccessDeniedModal: boolean;
  setShowAccessDeniedModal: (show: boolean) => void;
  switchUser: (userId: string) => Promise<void>;
  updateCurrentUser: (userData: Partial<User>) => void;
  updateCurrentLibrary: (library: DbLibrary) => void;
  isLibraryAdmin: boolean;
  token: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [allUsers, setAllUsers] = useState<User[]>(initialUsers);
  const [allLibraries, setAllLibraries] = useState<DbLibrary[]>(initialLibraries);
  
  // Default to Navoiy Library Admin
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const savedUserId = localStorage.getItem('bookmall_user_id');
    if (savedUserId) {
      const found = initialUsers.find((u) => u.id === savedUserId);
      if (found) return found;
    }
    return initialUsers[0]; // Admin by default
  });

  const [activeLibrary, setActiveLibrary] = useState<DbLibrary>(() => {
    const lib = initialLibraries.find((l) => l.id === currentUser.libraryId) || initialLibraries[0];
    return lib;
  });

  // App View Mode:
  // If role is LIBRARY_ADMIN -> starts in 'admin' mode
  // If role is MEMBER -> strictly 'member' mode
  const [activeAppView, setActiveAppViewInternal] = useState<'admin' | 'member'>(() => {
    return currentUser.role === 'LIBRARY_ADMIN' ? 'admin' : 'member';
  });

  const [showAccessDeniedModal, setShowAccessDeniedModal] = useState(false);

  // Sync token in localStorage
  useEffect(() => {
    if (currentUser.token) {
      localStorage.setItem('bookmall_auth_token', currentUser.token);
      localStorage.setItem('bookmall_user_id', currentUser.id);
    }
    // Update matching library
    const matchedLib = allLibraries.find((l) => l.id === currentUser.libraryId) || allLibraries[0];
    setActiveLibrary(matchedLib);
  }, [currentUser, allLibraries]);

  // Load backend users and libraries on mount
  useEffect(() => {
    api.auth.getUsers().then(setAllUsers).catch(() => {});
    api.libraries.getAll().then((libs) => {
      setAllLibraries(libs);
      const matched = libs.find((l) => l.id === currentUser.libraryId);
      if (matched) setActiveLibrary(matched);
    }).catch(() => {});
  }, []);

  // Safe setActiveAppView that enforces RBAC on frontend
  const setActiveAppView = (view: 'admin' | 'member') => {
    if (view === 'admin' && currentUser.role !== 'LIBRARY_ADMIN') {
      // MEMBER cannot open admin panel!
      setShowAccessDeniedModal(true);
      setActiveAppViewInternal('member');
      return;
    }
    setActiveAppViewInternal(view);
  };

  const switchUser = async (userId: string) => {
    try {
      const res = await api.auth.login(userId);
      setCurrentUser(res.user);
      const matchedLib = allLibraries.find((l) => l.id === res.user.libraryId) || allLibraries[0];
      setActiveLibrary(matchedLib);

      if (res.user.role === 'LIBRARY_ADMIN') {
        setActiveAppViewInternal('admin');
      } else {
        setActiveAppViewInternal('member');
      }
    } catch (err) {
      const targetUser = allUsers.find((u) => u.id === userId);
      if (targetUser) {
        setCurrentUser(targetUser);
        if (targetUser.role === 'LIBRARY_ADMIN') {
          setActiveAppViewInternal('admin');
        } else {
          setActiveAppViewInternal('member');
        }
      }
    }
  };

  const updateCurrentUser = (userData: Partial<User>) => {
    setCurrentUser((prev) => ({ ...prev, ...userData }));
    setAllUsers((prev) => prev.map((u) => (u.id === currentUser.id ? { ...u, ...userData } : u)));
  };

  const updateCurrentLibrary = (lib: DbLibrary) => {
    setActiveLibrary(lib);
    setAllLibraries((prev) => prev.map((item) => (item.id === lib.id ? lib : item)));
  };

  const isLibraryAdmin = currentUser.role === 'LIBRARY_ADMIN';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        allUsers,
        activeLibrary,
        allLibraries,
        activeAppView,
        setActiveAppView,
        showAccessDeniedModal,
        setShowAccessDeniedModal,
        switchUser,
        updateCurrentUser,
        updateCurrentLibrary,
        isLibraryAdmin,
        token: currentUser.token || '',
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
