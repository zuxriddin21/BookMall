export interface Book {
  id: string;
  title: string;
  author: string;
  rating: string | number;
  sold?: string;
  reads?: number;
  borrowCount?: number;
  cover: string;
  light?: boolean;
  available: boolean;
  genre?: string;
  category?: string;
  description?: string;
  pages?: number;
  year?: number | string;
  language?: string;
  isbn?: string;
  sampleText?: string;
  audioSample?: string;
}

export interface StoreItem {
  id: string;
  name: string;
  ring: string;
  bg: string;
  label?: string;
  sub?: string;
  labelColor?: string;
  italic?: boolean;
  icon?: 'triangle' | 'landmark' | 'store';
  description?: string;
  location?: string;
  website?: string;
}

export interface LibraryItem {
  id: string;
  name: string;
  totalLiterature: number;
  enteredBooks: number;
  gradient: string;
  accentText: string;
  accentText2: string;
  membersCount: number;
  address: string;
  phone: string;
  workingHours: string;
  isAvailable?: boolean;
  statusLabel?: string;
  type?: 'public' | 'university';
}

export interface DonationCampaign {
  id: string;
  library: string;
  bookTitle: string;
  author?: string;
  cover?: string;
  copiesNeeded: number;
  raised: number;
  goal: number;
  supportersCount: number;
}

export interface BorrowedItem {
  id: string;
  title: string;
  author: string;
  borrowedDate: string;
  dueDate: string;
  cover: string;
  light?: boolean;
  libraryName: string;
  status: 'active' | 'overdue' | 'returned';
}

export interface WaitingItem {
  id: string;
  title: string;
  author: string;
  requestedDate: string;
  cover: string;
  light?: boolean;
  queuePosition: number;
  libraryName: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'borrow' | 'donation' | 'library' | 'system';
}

export interface UserReview {
  id: string;
  bookTitle: string;
  userName: string;
  userAvatar: string;
  rating: number;
  comment: string;
  date: string;
}

// RBAC & System Models specified in user requirements
export type UserRole = 'LIBRARY_ADMIN' | 'MEMBER';

export interface User {
  id: string;
  name: string;
  username?: string;
  email: string;
  role: UserRole;
  libraryId: string;
  phone?: string;
  avatar?: string;
  bio?: string;
  token?: string;
  createdAt: string;
  isPremium?: boolean;
  subscriptionPlan?: 'FREE' | 'PREMIUM' | 'VIP';
}

export interface UserFollow {
  id: string;
  followerId: string;
  followingUserId: string;
  createdAt: string;
}

export interface LibraryFollow {
  id: string;
  followerId: string;
  followingLibraryId: string;
  createdAt: string;
}

export interface PublisherFollow {
  id: string;
  followerId: string;
  followingPublisherId: string;
  createdAt: string;
}

export interface DbPublisher {
  id: string;
  name: string;
  logo: string;
  description: string;
  booksCount: number;
  location: string;
  website?: string;
}

export interface ReadBook {
  id: string;
  userId: string;
  bookId: string;
  readAt: string;
  rating: number;
  reviewId?: string;
  notes?: string;
  isPinned?: boolean;
  pinnedOrder?: number;
  pinnedAt?: string;
}

export interface ProfileReadBookItem {
  id: string;
  bookId: string;
  title: string;
  author: string;
  coverImage: string;
  genre: string;
  description?: string;
  readAt: string;
  rating: number;
  libraryName?: string;
  publisher?: string;
  notes?: string;
  isPinned?: boolean;
  pinnedOrder?: number;
  pinnedAt?: string;
}

export interface ProfileStats {
  followersCount: number;
  followingCount: number;
  booksReadCount: number;
  activeLoansCount: number;
  savedBooksCount: number;
}

export interface FollowingItem {
  id: string;
  type: 'LIBRARY' | 'BLOGGER' | 'PUBLISHER';
  name: string;
  username?: string;
  avatarOrLogo: string;
  description: string;
  isFollowing: boolean;
  extraMeta?: string;
}

export interface UserProfileResponse {
  user: User;
  stats: ProfileStats;
  followings: {
    libraries: FollowingItem[];
    bloggers: FollowingItem[];
    publishers: FollowingItem[];
  };
  readBooks: {
    items: ProfileReadBookItem[];
    total: number;
    page: number;
    limit: number;
    hasMore: boolean;
  };
}

export interface DbLibrary {
  id: string;
  name: string;
  logo?: string;
  address: string;
  phone: string;
  workingHours: string;
  description: string;
  membersCount?: number;
  totalLiterature?: number;
}

export interface DbBook {
  id: string;
  libraryId: string;
  title: string;
  author: string;
  genre: string;
  isbn: string;
  publisher: string;
  publishedYear: number | string;
  description: string;
  coverImage: string;
  totalCopies: number;
  availableCopies: number;
  createdAt: string;
  updatedAt: string;
}

export type LoanStatus = 'ACTIVE' | 'RETURNED' | 'OVERDUE';

export interface DbLoan {
  id: string;
  bookId: string;
  bookTitle: string;
  bookAuthor?: string;
  bookCover?: string;
  memberId: string;
  memberName: string;
  memberEmail?: string;
  memberPhone?: string;
  libraryId: string;
  borrowedAt: string;
  dueDate: string;
  returnedAt?: string | null;
  status: LoanStatus;
}

export interface DbMember {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  libraryId: string;
  activeLoansCount: number;
  overdueLoansCount: number;
  totalBorrowedCount: number;
  registeredDate: string;
}

export interface DbSavedBook {
  id: string;
  userId: string;
  bookId: string;
  createdAt: string;
}

export interface LibraryStats {
  totalBooks: number;
  availableBooks: number;
  borrowedBooks: number;
  totalMembers: number;
  overdueBooks: number;
  recentBooks: DbBook[];
  recentLoans: DbLoan[];
  genreDistribution: { genre: string; count: number }[];
}

// Real-time Event Types & Payloads
export type RealtimeEventType =
  | 'CONNECTED'
  | 'BOOK_CREATED'
  | 'BOOK_UPDATED'
  | 'BOOK_DELETED'
  | 'LOAN_CREATED'
  | 'LOAN_RETURNED'
  | 'MEMBER_CREATED'
  | 'STATS_UPDATED'
  | 'NOTIFICATION_CREATED'
  | 'FOLLOW_UPDATED'
  | 'PROFILE_UPDATED'
  | 'PING'
  | 'PONG';

export interface RealtimeEventPayloads {
  CONNECTED: { clientId: string; timestamp: string };
  BOOK_CREATED: { book: DbBook; libraryId: string; stats?: LibraryStats };
  BOOK_UPDATED: { book: DbBook; libraryId: string; stats?: LibraryStats };
  BOOK_DELETED: { bookId: string; libraryId: string; stats?: LibraryStats };
  LOAN_CREATED: { loan: DbLoan; book: DbBook; libraryId: string; memberId: string; stats?: LibraryStats };
  LOAN_RETURNED: { loan: DbLoan; book: DbBook; libraryId: string; memberId: string; stats?: LibraryStats };
  MEMBER_CREATED: { member: DbMember; libraryId: string; stats?: LibraryStats };
  STATS_UPDATED: { libraryId: string; stats: LibraryStats };
  NOTIFICATION_CREATED: { memberId: string; notification: NotificationItem };
  FOLLOW_UPDATED: { followerId: string; targetId: string; targetType: 'USER' | 'LIBRARY' | 'PUBLISHER'; isFollowing: boolean };
  PROFILE_UPDATED: { userId: string; user: User };
  PING: { timestamp: number };
  PONG: { timestamp: number };
}

export type RealtimeEvent<T extends RealtimeEventType = RealtimeEventType> = {
  type: T;
  data: RealtimeEventPayloads[T];
  timestamp: string;
};
