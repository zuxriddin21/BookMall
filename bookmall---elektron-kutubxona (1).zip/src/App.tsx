import React, { useState, useEffect } from 'react';
import {
  Home,
  Search,
  Bookmark,
  User,
  Bell,
  Landmark,
  HandCoins,
  BookOpen,
  Sparkles,
  Smartphone,
  Monitor,
  CheckCircle2,
  Share2,
  Settings
} from 'lucide-react';
import { Book, StoreItem, LibraryItem, DonationCampaign, BorrowedItem, WaitingItem, NotificationItem } from './types';
import {
  LIBRARIES_DATA,
  INITIAL_DONATION_CAMPAIGN,
  INITIAL_BORROWED_BOOKS,
  INITIAL_WAITING_BOOKS,
  INITIAL_NOTIFICATIONS,
  ALL_BOOKS_DATABASE,
  BOOKMALL_LOGO,
} from './data/bookData';

import { HomeScreen } from './components/HomeScreen';
import { SearchScreen } from './components/SearchScreen';
import { SavedScreen } from './components/SavedScreen';
import { ProfileScreen } from './components/ProfileScreen';

import { BookDetailModal } from './components/BookDetailModal';
import { BookReaderModal } from './components/BookReaderModal';
import { AudioPlayerModal } from './components/AudioPlayerModal';
import { BorrowModal } from './components/BorrowModal';
import { DonationModal } from './components/DonationModal';
import { StoreDetailModal } from './components/StoreDetailModal';
import { LibraryInfoModal } from './components/LibraryInfoModal';
import { LibrarySwitcherModal } from './components/LibrarySwitcherModal';
import { EnteredBooksListModal } from './components/EnteredBooksListModal';
import { NotificationsModal } from './components/NotificationsModal';
import { FilterModal } from './components/FilterModal';
import { WelcomeSplashScreen } from './components/WelcomeSplashScreen';
import { BookMallIntroSequence } from './components/BookMallIntroSequence';
import { SettingsModal } from './components/SettingsModal';

import { AuthProvider, useAuth } from './context/AuthContext';
import { RealtimeProvider } from './context/RealtimeContext';
import { RoleSwitcherBanner } from './components/RoleSwitcherBanner';
import { LibraryAdminLayout } from './components/admin/LibraryAdminLayout';
import { AccessDeniedModal } from './components/admin/AccessDeniedModal';

function MainAppContent() {
  const { activeAppView, isLibraryAdmin } = useAuth();

  // Intro Sequence state (3-frame animation)
  const [showIntroSequence, setShowIntroSequence] = useState(false);

  // Welcome Splash Screen state
  const [showWelcomeSplash, setShowWelcomeSplash] = useState(false);

  // Navigation & Screen state
  const [activeTab, setActiveTab] = useState<'home' | 'search' | 'saved' | 'profile'>('home');
  const [searchInitialQuery, setSearchInitialQuery] = useState('');

  // Active Data state
  const [libraries, setLibraries] = useState<LibraryItem[]>(LIBRARIES_DATA);
  const [activeLibrary, setActiveLibrary] = useState<LibraryItem>(LIBRARIES_DATA[0]);
  const [donationCampaign, setDonationCampaign] = useState<DonationCampaign>(INITIAL_DONATION_CAMPAIGN);
  const [borrowedBooks, setBorrowedBooks] = useState<BorrowedItem[]>(INITIAL_BORROWED_BOOKS);
  const [waitingBooks, setWaitingBooks] = useState<WaitingItem[]>(INITIAL_WAITING_BOOKS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [savedBookIds, setSavedBookIds] = useState<string[]>(['b-1', 'jk-1', 'best-1', 'uz-1']);

  // Modals state
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [selectedStore, setSelectedStore] = useState<StoreItem | null>(null);
  const [readerBook, setReaderBook] = useState<Book | null>(null);
  const [audioBook, setAudioBook] = useState<Book | null>(null);
  const [borrowBook, setBorrowBook] = useState<Book | null>(null);

  const [showDonationModal, setShowDonationModal] = useState(false);
  const [showLibraryInfoModal, setShowLibraryInfoModal] = useState<LibraryItem | null>(null);
  const [showLibrarySwitcherModal, setShowLibrarySwitcherModal] = useState(false);
  const [showEnteredBooksModal, setShowEnteredBooksModal] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Search Filters
  const [filterGenre, setFilterGenre] = useState<string>('all');
  const [filterAvailability, setFilterAvailability] = useState<'all' | 'available' | 'borrowed'>('all');
  const [sortBy, setSortBy] = useState<'popular' | 'rating' | 'newest' | 'alphabetical'>('popular');

  // Toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Toggle Save Book
  const handleToggleSave = (book: Book) => {
    if (savedBookIds.includes(book.id)) {
      setSavedBookIds(savedBookIds.filter((id) => id !== book.id));
      showToast(`"${book.title}" saqlanganlardan chiqarildi`);
    } else {
      setSavedBookIds([...savedBookIds, book.id]);
      showToast(`"${book.title}" saqlanganlarga qo'shildi`);
    }
  };

  // Borrow Success Handler
  const handleBorrowSuccess = (book: Book, durationDays: number, selectedLib: string) => {
    const returnDate = new Date();
    returnDate.setDate(returnDate.getDate() + durationDays);
    const dateFormatted = `${returnDate.getDate()}/${returnDate.getMonth() + 1}`;

    const newBorrowItem: BorrowedItem = {
      id: `borr-${Date.now()}`,
      title: book.title,
      author: book.author,
      borrowedDate: 'Bugun',
      dueDate: dateFormatted,
      cover: book.cover,
      light: book.light,
      libraryName: selectedLib,
      status: 'active',
    };

    setBorrowedBooks([newBorrowItem, ...borrowedBooks]);

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Kitob band qilindi',
      message: `"${book.title}" kitobini ${selectedLib}dan olib ketishingiz mumkin. Qaytarish: ${dateFormatted}`,
      time: 'Hozirgina',
      read: false,
      type: 'borrow',
    };
    setNotifications([newNotif, ...notifications]);

    showToast(`"${book.title}" muvaffaqiyatli band qilindi!`);
  };

  // Donation Success Handler
  const handleDonationSuccess = (amount: number) => {
    setDonationCampaign((prev) => ({
      ...prev,
      raised: prev.raised + amount,
      supportersCount: prev.supportersCount + 1,
    }));

    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title: 'Donatsiya uchun tashakkur!',
      message: `Sizning ${amount.toLocaleString()} so'mlik ehsoningiz yangi kitoblar fondiga yo'naltirildi.`,
      time: 'Hozirgina',
      read: false,
      type: 'donation',
    };
    setNotifications([newNotif, ...notifications]);
    showToast(`Ehsoningiz qabul qilindi. Tashakkur!`);
  };

  // Search shortcut
  const handleNavigateToSearch = (query?: string) => {
    if (query) setSearchInitialQuery(query);
    setActiveTab('search');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const unreadNotifsCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-[#F5F2EB] text-[#3D3B35] flex flex-col selection:bg-[#5A5A40] selection:text-white">
      {/* Toast popup */}
      {toastMessage && (
        <div className="fixed top-4 z-50 left-1/2 -translate-x-1/2 bg-[#2D2C27] text-[#FAF8F3] text-xs font-semibold px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-2 border border-[#48463E] animate-in fade-in slide-in-from-top-4 duration-300">
          <CheckCircle2 className="w-4 h-4 text-[#7BB38E]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Global RBAC Role & View Switcher Bar */}
      <RoleSwitcherBanner />

      {/* Access Denied Modal (403 Forbidden alert) */}
      <AccessDeniedModal />

      {/* Conditional Rendering based on RBAC View Mode */}
      {activeAppView === 'admin' && isLibraryAdmin ? (
        <LibraryAdminLayout showToast={showToast} />
      ) : (
        <div className="flex-1 flex justify-center">
          {/* Main Member Container */}
          <div className="w-full max-w-md sm:max-w-lg md:max-w-xl min-h-screen bg-[#FDFCF9] shadow-xl flex flex-col relative border-x border-[#E6E1D6]">
            {/* Top App Bar with Centered BookMall Branding */}
            <header className="sticky top-0 z-30 bg-[#FDFCF9]/95 backdrop-blur-md px-4 sm:px-5 py-2.5 border-b border-[#ECE7DC] relative flex items-center justify-between h-14">
              {/* Left: Settings Button */}
              <button
                id="header-settings-btn"
                onClick={() => setShowSettingsModal(true)}
                className="p-2 rounded-full text-[#5A5850] hover:text-[#2C5338] hover:bg-[#F2EFE8] transition-colors cursor-pointer flex items-center justify-center group"
                title="Sozlamalar"
                aria-label="Sozlamalar"
              >
                <Settings className="w-5 h-5 group-hover:rotate-45 transition-transform duration-300" />
              </button>

              {/* Center: Centered BookMall Logo */}
              <div
                id="header-centered-brand"
                onClick={() => setActiveTab('home')}
                className="absolute left-1/2 -translate-x-1/2 flex items-center justify-center cursor-pointer select-none group"
                title="BookMall"
              >
                <div className="flex items-center text-2xl sm:text-3xl font-serif-book font-black tracking-tight leading-none">
                  <span
                    className="text-[#E06A26] transition-transform duration-200 group-hover:scale-105"
                    style={{ color: '#E06A26', textShadow: '0 1px 2px rgba(224, 106, 38, 0.12)' }}
                  >
                    Book
                  </span>
                  <span
                    className="text-[#2D7A4D] transition-transform duration-200 group-hover:scale-105"
                    style={{ color: '#2D7A4D', textShadow: '0 1px 2px rgba(45, 122, 77, 0.12)' }}
                  >
                    Mall
                  </span>
                </div>
              </div>

              {/* Right: Actions */}
              <div className="flex items-center gap-1">
                <button
                  id="header-search-btn"
                  onClick={() => setActiveTab('search')}
                  className="p-2 rounded-full text-[#5A5850] hover:text-[#2D2B26] hover:bg-[#F2EFE8] transition-colors cursor-pointer"
                  title="Qidiruv"
                >
                  <Search className="w-5 h-5" />
                </button>
                <button
                  id="header-notifications-btn"
                  onClick={() => setShowNotificationsModal(true)}
                  className="p-2 rounded-full text-[#5A5850] hover:text-[#2D2B26] hover:bg-[#F2EFE8] transition-colors relative cursor-pointer"
                  title="Bildirishnomalar"
                >
                  <Bell className="w-5 h-5" />
                  {unreadNotifsCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#C8523A] text-white font-bold text-[9px] rounded-full flex items-center justify-center animate-pulse">
                      {unreadNotifsCount}
                    </span>
                  )}
                </button>
              </div>
            </header>

            {/* Main Content View Switcher */}
            <main className="flex-1 px-4 sm:px-5 pt-3">
              {activeTab === 'home' && (
                <HomeScreen
                  activeLibrary={activeLibrary}
                  unreadNotifsCount={unreadNotifsCount}
                  donationCampaign={donationCampaign}
                  savedBookIds={savedBookIds}
                  onOpenNotifications={() => setShowNotificationsModal(true)}
                  onOpenLibrarySwitcher={() => setShowLibrarySwitcherModal(true)}
                  onOpenLibraryInfo={(lib) => setShowLibraryInfoModal(lib)}
                  onOpenDonationModal={() => setShowDonationModal(true)}
                  onOpenEnteredBooksModal={() => setShowEnteredBooksModal(true)}
                  onSelectStore={(store) => setSelectedStore(store)}
                  onSelectBook={(book) => setSelectedBook(book)}
                  onToggleSaveBook={handleToggleSave}
                  onQuickReadBook={(book) => setReaderBook(book)}
                  onNavigateToSearch={handleNavigateToSearch}
                  onOpenWelcomeSplash={() => setShowWelcomeSplash(true)}
                />
              )}

              {activeTab === 'search' && (
                <SearchScreen
                  initialQuery={searchInitialQuery}
                  savedBookIds={savedBookIds}
                  onSelectBook={(book) => setSelectedBook(book)}
                  onToggleSaveBook={handleToggleSave}
                  onOpenFilter={() => setShowFilterModal(true)}
                  activeFilterGenre={filterGenre}
                  activeFilterAvailability={filterAvailability}
                  activeSortBy={sortBy}
                />
              )}

              {activeTab === 'saved' && (
                <SavedScreen
                  savedBookIds={savedBookIds}
                  onSelectBook={(book) => setSelectedBook(book)}
                  onToggleSaveBook={handleToggleSave}
                  onOpenReader={(book) => setReaderBook(book)}
                  onNavigateToSearch={() => setActiveTab('search')}
                />
              )}

              {activeTab === 'profile' && (
                <ProfileScreen
                  activeLibrary={activeLibrary}
                  borrowedBooks={borrowedBooks}
                  waitingBooks={waitingBooks}
                  onOpenDonationModal={() => setShowDonationModal(true)}
                  onOpenLibrarySwitcher={() => setShowLibrarySwitcherModal(true)}
                  onOpenWelcomeSplash={() => setShowWelcomeSplash(true)}
                  onSelectBook={(book) => setSelectedBook(book)}
                />
              )}
            </main>

            {/* Bottom Navigation Bar */}
            <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md sm:max-w-lg md:max-w-xl bg-[#FDFCF9]/95 backdrop-blur-md border-t border-[#EAE5DA] px-6 py-2 z-40 flex items-center justify-between shadow-lg">
              <button
                id="nav-tab-home"
                onClick={() => {
                  setActiveTab('home');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`flex flex-col items-center gap-1 focus:outline-none transition-all cursor-pointer ${
                  activeTab === 'home' ? 'text-[#5A5A40] scale-105 font-bold' : 'text-[#9B978C] hover:text-[#5A5A40]'
                }`}
              >
                <Home className="w-5 h-5" />
                <span className="text-[10px]">Asosiy</span>
              </button>

              <button
                id="nav-tab-search"
                onClick={() => {
                  setActiveTab('search');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`flex flex-col items-center gap-1 focus:outline-none transition-all cursor-pointer ${
                  activeTab === 'search' ? 'text-[#5A5A40] scale-105 font-bold' : 'text-[#9B978C] hover:text-[#5A5A40]'
                }`}
              >
                <Search className="w-5 h-5" />
                <span className="text-[10px]">Qidiruv</span>
              </button>

              <button
                id="nav-tab-saved"
                onClick={() => {
                  setActiveTab('saved');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`flex flex-col items-center gap-1 focus:outline-none transition-all cursor-pointer relative ${
                  activeTab === 'saved' ? 'text-[#5A5A40] scale-105 font-bold' : 'text-[#9B978C] hover:text-[#5A5A40]'
                }`}
              >
                <Bookmark className="w-5 h-5" />
                <span className="text-[10px]">Saqlangan</span>
                {savedBookIds.length > 0 && (
                  <span className="absolute -top-1 right-2 w-2 h-2 bg-[#D49A3D] rounded-full" />
                )}
              </button>

              <button
                id="nav-tab-profile"
                onClick={() => {
                  setActiveTab('profile');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`flex flex-col items-center gap-1 focus:outline-none transition-all cursor-pointer ${
                  activeTab === 'profile' ? 'text-[#5A5A40] scale-105 font-bold' : 'text-[#9B978C] hover:text-[#5A5A40]'
                }`}
              >
                <User className="w-5 h-5" />
                <span className="text-[10px]">Profil</span>
              </button>
            </nav>
          </div>
        </div>
      )}

      {/* Global Modals for Reader, Audio, Borrow, etc. */}
      {selectedBook && (
        <BookDetailModal
          book={selectedBook}
          activeLibrary={activeLibrary}
          isSaved={savedBookIds.includes(selectedBook.id)}
          onClose={() => setSelectedBook(null)}
          onToggleSave={handleToggleSave}
          onOpenReader={(b) => {
            setSelectedBook(null);
            setReaderBook(b);
          }}
          onOpenAudio={(b) => {
            setSelectedBook(null);
            setAudioBook(b);
          }}
          onOpenBorrow={(b) => {
            setSelectedBook(null);
            setBorrowBook(b);
          }}
        />
      )}

      {readerBook && (
        <BookReaderModal
          book={readerBook}
          onClose={() => setReaderBook(null)}
        />
      )}

      {audioBook && (
        <AudioPlayerModal
          book={audioBook}
          onClose={() => setAudioBook(null)}
        />
      )}

      {borrowBook && (
        <BorrowModal
          book={borrowBook}
          libraries={libraries}
          activeLibrary={activeLibrary}
          onClose={() => setBorrowBook(null)}
          onSuccess={handleBorrowSuccess}
        />
      )}

      {showDonationModal && (
        <DonationModal
          campaign={donationCampaign}
          onClose={() => setShowDonationModal(false)}
          onDonateSuccess={handleDonationSuccess}
        />
      )}

      {selectedStore && (
        <StoreDetailModal
          store={selectedStore}
          onClose={() => setSelectedStore(null)}
          onSelectBook={(b) => setSelectedBook(b)}
        />
      )}

      {showLibraryInfoModal && (
        <LibraryInfoModal
          library={showLibraryInfoModal}
          onClose={() => setShowLibraryInfoModal(null)}
          onViewEnteredBooks={() => setShowEnteredBooksModal(true)}
        />
      )}

      {showLibrarySwitcherModal && (
        <LibrarySwitcherModal
          libraries={libraries}
          activeLibrary={activeLibrary}
          onSelectLibrary={(lib) => {
            setActiveLibrary(lib);
            showToast(`"${lib.name}" tanlandi`);
          }}
          onClose={() => setShowLibrarySwitcherModal(false)}
        />
      )}

      {showEnteredBooksModal && (
        <EnteredBooksListModal
          library={activeLibrary}
          books={ALL_BOOKS_DATABASE}
          savedBookIds={savedBookIds}
          onSelectBook={(b) => setSelectedBook(b)}
          onToggleSave={handleToggleSave}
          onClose={() => setShowEnteredBooksModal(false)}
        />
      )}

      {showNotificationsModal && (
        <NotificationsModal
          notifications={notifications}
          onMarkAllRead={() => {
            setNotifications(notifications.map((n) => ({ ...n, read: true })));
            showToast("Barcha bildirishnomalar o'qilgan deb belgilandi");
          }}
          onClearAll={() => {
            setNotifications([]);
            showToast("Bildirishnomalar tozalandi");
          }}
          onClose={() => setShowNotificationsModal(false)}
        />
      )}

      {showFilterModal && (
        <FilterModal
          selectedGenre={filterGenre}
          onSelectGenre={setFilterGenre}
          selectedAvailability={filterAvailability}
          onSelectAvailability={setFilterAvailability}
          sortBy={sortBy}
          onSelectSortBy={setSortBy}
          onReset={() => {
            setFilterGenre('all');
            setFilterAvailability('all');
            setSortBy('popular');
            showToast("Filtrlar tozalandi");
          }}
          onClose={() => setShowFilterModal(false)}
        />
      )}

      {/* Welcome Splash Screen */}
      {showWelcomeSplash && (
        <WelcomeSplashScreen
          activeLibrary={activeLibrary}
          featuredBook={ALL_BOOKS_DATABASE[0]}
          onEnterApp={() => setShowWelcomeSplash(false)}
          onPlayIntro={() => {
            setShowWelcomeSplash(false);
            setShowIntroSequence(true);
          }}
          onOpenLibrarySwitcher={() => {
            setShowWelcomeSplash(false);
            setShowLibrarySwitcherModal(true);
          }}
          onSelectBook={(book) => {
            setShowWelcomeSplash(false);
            setSelectedBook(book);
          }}
        />
      )}

      {/* BookMall 3-Frame Cinematic Intro Sequence */}
      {showIntroSequence && (
        <BookMallIntroSequence
          onComplete={() => setShowIntroSequence(false)}
        />
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <SettingsModal
          onClose={() => setShowSettingsModal(false)}
          onOpenDonationModal={() => {
            setShowSettingsModal(false);
            setShowDonationModal(true);
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <RealtimeProvider>
        <MainAppContent />
      </RealtimeProvider>
    </AuthProvider>
  );
}
