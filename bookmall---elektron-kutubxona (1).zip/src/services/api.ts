import { User, DbLibrary, DbBook, DbLoan, DbMember, LibraryStats, UserProfileResponse, ReadBook, ProfileReadBookItem } from '../types';
import { initialUsers, initialLibraries, initialBooks, initialLoans, initialMembersRoster } from '../../server/db';

const API_BASE = '/api';

function getAuthHeaders(token?: string): HeadersInit {
  const currentToken = token || localStorage.getItem('bookmall_auth_token') || 'token-admin-navoiy-sec99';
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${currentToken}`,
    'x-auth-token': currentToken,
  };
}

export const api = {
  // Auth
  auth: {
    async getUsers(): Promise<User[]> {
      try {
        const res = await fetch(`${API_BASE}/auth/users`);
        if (!res.ok) throw new Error('Failed to fetch users');
        return await res.json();
      } catch (err) {
        console.warn('Fallback to local initial users:', err);
        return initialUsers;
      }
    },

    async login(userId: string): Promise<{ user: User; token: string }> {
      try {
        const res = await fetch(`${API_BASE}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId }),
        });
        if (!res.ok) throw new Error('Login failed');
        const data = await res.json();
        if (data.token) localStorage.setItem('bookmall_auth_token', data.token);
        return data;
      } catch (err) {
        const user = initialUsers.find((u) => u.id === userId) || initialUsers[0];
        if (user.token) localStorage.setItem('bookmall_auth_token', user.token);
        return { user, token: user.token || 'token-admin-navoiy-sec99' };
      }
    },

    async me(token?: string): Promise<{ user: User }> {
      const res = await fetch(`${API_BASE}/auth/me`, {
        headers: getAuthHeaders(token),
      });
      if (!res.ok) throw new Error('Auth me failed');
      return await res.json();
    },
  },

  // Libraries
  libraries: {
    async getAll(): Promise<DbLibrary[]> {
      try {
        const res = await fetch(`${API_BASE}/libraries`);
        if (!res.ok) throw new Error('Failed to fetch libraries');
        return await res.json();
      } catch (err) {
        return initialLibraries;
      }
    },

    async update(id: string, data: Partial<DbLibrary>, token?: string): Promise<{ message: string; library: DbLibrary }> {
      const res = await fetch(`${API_BASE}/libraries/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(token),
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Kutubxonani yangilab bo‘lmadi');
      }
      return await res.json();
    },
  },

  // Books CRUD (RBAC Protected on POST, PUT, DELETE)
  books: {
    async getAll(params?: { libraryId?: string; genre?: string; query?: string; availableOnly?: boolean }): Promise<DbBook[]> {
      try {
        const queryParams = new URLSearchParams();
        if (params?.libraryId) queryParams.set('libraryId', params.libraryId);
        if (params?.genre) queryParams.set('genre', params.genre);
        if (params?.query) queryParams.set('query', params.query);
        if (params?.availableOnly) queryParams.set('availableOnly', 'true');

        const res = await fetch(`${API_BASE}/books?${queryParams.toString()}`);
        if (!res.ok) throw new Error('Failed to fetch books');
        return await res.json();
      } catch (err) {
        let list = [...initialBooks];
        if (params?.libraryId && params.libraryId !== 'all') {
          list = list.filter((b) => b.libraryId === params.libraryId);
        }
        return list;
      }
    },

    async create(bookData: Omit<DbBook, 'id' | 'createdAt' | 'updatedAt'>, token?: string): Promise<{ message: string; book: DbBook }> {
      const res = await fetch(`${API_BASE}/books`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify(bookData),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Kitob qo'shishda xatolik yuz berdi");
      }
      return await res.json();
    },

    async update(id: string, bookData: Partial<DbBook>, token?: string): Promise<{ message: string; book: DbBook }> {
      const res = await fetch(`${API_BASE}/books/${id}`, {
        method: 'PUT',
        headers: getAuthHeaders(token),
        body: JSON.stringify(bookData),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Kitobni tahrirlashda xatolik yuz berdi");
      }
      return await res.json();
    },

    async delete(id: string, token?: string): Promise<{ message: string }> {
      const res = await fetch(`${API_BASE}/books/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(token),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Kitobni o'chirishda xatolik yuz berdi");
      }
      return await res.json();
    },
  },

  // Loans (RBAC & Privacy Protected)
  loans: {
    async getAll(token?: string): Promise<DbLoan[]> {
      try {
        const res = await fetch(`${API_BASE}/loans`, {
          headers: getAuthHeaders(token),
        });
        if (!res.ok) throw new Error('Failed to fetch loans');
        return await res.json();
      } catch (err) {
        return initialLoans;
      }
    },

    async create(data: { bookId: string; memberId: string; dueDate: string }, token?: string): Promise<{ message: string; loan: DbLoan }> {
      const res = await fetch(`${API_BASE}/loans`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Kitob berishda xatolik yuz berdi");
      }
      return await res.json();
    },

    async borrow(data: {
      bookId: string;
      durationDays?: number;
      libraryId?: string;
      fullName?: string;
      phone?: string;
      bookTitle?: string;
      bookAuthor?: string;
      bookCover?: string;
      genre?: string;
    }, token?: string): Promise<{ message: string; loan: DbLoan; book: DbBook }> {
      const res = await fetch(`${API_BASE}/loans/borrow`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify(data),
      });

      const body = await res.json();
      if (!res.ok) {
        throw new Error(body.error || "Kitobni band qilishda xatolik yuz berdi");
      }
      return body;
    },

    async returnLoan(loanId: string, token?: string): Promise<{ message: string; loan: DbLoan }> {
      const res = await fetch(`${API_BASE}/loans/${loanId}/return`, {
        method: 'PUT',
        headers: getAuthHeaders(token),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Kitobni qaytarishda xatolik yuz berdi");
      }
      return await res.json();
    },
  },

  // Members (Admin Only)
  members: {
    async getAll(token?: string): Promise<DbMember[]> {
      try {
        const res = await fetch(`${API_BASE}/members`, {
          headers: getAuthHeaders(token),
        });
        if (!res.ok) throw new Error('Failed to fetch members');
        return await res.json();
      } catch (err) {
        return initialMembersRoster;
      }
    },

    async create(data: { name: string; email: string; phone: string }, token?: string): Promise<{ message: string; member: DbMember }> {
      const res = await fetch(`${API_BASE}/members`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify(data),
      });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body.error || "A'zo qo'shishda xatolik yuz berdi");
      }
      return body;
    },
  },

  // Stats (Admin Only)
  stats: {
    async get(token?: string): Promise<LibraryStats> {
      try {
        const res = await fetch(`${API_BASE}/stats`, {
          headers: getAuthHeaders(token),
        });
        if (!res.ok) throw new Error('Failed to fetch stats');
        return await res.json();
      } catch (err) {
        return {
          totalBooks: 95,
          availableBooks: 78,
          borrowedBooks: 17,
          totalMembers: 5,
          overdueBooks: 1,
          recentBooks: initialBooks.slice(0, 5),
          recentLoans: initialLoans.slice(0, 5),
          genreDistribution: [
            { genre: "Falsafiy roman", count: 12 },
            { genre: "Tarixiy roman", count: 45 },
            { genre: "IT & Dasturlash", count: 10 },
          ],
        };
      }
    },
  },

  // Security Test Execution
  security: {
    async runTest(token?: string) {
      const res = await fetch(`${API_BASE}/security-test/run`, {
        method: 'POST',
        headers: getAuthHeaders(token),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Security test failed');
      }
      return await res.json();
    },

    async runConcurrencyTest(token?: string) {
      const res = await fetch(`${API_BASE}/security-test/concurrency-test`, {
        method: 'POST',
        headers: getAuthHeaders(token),
      });
      const body = await res.json();
      if (!res.ok) {
        throw new Error(body.error || 'Concurrency test failed');
      }
      return body;
    },
  },

  // Profile & Social Follow Service
  profile: {
    async get(userId?: string, page = 1, limit = 8, token?: string): Promise<UserProfileResponse> {
      const params = new URLSearchParams();
      if (userId) params.set('userId', userId);
      params.set('page', page.toString());
      params.set('limit', limit.toString());

      const res = await fetch(`${API_BASE}/profile?${params.toString()}`, {
        headers: getAuthHeaders(token),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Profilni yuklab bo'lmadi");
      }
      return await res.json();
    },

    async update(
      data: { name?: string; username?: string; bio?: string; avatar?: string; phone?: string },
      token?: string
    ): Promise<{ message: string; user: User }> {
      const res = await fetch(`${API_BASE}/profile`, {
        method: 'PUT',
        headers: getAuthHeaders(token),
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Profilni yangilab bo'lmadi");
      }
      return await res.json();
    },

    async toggleFollow(
      data: { targetType: 'USER' | 'LIBRARY' | 'PUBLISHER'; targetId: string },
      token?: string
    ): Promise<{
      message: string;
      isFollowing: boolean;
      followersCount: number;
      followingCount: number;
    }> {
      const res = await fetch(`${API_BASE}/profile/follow`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Obunani yangilab bo'lmadi");
      }
      return await res.json();
    },

    async getReadBooks(
      userId?: string,
      page = 1,
      limit = 8,
      token?: string
    ): Promise<{
      items: ProfileReadBookItem[];
      total: number;
      page: number;
      limit: number;
      hasMore: boolean;
    }> {
      const params = new URLSearchParams();
      if (userId) params.set('userId', userId);
      params.set('page', page.toString());
      params.set('limit', limit.toString());

      const res = await fetch(`${API_BASE}/profile/read-books?${params.toString()}`, {
        headers: getAuthHeaders(token),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "O'qilgan kitoblarni yuklab bo'lmadi");
      }
      return await res.json();
    },

    async markRead(
      bookId: string,
      rating = 5,
      notes?: string,
      token?: string
    ): Promise<{ message: string; readBook: ReadBook }> {
      const res = await fetch(`${API_BASE}/profile/mark-read`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify({ bookId, rating, notes }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Kitobni belgilab bo'lmadi");
      }
      return await res.json();
    },

    async pinBook(
      bookId: string,
      order?: number,
      token?: string
    ): Promise<{
      success: boolean;
      message: string;
      isPinned: boolean;
      pinnedOrder?: number;
      readBooks?: ProfileReadBookItem[];
    }> {
      const res = await fetch(`${API_BASE}/profile/pin-book`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify({ bookId, order }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const error: any = new Error(data.error || "Kitobni qadashda xatolik yuz berdi");
        error.code = data.code;
        throw error;
      }
      return data;
    },

    async setSubscriptionPlan(
      plan: 'FREE' | 'PREMIUM',
      token?: string
    ): Promise<{ message: string; user: User }> {
      const res = await fetch(`${API_BASE}/profile/subscription-plan`, {
        method: 'POST',
        headers: getAuthHeaders(token),
        body: JSON.stringify({ plan }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data.error || "Tarifni o'zgartirib bo'lmadi");
      }
      return data;
    },
  },
};
