import React from 'react';
import { Landmark, Store, ExternalLink } from 'lucide-react';
import { StoreItem } from '../types';

interface StoryCircleProps {
  store: StoreItem;
  onClick: (store: StoreItem) => void;
}

export const StoryCircle: React.FC<StoryCircleProps> = ({ store, onClick }) => {
  return (
    <button
      id={`story-btn-${store.id}`}
      onClick={() => onClick(store)}
      className="flex flex-col items-center gap-1.5 focus:outline-none group flex-shrink-0 cursor-pointer transition-transform duration-200 hover:scale-105 active:scale-95"
    >
      <div
        className="w-16 h-16 rounded-full p-[2.5px] transition-all duration-300 group-hover:shadow-md"
        style={{ background: store.ring }}
      >
        <div
          className="w-full h-full rounded-full flex flex-col items-center justify-center relative overflow-hidden transition-transform duration-300 group-hover:scale-95"
          style={{ background: store.bg }}
        >
          {store.icon === 'triangle' ? (
            <div className="flex items-center justify-center">
              <span className="text-xl font-black text-amber-500 transform rotate-12">▲</span>
            </div>
          ) : store.icon === 'landmark' ? (
            <Landmark className="w-6 h-6 text-[#5A5A40]" />
          ) : store.label ? (
            <div className="flex flex-col items-center justify-center leading-none">
              <span
                className={`text-[11px] font-black tracking-tight ${store.italic ? 'italic' : ''}`}
                style={{ color: store.labelColor || '#fff' }}
              >
                {store.label}
              </span>
              {store.sub && (
                <span
                  className="text-[8px] font-bold tracking-widest mt-0.5 opacity-90"
                  style={{ color: store.labelColor || '#fff' }}
                >
                  {store.sub}
                </span>
              )}
            </div>
          ) : (
            <Store className="w-5 h-5 text-[#5A5850]" />
          )}
        </div>
      </div>
      <span className="text-[11px] font-medium text-[#4A473D] group-hover:text-[#5A5A40] transition-colors w-16 text-center truncate">
        {store.name}
      </span>
    </button>
  );
};
