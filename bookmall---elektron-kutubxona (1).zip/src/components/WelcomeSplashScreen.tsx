import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Sparkles,
  Landmark,
  Quote,
  ArrowRight,
  RefreshCw,
  CheckCircle2,
  GraduationCap,
  Heart,
  Headphones,
  SlidersHorizontal,
  ChevronRight,
  Library,
  X
} from 'lucide-react';
import { LibraryItem, Book } from '../types';
import bookmallLogoImg from '../assets/images/bookmall_logo_1788418721778.jpg';

interface WelcomeSplashScreenProps {
  onEnterApp: () => void;
  onOpenLibrarySwitcher: () => void;
  onSelectBook: (book: Book) => void;
  onPlayIntro?: () => void;
  activeLibrary: LibraryItem;
  featuredBook: Book;
  totalBooksCount?: number;
}

const LITERARY_QUOTES = [
  {
    quote: "Kitob — aql chirog'i, ma'rifat va ma'naviyatning bitmas-tuganmas bulog'idir.",
    author: "Alisher Navoiy",
    title: "Mumtoz adabiyot dahosi"
  },
  {
    quote: "Kitob o'qigan inson fikrlay oladi, tafakkur esa millat taraqqiyotining mustahkam poydevoridir.",
    author: "Abdulla Qodiriy",
    title: "O'zbek romanchiligi asoschisi"
  },
  {
    quote: "Kitob — inson qalbining eng samimiy, hech qachon xiyonat qilmaydigan sirdoshi.",
    author: "O'tkir Hoshimov",
    title: "O'zbekiston xalq yozuvchisi"
  },
  {
    quote: "Dunyodagi eng katta boylik — bilim, eng ulug' fazilat esa kitobxonlikdir.",
    author: "Mirzo Ulug'bek",
    title: "Buyuk alloma va mutafakkir"
  },
  {
    quote: "Barcha yaxshi kitoblarni o'qish — o'tgan asrlarning eng buyuk insonlari bilan suhbatlashmoq demakdir.",
    author: "Rene Dekart",
    title: "Faylasuf va olim"
  }
];

export const WelcomeSplashScreen: React.FC<WelcomeSplashScreenProps> = ({
  onEnterApp,
  onOpenLibrarySwitcher,
  onSelectBook,
  onPlayIntro,
  activeLibrary,
  featuredBook,
  totalBooksCount = 45000
}) => {
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [isChangingQuote, setIsChangingQuote] = useState(false);
  const [skipNextTime, setSkipNextTime] = useState(false);

  const nextQuote = () => {
    setIsChangingQuote(true);
    setTimeout(() => {
      setQuoteIndex((prev) => (prev + 1) % LITERARY_QUOTES.length);
      setIsChangingQuote(false);
    }, 200);
  };

  const handleEnter = () => {
    if (skipNextTime) {
      localStorage.setItem('bookmall_skip_splash', 'true');
    }
    onEnterApp();
  };

  const currentQuote = LITERARY_QUOTES[quoteIndex];

  return (
    <div
      id="welcome-splash-screen"
      className="fixed inset-0 z-50 overflow-y-auto bg-[#FDFCF9] text-[#3D3B35] flex flex-col justify-between custom-scrollbar"
    >
      {/* Background Subtle Warm Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-lg h-96 bg-gradient-to-b from-[#FAF2E3]/80 via-[#F5EFE3]/30 to-transparent pointer-events-none rounded-b-[4rem]" />

      {/* Main Container */}
      <div className="relative max-w-md mx-auto w-full px-5 pt-4 pb-10 flex-1 flex flex-col justify-between">
        
        {/* Top Controls Bar with Close Button */}
        <div className="w-full flex items-center justify-between pb-3 mb-2">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#8C5D19] bg-[#FAF2E3] px-3 py-1 rounded-full border border-[#E8DFC8] shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#D49A3D]" />
            <span>BookMall Rasmiy Oynasi</span>
          </div>
          <button
            id="close-welcome-splash-btn"
            onClick={handleEnter}
            className="p-1.5 rounded-full bg-[#FAF8F5] hover:bg-[#F2EFE8] text-[#5A5850] hover:text-[#2D2B26] border border-[#E6E1D6] shadow-xs transition-colors cursor-pointer flex items-center gap-1 text-xs font-semibold"
            title="Oynani yopish"
          >
            <X className="w-4 h-4 text-[#5A5850]" />
            <span className="text-[11px] pr-1">Yopish</span>
          </button>
        </div>
        
        {/* 1. Header & Official BookMall Logo Display */}
        <div className="flex flex-col items-center text-center space-y-4">
          
          {/* Logo Card with Textured Parchment Border */}
          <div className="relative group">
            <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden shadow-lg border-2 border-[#E6E1D6] bg-[#FAF8F5] p-1.5 transition-transform duration-300 hover:scale-105">
              <img
                src={bookmallLogoImg}
                alt="BookMall rasmiy belgisi"
                className="w-full h-full object-contain rounded-2xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 whitespace-nowrap bg-[#5A5A40] text-white text-[10px] uppercase font-bold tracking-widest px-3 py-0.5 rounded-full shadow-xs border border-[#484833]">
              Raqamli Kutubxona
            </div>
          </div>

          <div className="pt-2">
            <h1 className="text-2xl font-bold tracking-tight font-serif-book text-[#2D2B26]">
              Book<span className="text-[#2C5338]">Mall</span>
            </h1>
            <p className="text-xs text-[#757268] mt-1 max-w-[280px] mx-auto leading-relaxed">
              O'zbekiston kutubxonalari va kitob do'konlarining yagona raqamli platformasi
            </p>
          </div>
        </div>

        {/* 2. Interactive Feature: Kunning Hikmati (Daily Book Quote) */}
        <div className="my-6 bg-[#FAF2E3]/90 border border-[#E8DFC8] rounded-2xl p-4 sm:p-5 relative shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-[#8C5D19]">
              <Quote className="w-4 h-4 fill-[#D49A3D]/20 text-[#8C5D19]" />
              <span className="text-[11px] uppercase font-bold tracking-wider">
                Kunning Hikmati
              </span>
            </div>
            <button
              onClick={nextQuote}
              className="text-[11px] text-[#757268] hover:text-[#3D3B35] flex items-center gap-1 font-medium px-2 py-0.5 rounded-lg hover:bg-[#F2EFE8] transition-colors cursor-pointer"
              title="Boshqa hikmatni ko'rish"
            >
              <RefreshCw className={`w-3 h-3 text-[#8C5D19] ${isChangingQuote ? 'animate-spin' : ''}`} />
              <span>Boshqasi</span>
            </button>
          </div>

          <div className={`transition-opacity duration-200 ${isChangingQuote ? 'opacity-0' : 'opacity-100'}`}>
            <p className="text-xs sm:text-[13px] font-serif-book italic text-[#3D3B35] leading-relaxed">
              "{currentQuote.quote}"
            </p>
            <div className="mt-2.5 flex items-center justify-between text-[11px]">
              <span className="font-bold text-[#2D2B26]">{currentQuote.author}</span>
              <span className="text-[#8F8B7F] text-[10px]">{currentQuote.title}</span>
            </div>
          </div>
        </div>

        {/* 3. Today's Spotlight / Quick Feature (Creative Addition) */}
        <div className="space-y-3 mb-6">
          <div className="flex items-center justify-between px-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#757268] flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-[#D49A3D]" />
              Kunning tavsiya etilgan kitobi
            </span>
          </div>

          <div
            onClick={() => {
              onSelectBook(featuredBook);
              onEnterApp();
            }}
            className="p-3 bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl flex items-center gap-3.5 hover:border-[#5A5A40]/40 transition-all cursor-pointer shadow-xs group"
          >
            <div className="w-12 h-16 rounded-lg overflow-hidden flex-shrink-0 shadow-xs relative" style={{ background: featuredBook.cover }}>
              <div className="w-full h-full flex items-center justify-center p-1 text-center">
                <span className={`text-[8px] font-bold font-serif-book line-clamp-2 ${featuredBook.light ? 'text-[#2D2B26]' : 'text-white'}`}>
                  {featuredBook.title}
                </span>
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <span className="text-[9px] font-bold uppercase text-[#8C5D19] bg-[#FAF2E3] px-1.5 py-0.5 rounded border border-[#E8DFC8]">
                {featuredBook.genre}
              </span>
              <h4 className="text-xs font-bold text-[#3D3B35] group-hover:text-[#5A5A40] transition-colors truncate mt-1">
                {featuredBook.title}
              </h4>
              <p className="text-[11px] text-[#757268] truncate">{featuredBook.author}</p>
            </div>

            <ChevronRight className="w-4 h-4 text-[#8F8B7F] group-hover:text-[#5A5A40] group-hover:translate-x-0.5 transition-all flex-shrink-0" />
          </div>

          {/* Quick Active Library Selector Info */}
          <div
            onClick={onOpenLibrarySwitcher}
            className="p-2.5 bg-[#F2EFE8]/70 border border-[#E6E1D6] rounded-xl flex items-center justify-between text-xs cursor-pointer hover:bg-[#EAE5DA] transition-colors"
          >
            <div className="flex items-center gap-2">
              <Landmark className="w-3.5 h-3.5 text-[#5A5A40]" />
              <span className="text-[11px] text-[#757268]">Faol kutubxona:</span>
              <span className="text-[11px] font-bold text-[#3D3B35] truncate max-w-[170px]">{activeLibrary.name}</span>
            </div>
            <span className="text-[10px] text-[#5A5A40] font-semibold underline">O'zgartirish</span>
          </div>
        </div>

        {/* 4. Platform Key Statistics */}
        <div className="grid grid-cols-3 gap-2 text-center mb-6">
          <div className="p-2.5 bg-[#FAF8F5] border border-[#E6E1D6] rounded-xl">
            <span className="text-xs font-bold text-[#3D3B35] block">45,000+</span>
            <span className="text-[9px] text-[#8F8B7F] block mt-0.5">Kitob & audio</span>
          </div>
          <div className="p-2.5 bg-[#FAF8F5] border border-[#E6E1D6] rounded-xl">
            <span className="text-xs font-bold text-[#3D3B35] block">3 ta ARM</span>
            <span className="text-[9px] text-[#8F8B7F] block mt-0.5">Faol kutubxona</span>
          </div>
          <div className="p-2.5 bg-[#FAF8F5] border border-[#E6E1D6] rounded-xl">
            <span className="text-xs font-bold text-[#3D3B35] block">4 ta OTM</span>
            <span className="text-[9px] text-[#8F8B7F] block mt-0.5">Davlat universiteti</span>
          </div>
        </div>

        {/* 5. Enter Buttons & Footer */}
        <div className="space-y-3">
          <button
            id="enter-applet-btn"
            onClick={handleEnter}
            className="w-full py-3.5 px-6 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-sm rounded-2xl shadow-md shadow-[#5A5A40]/25 flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-[0.98]"
          >
            <span>Kitobxonlikka kirish</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {onPlayIntro && (
            <button
              onClick={onPlayIntro}
              className="w-full py-2.5 px-4 bg-[#FAF2E3] hover:bg-[#F3E7CF] text-[#8C5D19] border border-[#E8DFC8] rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D49A3D]" />
              <span>3-Kadrli BookMall Intro animatsiyasini ko'rish</span>
            </button>
          )}

          <div className="flex items-center justify-center gap-2 pt-1">
            <label className="flex items-center gap-1.5 text-[11px] text-[#8F8B7F] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={skipNextTime}
                onChange={(e) => setSkipNextTime(e.target.checked)}
                className="w-3.5 h-3.5 rounded border-[#D0C9BA] text-[#5A5A40] focus:ring-[#5A5A40] accent-[#5A5A40]"
              />
              <span>Keyingi safar to'g'ridan-to'g'ri ochilsin</span>
            </label>
          </div>
        </div>

      </div>
    </div>
  );
};
