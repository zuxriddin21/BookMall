import React, { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  UserCheck,
  ChevronDown,
  LayoutDashboard,
  Smartphone,
  CheckCircle2,
  Lock,
  Building2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function RoleSwitcherBanner() {
  const {
    currentUser,
    allUsers,
    activeLibrary,
    activeAppView,
    setActiveAppView,
    switchUser,
  } = useAuth();

  const [isOpen, setIsOpen] = useState(false);

  const isAdmin = currentUser.role === 'LIBRARY_ADMIN';

  return (
    <div className="bg-[#211F1C] text-[#E6E0D2] border-b border-[#38352F] text-xs py-1.5 px-3 sm:px-4 flex items-center justify-between z-40 relative">
      {/* Left: Current Active Role Indicator */}
      <div className="flex items-center gap-2 min-w-0">
        <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-[#33302B] border border-[#48443D] text-[11px] font-bold">
          {isAdmin ? (
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <Lock className="w-3.5 h-3.5 text-amber-400" />
          )}
          <span className={isAdmin ? 'text-emerald-400' : 'text-amber-400'}>
            {currentUser.role}
          </span>
        </span>

        <span className="hidden sm:inline text-[#8C8677]">•</span>

        <div className="truncate text-[11px]">
          <span className="text-white font-semibold">{currentUser.name}</span>
          <span className="text-[#8C8677] hidden md:inline ml-1">({activeLibrary.name})</span>
        </div>
      </div>

      {/* Right: View Toggle + Role Switch Dropdown */}
      <div className="flex items-center gap-2 shrink-0">
        {/* View Switch Button */}
        {activeAppView === 'admin' ? (
          <button
            onClick={() => setActiveAppView('member')}
            className="px-2.5 py-1 rounded-lg bg-[#38352E] hover:bg-[#48443B] text-[#D8D2C4] font-bold text-[11px] flex items-center gap-1.5 border border-[#4D4940] transition-colors cursor-pointer"
            title="Oddiy foydalanuvchi ko'rinishiga o'tish"
          >
            <Smartphone className="w-3.5 h-3.5 text-[#E8B96A]" />
            <span className="hidden sm:inline">Kitobxon Rejimi</span>
          </button>
        ) : (
          <button
            onClick={() => setActiveAppView('admin')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] flex items-center gap-1.5 border transition-colors cursor-pointer ${
              isAdmin
                ? 'bg-[#2D7A4D] hover:bg-[#23633E] text-white border-[#3F8E5F]'
                : 'bg-[#38352E] hover:bg-[#48443B] text-[#D8D2C4] border-[#4D4940]'
            }`}
            title="Kutubxona Admin Paneliga o'tish"
          >
            <LayoutDashboard className="w-3.5 h-3.5 text-[#E8B96A]" />
            <span>Admin Paneli</span>
            {!isAdmin && (
              <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-normal">
                403 Test
              </span>
            )}
          </button>
        )}

        {/* Quick User Picker */}
        <div className="relative">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="px-2.5 py-1 rounded-lg bg-[#2D2A24] hover:bg-[#38342D] border border-[#48443C] text-[11px] font-bold text-[#D8D2C4] flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <UserCheck className="w-3.5 h-3.5 text-[#E8B96A]" />
            <span className="hidden sm:inline">Rolni O'zgartirish</span>
            <ChevronDown className="w-3 h-3 text-[#8C8677]" />
          </button>

          {isOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-72 bg-[#FAF8F5] text-[#2D2A26] border border-[#E6E1D6] rounded-2xl shadow-2xl p-2.5 z-50 animate-in fade-in duration-150">
              <p className="text-[10px] font-black uppercase tracking-wider text-[#8C8677] px-2 py-1">
                Foydalanuvchi tanlang:
              </p>
              <div className="space-y-1">
                {allUsers.map((u) => {
                  const isSelected = currentUser.id === u.id;
                  const isUserAdmin = u.role === 'LIBRARY_ADMIN';
                  return (
                    <button
                      key={u.id}
                      onClick={async () => {
                        await switchUser(u.id);
                        setIsOpen(false);
                      }}
                      className={`w-full p-2 rounded-xl text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-[#5A5A40] text-white font-bold'
                          : 'hover:bg-[#F2ECE1] text-[#4A473E]'
                      }`}
                    >
                      <div className="truncate pr-2">
                        <div className="flex items-center gap-1.5">
                          <span className="truncate font-semibold">{u.name}</span>
                          <span
                            className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase ${
                              isUserAdmin
                                ? isSelected
                                  ? 'bg-[#E8B96A] text-[#2D2A26]'
                                  : 'bg-emerald-100 text-emerald-800'
                                : isSelected
                                ? 'bg-white/20 text-white'
                                : 'bg-stone-200 text-stone-700'
                            }`}
                          >
                            {u.role === 'LIBRARY_ADMIN' ? 'Admin' : "A'zo"}
                          </span>
                        </div>
                        <p className={`text-[10px] truncate ${isSelected ? 'text-[#E8B96A]' : 'text-[#8C8677]'}`}>
                          {u.libraryId} • {u.email}
                        </p>
                      </div>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-[#E8B96A] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
