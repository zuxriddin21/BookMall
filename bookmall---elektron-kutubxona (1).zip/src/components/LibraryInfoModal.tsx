import React from 'react';
import { X, Landmark, MapPin, Phone, Clock, Users, BookOpen, Layers, CheckCircle2, ChevronRight } from 'lucide-react';
import { LibraryItem } from '../types';

interface LibraryInfoModalProps {
  library: LibraryItem | null;
  onClose: () => void;
  onViewEnteredBooks: () => void;
}

export const LibraryInfoModal: React.FC<LibraryInfoModalProps> = ({
  library,
  onClose,
  onViewEnteredBooks,
}) => {
  if (!library) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="library-info-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6]"
      >
        {/* Top Banner */}
        <div className="p-6 text-white relative" style={{ background: library.gradient }}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Landmark className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#E8B96A]">
                Axborot-Resurs Markazi
              </span>
              <h2 className="text-lg sm:text-xl font-bold">{library.name}</h2>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="p-5 space-y-5 overflow-y-auto max-h-[75vh] custom-scrollbar">
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-[#F2EFE8] border border-[#E6E1D6] rounded-xl p-3 text-center">
              <span className="text-[10px] text-[#8F8B7F] block font-medium">Jami adabiyot</span>
              <span className="text-sm font-bold text-[#3D3B35] mt-0.5 block">
                {library.totalLiterature.toLocaleString()}
              </span>
            </div>
            <div className="bg-[#FAF2E3] border border-[#E8DFC8] rounded-xl p-3 text-center cursor-pointer hover:bg-[#F3E7CF] transition-colors" onClick={onViewEnteredBooks}>
              <span className="text-[10px] text-[#8C5D19] block font-medium">Kiritilgan kitoblar</span>
              <span className="text-sm font-bold text-[#8C5D19] mt-0.5 block">
                {library.enteredBooks} ta →
              </span>
            </div>
            <div className="bg-[#F2EFE8] border border-[#E6E1D6] rounded-xl p-3 text-center">
              <span className="text-[10px] text-[#8F8B7F] block font-medium">A'zolar</span>
              <span className="text-sm font-bold text-[#3D3B35] mt-0.5 block">
                {library.membersCount.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Details */}
          <div className="space-y-3 bg-[#F2EFE8] p-4 rounded-xl border border-[#E6E1D6] text-xs text-[#5A5850]">
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-[#5A5A40] mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-semibold text-[#3D3B35] block">Manzil:</span>
                <span>{library.address}</span>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Clock className="w-4 h-4 text-[#2C5338] mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-semibold text-[#3D3B35] block">Ish vaqti:</span>
                <span>{library.workingHours}</span>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Phone className="w-4 h-4 text-[#8C5D19] mt-0.5 flex-shrink-0" />
              <div>
                <span className="font-semibold text-[#3D3B35] block">Bog'lanish:</span>
                <span>{library.phone}</span>
              </div>
            </div>
          </div>

          {/* Quick Action to view books */}
          <button
            onClick={() => {
              onClose();
              onViewEnteredBooks();
            }}
            className="w-full py-3 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl shadow-md shadow-[#5A5A40]/20 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <BookOpen className="w-4 h-4" />
            <span>Kutubxona fondidagi barcha kitoblarni ko'rish</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
