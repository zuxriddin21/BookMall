import React, { useState } from 'react';
import { Bookmark, BookOpen, Trash2, Star, CheckCircle, Search } from 'lucide-react';
import { Book } from '../types';
import { ALL_BOOKS_DATABASE } from '../data/bookData';

interface SavedScreenProps {
  savedBookIds: string[];
  onSelectBook: (book: Book) => void;
  onToggleSaveBook: (book: Book) => void;
  onOpenReader: (book: Book) => void;
  onNavigateToSearch: () => void;
}

export const SavedScreen: React.FC<SavedScreenProps> = ({
  savedBookIds,
  onSelectBook,
  onToggleSaveBook,
  onOpenReader,
  onNavigateToSearch,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'reading' | 'completed'>('all');

  const savedBooks = ALL_BOOKS_DATABASE.filter((b) => savedBookIds.includes(b.id));

  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between pt-1">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-[#3D3B35]">Saqlangan kitoblar</h2>
          <p className="text-[11px] text-[#757268]">Mutolaa ro'yxatingiz va xatcho'plar</p>
        </div>
        <span className="text-xs font-bold text-[#5A5A40] bg-[#ECEAE1] px-2.5 py-1 rounded-full">
          {savedBooks.length} ta kitob
        </span>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-[#EFECE3] p-1 rounded-2xl">
        {[
          { id: 'all', label: 'Barchasi' },
          { id: 'reading', label: "O'qilmoqda (2)" },
          { id: 'completed', label: "O'qib bo'lingan (4)" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-[#FAF8F5] text-[#3D3B35] shadow-xs font-bold'
                : 'text-[#757268] hover:text-[#3D3B35]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Book list */}
      {savedBooks.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-[#FAF8F5] rounded-3xl border border-[#E6E1D6] p-6">
          <div className="w-14 h-14 bg-[#FAF2E3] rounded-full flex items-center justify-center mx-auto text-[#D49A3D]">
            <Bookmark className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-[#3D3B35]">Saqlangan kitoblar yo'q</h3>
          <p className="text-xs text-[#757268] max-w-xs mx-auto">
            O'zingizga yoqqan kitoblarni xatcho'p orqali saqlab qo'ying va istalgan paytda o'qing.
          </p>
          <button
            onClick={onNavigateToSearch}
            className="px-4 py-2.5 bg-[#5A5A40] hover:bg-[#484833] text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Katalogdan kitob tanlash
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {savedBooks.map((book) => (
            <div
              key={book.id}
              onClick={() => onSelectBook(book)}
              className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl p-3 flex gap-3 items-center justify-between hover:border-[#5A5A40]/50 hover:shadow-md transition-all cursor-pointer group"
            >
              {/* Cover thumbnail */}
              <div
                className="w-16 h-22 rounded-xl flex-shrink-0 flex flex-col justify-between p-2 shadow-xs bg-[#EFECE3]"
                style={{
                  background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
                    ? book.cover
                    : `url(${book.cover}) center/cover no-repeat`,
                }}
              >
                <span className={`text-[8px] font-bold ${book.light ? 'text-[#2D2B26]' : 'text-white'}`}>
                  ★ {book.rating}
                </span>
                <span className={`text-[8px] font-serif-book font-bold line-clamp-2 ${book.light ? 'text-[#2D2B26]' : 'text-white'}`}>
                  {book.title}
                </span>
              </div>

              {/* Book Info */}
              <div className="flex-1 min-w-0">
                <span className="text-[10px] font-semibold text-[#5A5A40] uppercase">
                  {book.genre || 'Adabiyot'}
                </span>
                <h4 className="text-xs font-bold text-[#3D3B35] truncate group-hover:text-[#5A5A40] transition-colors">
                  {book.title}
                </h4>
                <p className="text-[11px] text-[#757268] truncate mt-0.5">{book.author}</p>

                <div className="flex items-center gap-2 mt-2">
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                      book.available ? 'bg-[#E3EFE5] text-[#2C5338]' : 'bg-[#FBEAE7] text-[#933625]'
                    }`}
                  >
                    {book.available ? 'Mavjud' : 'Band'}
                  </span>
                  <span className="text-[10px] text-[#8F8B7F]">
                    {book.sold || `${book.reads || 150} o'qilgan`}
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col gap-2 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                <button
                  onClick={() => onOpenReader(book)}
                  className="p-2 bg-[#ECEAE1] hover:bg-[#E3E0D5] text-[#5A5A40] rounded-xl transition-colors cursor-pointer"
                  title="O'qish"
                >
                  <BookOpen className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onToggleSaveBook(book)}
                  className="p-2 bg-[#F2EFE8] hover:bg-[#FBEAE7] text-[#8F8B7F] hover:text-[#AD4D39] rounded-xl transition-colors cursor-pointer"
                  title="O'chirish"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
