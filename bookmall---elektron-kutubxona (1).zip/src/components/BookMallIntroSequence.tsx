import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, BookOpen, Volume2, VolumeX, RotateCcw } from 'lucide-react';

interface BookMallIntroSequenceProps {
  onComplete: () => void;
  autoPlay?: boolean;
}

interface VintageBookItem {
  id: number;
  title: string;
  author: string;
  color: string;
  borderColor: string;
  spinePattern: string;
  width: string;
  height: string;
  left: string;
  top: string;
  rotation: number;
  delayMs: number;
  leatherTexture?: string;
  goldFoil?: boolean;
  depthZ: number;
}

export const BookMallIntroSequence: React.FC<BookMallIntroSequenceProps> = ({
  onComplete,
}) => {
  // Current frame: 1 (Appear logo), 2 (Books falling & covering), 3 (Final full book stack & transition)
  const [currentFrame, setCurrentFrame] = useState<1 | 2 | 3>(1);
  const [textVisible, setTextVisible] = useState(false);
  const [booksLandedCount, setBooksLandedCount] = useState(0);
  const [isFinishing, setIsFinishing] = useState(false);

  // Vintage books dataset with authentic bindings
  const vintageBooks: VintageBookItem[] = [
    // Layer 1: Base coverage over "Book"
    {
      id: 1,
      title: "O'tkan kunlar",
      author: "A. Qodiriy",
      color: "linear-gradient(135deg, #7A1F1D, #4A0E0C)",
      borderColor: "#A33B38",
      spinePattern: "border-l-4 border-[#C88A1E]",
      width: "150px",
      height: "44px",
      left: "calc(50% - 150px)",
      top: "calc(50% - 35px)",
      rotation: -6,
      delayMs: 300,
      goldFoil: true,
      depthZ: 10,
    },
    // Layer 1: Base coverage over "Mall"
    {
      id: 2,
      title: "Boburnoma",
      author: "Z.M. Bobur",
      color: "linear-gradient(135deg, #1C4D35, #0E2E1F)",
      borderColor: "#2E7552",
      spinePattern: "border-r-4 border-[#D4A359]",
      width: "160px",
      height: "48px",
      left: "calc(50% - 10px)",
      top: "calc(50% - 28px)",
      rotation: 5,
      delayMs: 550,
      goldFoil: true,
      depthZ: 12,
    },
    // Layer 2: Center cross & overlap
    {
      id: 3,
      title: "Xamsa",
      author: "Alisher Navoiy",
      color: "linear-gradient(135deg, #1E3A5F, #0E1E33)",
      borderColor: "#3A6394",
      spinePattern: "border-l-4 border-[#E5C158]",
      width: "175px",
      height: "50px",
      left: "calc(50% - 90px)",
      top: "calc(50% - 60px)",
      rotation: 2,
      delayMs: 850,
      goldFoil: true,
      depthZ: 15,
    },
    // Layer 2: Bottom stack
    {
      id: 4,
      title: "Kecha va kunduz",
      author: "Cho'lpon",
      color: "linear-gradient(135deg, #6E4720, #3D250D)",
      borderColor: "#996A39",
      spinePattern: "border-r-4 border-[#D4A359]",
      width: "165px",
      height: "46px",
      left: "calc(50% - 130px)",
      top: "calc(50% + 5px)",
      rotation: -3,
      delayMs: 1100,
      goldFoil: true,
      depthZ: 18,
    },
    // Layer 3: Top stack covering top text edges
    {
      id: 5,
      title: "Yulduzli tunlar",
      author: "P. Qodirov",
      color: "linear-gradient(135deg, #5C2B4E, #33142B)",
      borderColor: "#8A4877",
      spinePattern: "border-l-4 border-[#E0B85E]",
      width: "155px",
      height: "42px",
      left: "calc(50% - 20px)",
      top: "calc(50% + 15px)",
      rotation: 7,
      delayMs: 1350,
      goldFoil: true,
      depthZ: 20,
    },
    // Layer 3: Crown book sealing the stack
    {
      id: 6,
      title: "Dunyoning ishlari",
      author: "O'. Hoshimov",
      color: "linear-gradient(135deg, #8A6421, #52390F)",
      borderColor: "#BFA043",
      spinePattern: "border-l-4 border-[#F3E5AB]",
      width: "145px",
      height: "42px",
      left: "calc(50% - 75px)",
      top: "calc(50% - 20px)",
      rotation: -1,
      delayMs: 1600,
      goldFoil: true,
      depthZ: 25,
    },
    // Side accents for rich full vintage pile
    {
      id: 7,
      title: "Qutadg'u bilig",
      author: "Yusuf Xos Hojib",
      color: "linear-gradient(135deg, #2D4A43, #152622)",
      borderColor: "#4A7067",
      spinePattern: "border-r-4 border-[#E5C158]",
      width: "135px",
      height: "38px",
      left: "calc(50% - 160px)",
      top: "calc(50% - 15px)",
      rotation: -12,
      delayMs: 1850,
      goldFoil: false,
      depthZ: 22,
    },
    {
      id: 8,
      title: "Shum bola",
      author: "G'. G'ulom",
      color: "linear-gradient(135deg, #8B3A2B, #531D13)",
      borderColor: "#B85B48",
      spinePattern: "border-l-4 border-[#E5C158]",
      width: "140px",
      height: "40px",
      left: "calc(50% + 10px)",
      top: "calc(50% - 50px)",
      rotation: 11,
      delayMs: 2050,
      goldFoil: false,
      depthZ: 24,
    }
  ];

  // Timeline choreography
  useEffect(() => {
    // Frame 1: Fade in text immediately
    const t1 = setTimeout(() => {
      setTextVisible(true);
    }, 200);

    // Frame 2: Start book rain after text is fully shown
    const t2 = setTimeout(() => {
      setCurrentFrame(2);
    }, 1500);

    // Track books landing count
    vintageBooks.forEach((book) => {
      setTimeout(() => {
        setBooksLandedCount((prev) => Math.min(prev + 1, vintageBooks.length));
      }, 1500 + book.delayMs);
    });

    // Frame 3: Final state with text completely covered
    const t3 = setTimeout(() => {
      setCurrentFrame(3);
    }, 3900);

    // Auto transition to main app after frame 3 displays nicely
    const t4 = setTimeout(() => {
      setIsFinishing(true);
      setTimeout(() => {
        onComplete();
      }, 600);
    }, 6200);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [onComplete]);

  const handleSkip = () => {
    setIsFinishing(true);
    setTimeout(() => {
      onComplete();
    }, 300);
  };

  return (
    <div
      id="bookmall-intro-sequence"
      className={`fixed inset-0 z-50 overflow-hidden flex flex-col justify-between select-none transition-opacity duration-500 ${
        isFinishing ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100'
      }`}
      style={{
        backgroundColor: '#F3ECE0',
        backgroundImage: `
          radial-gradient(circle at 50% 40%, rgba(255, 252, 245, 0.9) 0%, rgba(243, 236, 224, 0.8) 50%, rgba(220, 209, 191, 0.95) 100%),
          repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(160, 140, 110, 0.03) 3px, rgba(160, 140, 110, 0.03) 6px)
        `
      }}
    >
      {/* Parchment Antique Paper Texture Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-40 mix-blend-multiply bg-[radial-gradient(#8a7050_1px,transparent_1px)] [background-size:16px_16px]" />
      
      {/* Soft Vignette Border */}
      <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_90px_rgba(110,85,55,0.22)]" />

      {/* Top Bar: Progress Indicator & Skip */}
      <header className="relative z-20 w-full max-w-md mx-auto px-5 pt-6 flex items-center justify-between">
        {/* Frame Tracker Pills */}
        <div className="flex items-center gap-1.5 bg-[#E8DFC8]/80 backdrop-blur-xs px-3 py-1.5 rounded-full border border-[#D8CEB4] shadow-xs">
          <span className="text-[10px] uppercase font-bold tracking-wider text-[#756A54] mr-1">
            Intro:
          </span>
          <div
            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
              currentFrame === 1
                ? 'bg-[#C88A1E] ring-2 ring-[#C88A1E]/30 scale-110'
                : 'bg-[#C88A1E]'
            }`}
            title="Frame 1: Paydo bo'lish"
          />
          <div
            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
              currentFrame === 2
                ? 'bg-[#1E824C] ring-2 ring-[#1E824C]/30 scale-110'
                : currentFrame === 3
                ? 'bg-[#1E824C]'
                : 'bg-[#C8BFAB]'
            }`}
            title="Frame 2: Kitoblar yopilishi"
          />
          <div
            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
              currentFrame === 3
                ? 'bg-[#5A5A40] ring-2 ring-[#5A5A40]/30 scale-110'
                : 'bg-[#C8BFAB]'
            }`}
            title="Frame 3: Yakuniy ko'rinish"
          />
        </div>

        {/* Skip button */}
        <button
          id="skip-intro-btn"
          onClick={handleSkip}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#FAF8F5]/90 hover:bg-[#FFFFFF] text-[#5A5850] hover:text-[#2D2B26] text-xs font-semibold border border-[#DED6C4] shadow-xs transition-all cursor-pointer active:scale-95"
        >
          <span>O'tkazib yuborish</span>
          <ArrowRight className="w-3.5 h-3.5 text-[#8C5D19]" />
        </button>
      </header>

      {/* Main Cinematic Stage */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4">
        
        {/* Frame Title Badge (Subtle guidance) */}
        <div className="mb-8 text-center transition-all duration-500">
          {currentFrame === 1 && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FAF2E3] border border-[#E5D7BE] text-[#8C5D19] text-[11px] font-semibold tracking-wide shadow-xs animate-in fade-in duration-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>1-Kadr: Rasmiy "BookMall" logotipi</span>
            </div>
          )}
          {currentFrame === 2 && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EBF4EE] border border-[#CCE4D5] text-[#1E824C] text-[11px] font-semibold tracking-wide shadow-xs animate-in fade-in duration-300">
              <BookOpen className="w-3.5 h-3.5" />
              <span>2-Kadr: Vintage kitoblar yozuvni qoplamoqda... ({booksLandedCount}/{vintageBooks.length})</span>
            </div>
          )}
          {currentFrame === 3 && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F0EDE4] border border-[#DDD5C3] text-[#5A5A40] text-[11px] font-semibold tracking-wide shadow-xs animate-in fade-in duration-300">
              <Sparkles className="w-3.5 h-3.5 text-[#C88A1E]" />
              <span>3-Kadr: Kitoblar xazinasi tayyor</span>
            </div>
          )}
        </div>

        {/* Central Logo & Book Arena */}
        <div className="relative w-full max-w-sm h-64 flex items-center justify-center">
          
          {/* Subtle warm glow behind text */}
          <div
            className={`absolute w-72 h-36 rounded-full bg-[#E8C57D]/30 blur-2xl transition-opacity duration-1000 ${
              textVisible ? 'opacity-100' : 'opacity-0'
            }`}
          />

          {/* 1. FRAME 1: The "BookMall" Typography with Vintage Serif/Clean Hybrid Style */}
          <div
            className={`relative z-0 flex items-center justify-center tracking-tight transition-all duration-1000 transform ${
              textVisible ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-90 translate-y-4'
            }`}
          >
            <span
              className="text-6xl sm:text-7xl font-serif-book font-bold transition-colors duration-500"
              style={{
                color: '#C98B1C',
                textShadow: '0 2px 4px rgba(138, 93, 20, 0.18)',
                letterSpacing: '-0.02em',
              }}
            >
              Book
            </span>
            <span
              className="text-6xl sm:text-7xl font-serif-book font-bold transition-colors duration-500"
              style={{
                color: '#1E824C',
                textShadow: '0 2px 4px rgba(30, 130, 76, 0.18)',
                letterSpacing: '-0.02em',
              }}
            >
              Mall
            </span>
          </div>

          {/* 2. FRAME 2 & 3: The Falling Vintage Books that Cover the Text */}
          {vintageBooks.map((book, idx) => {
            const isLanded = currentFrame >= 2 && booksLandedCount > idx;

            return (
              <div
                key={book.id}
                className="absolute shadow-xl transition-all"
                style={{
                  width: book.width,
                  height: book.height,
                  left: book.left,
                  top: book.top,
                  zIndex: book.depthZ,
                  transform: isLanded
                    ? `rotate(${book.rotation}deg) scale(1) translateY(0)`
                    : `rotate(${book.rotation * 3}deg) scale(1.4) translateY(-320px)`,
                  opacity: isLanded ? 1 : 0,
                  transitionDuration: isLanded ? '550ms' : '0ms',
                  transitionTimingFunction: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
                  borderRadius: '5px',
                  background: book.color,
                  border: `1.5px solid ${book.borderColor}`,
                  boxShadow: isLanded
                    ? '0 10px 20px -5px rgba(45, 30, 15, 0.45), 0 2px 6px rgba(0,0,0,0.2)'
                    : 'none',
                }}
              >
                {/* Book Spine Details (Leather / Cloth / Gold Foil) */}
                <div className={`w-full h-full p-1.5 flex items-center justify-between text-white relative overflow-hidden ${book.spinePattern}`}>
                  
                  {/* Subtle leather ribbed spine effect */}
                  <div className="absolute inset-y-0 left-2 w-0.5 bg-black/25" />
                  <div className="absolute inset-y-0 left-3 w-0.5 bg-white/10" />

                  {/* Gold foil / embossed title */}
                  <div className="pl-3.5 pr-1 flex-1 min-w-0">
                    <p
                      className={`text-[11px] font-serif-book font-bold truncate leading-tight ${
                        book.goldFoil ? 'text-[#F3E3B6]' : 'text-white'
                      }`}
                      style={{
                        textShadow: book.goldFoil ? '0 1px 2px rgba(0,0,0,0.8)' : 'none',
                      }}
                    >
                      {book.title}
                    </p>
                    <p className="text-[9px] opacity-75 truncate text-[#E2DACB] font-mono">
                      {book.author}
                    </p>
                  </div>

                  {/* Bookmark ribbon or ornament */}
                  {book.goldFoil && (
                    <div className="w-1.5 h-full bg-[#E5C158] opacity-85 shadow-xs rounded-xs flex-shrink-0 mr-1" />
                  )}
                </div>
              </div>
            );
          })}

          {/* Particle sparkles in Frame 3 */}
          {currentFrame === 3 && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center animate-in fade-in duration-500">
              <Sparkles className="w-6 h-6 text-[#D4A359] absolute -top-4 -right-2 animate-bounce" />
              <Sparkles className="w-5 h-5 text-[#C88A1E] absolute -bottom-6 -left-4 animate-pulse" />
              <Sparkles className="w-4 h-4 text-[#1E824C] absolute top-8 -left-8 animate-spin" />
            </div>
          )}
        </div>

        {/* Frame 3 Caption & Readiness */}
        <div className="mt-8 text-center max-w-xs transition-all duration-500">
          {currentFrame === 1 && (
            <p className="text-xs text-[#7A6F5A] font-medium animate-in fade-in duration-300">
              O'zbekistonning boy adabiy merosi va zamonaviy kutubxonalari
            </p>
          )}
          {currentFrame === 2 && (
            <p className="text-xs text-[#5A5850] font-serif-book italic animate-in fade-in duration-300">
              "Kitoblar — asrlar to'lqinida suzuvchi va o'zining qimmatbaho yukini avloddan-avlodga eltuvchi fikr kemalaridir."
            </p>
          )}
          {currentFrame === 3 && (
            <div className="space-y-2 animate-in slide-in-from-bottom duration-400">
              <p className="text-sm font-bold font-serif-book text-[#2D2B26]">
                45,000+ dan ziyod kitoblar sizni kutmoqda
              </p>
              <p className="text-[11px] text-[#7A6F5A]">
                Asosiy platformaga o'tilmoqda...
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Footer Area */}
      <footer className="relative z-20 w-full max-w-md mx-auto px-5 pb-8 flex flex-col items-center gap-3">
        {/* Manual Enter Button */}
        <button
          id="enter-app-now-btn"
          onClick={handleSkip}
          className={`w-full py-3.5 px-5 rounded-2xl font-bold text-sm shadow-md transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
            currentFrame === 3
              ? 'bg-[#5A5A40] hover:bg-[#484833] text-white shadow-[#5A5A40]/30 scale-100'
              : 'bg-[#FAF8F5] hover:bg-[#F2EFE8] text-[#3D3B35] border border-[#DED6C4]'
          }`}
        >
          <span>{currentFrame === 3 ? "Ilovaga kirish" : "To'g'ridan-to'g'ri o'tish"}</span>
          <ArrowRight className="w-4 h-4 text-[#E5C158]" />
        </button>

        {/* Small copyright / theme footnote */}
        <div className="flex items-center gap-2 text-[10px] text-[#8C8370]">
          <span>Pergament & Vintage nashrlar</span>
          <span>•</span>
          <span>BookMall Raqamli Fondi</span>
        </div>
      </footer>
    </div>
  );
};
