import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  BookOpen,
  Phone,
  Mail,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  Eye,
  X,
  UserPlus,
  Loader2
} from 'lucide-react';
import { DbMember, DbLoan } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

interface AdminMembersTabProps {
  members: DbMember[];
  loans: DbLoan[];
}

export function AdminMembersTab({ members, loans }: AdminMembersTabProps) {
  const { activeLibrary, token } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMember, setSelectedMember] = useState<DbMember | null>(null);

  // New Member Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberPhone, setNewMemberPhone] = useState('+998 ');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim() || !newMemberEmail.trim() || !newMemberPhone.trim()) {
      setSubmitError("Barcha maydonlarni to'ldirish shart");
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);
    try {
      await api.members.create(
        {
          name: newMemberName.trim(),
          email: newMemberEmail.trim(),
          phone: newMemberPhone.trim(),
        },
        token
      );
      // Clean up and close modal
      setIsAddModalOpen(false);
      setNewMemberName('');
      setNewMemberEmail('');
      setNewMemberPhone('+998 ');
    } catch (err: any) {
      setSubmitError(err.message || "A'zoni ro'yxatdan o'tkazishda xatolik yuz berdi");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Members of active library
  const libraryMembers = useMemo(() => {
    return members.filter((m) => m.libraryId === activeLibrary.id);
  }, [members, activeLibrary.id]);

  // Filtered members
  const filteredMembers = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return libraryMembers;
    return libraryMembers.filter(
      (m) =>
        m.name.toLowerCase().includes(q) ||
        m.email.toLowerCase().includes(q) ||
        m.phone.toLowerCase().includes(q)
    );
  }, [libraryMembers, searchQuery]);

  // Selected member loans
  const memberLoans = useMemo(() => {
    if (!selectedMember) return [];
    return loans.filter((l) => l.memberId === selectedMember.id);
  }, [loans, selectedMember]);

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Header & Search */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-[#2D2A26] flex items-center gap-2">
              <Users className="w-5 h-5 text-[#5A5A40]" />
              <span>Kutubxona A'zolari Ro'yxati</span>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#F5F2EB] text-[#6E6A5F] border border-[#E6E1D6]">
                {libraryMembers.length} ta a'zo
              </span>
            </h2>
            <p className="text-xs text-[#827D70]">
              <b>{activeLibrary.name}</b> ga biriktirilgan kitobxonlar va ularning faolligi.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative min-w-[220px]">
              <Search className="w-4 h-4 text-[#8C8677] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Ism, email yoki telefon..."
                className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl pl-9 pr-3 py-2 text-xs text-[#2D2A26] placeholder-[#9E988A] focus:outline-none focus:border-[#5A5A40]"
              />
            </div>

            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-3.5 py-2 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <UserPlus className="w-4 h-4" />
              <span>Yangi A'zo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Members Table */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#FAF8F5] border-b border-[#ECE7DC] text-[#7A7568] font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Kitobxon</th>
                <th className="py-3 px-4">Aloqa</th>
                <th className="py-3 px-4">Ro'yxatdan O'tgan</th>
                <th className="py-3 px-4 text-center">Faol Ijaralar</th>
                <th className="py-3 px-4 text-center">Kechikkan</th>
                <th className="py-3 px-4 text-center">Jami Olingan</th>
                <th className="py-3 px-4 text-right">Tafsilot</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F2ECE1]">
              {filteredMembers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#9E988A] space-y-2">
                    <Users className="w-8 h-8 mx-auto text-[#C8C2B4]" />
                    <p className="font-semibold">A'zolar topilmadi</p>
                  </td>
                </tr>
              ) : (
                filteredMembers.map((member) => (
                  <tr key={member.id} className="hover:bg-[#FAF8F5] transition-colors">
                    {/* Member Profile */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={member.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                          alt={member.name}
                          className="w-9 h-9 rounded-xl object-cover shadow-xs border border-[#E6E1D6]"
                        />
                        <div>
                          <p className="font-bold text-[#2D2A26]">{member.name}</p>
                          <p className="text-[10px] text-[#8C8677] font-mono">ID: {member.id}</p>
                        </div>
                      </div>
                    </td>

                    {/* Contact */}
                    <td className="py-3 px-4 space-y-0.5">
                      <p className="text-[#4A473E] flex items-center gap-1.5 text-[11px]">
                        <Mail className="w-3 h-3 text-[#8C8677]" />
                        <span>{member.email}</span>
                      </p>
                      <p className="text-[#4A473E] flex items-center gap-1.5 text-[11px]">
                        <Phone className="w-3 h-3 text-[#8C8677]" />
                        <span>{member.phone}</span>
                      </p>
                    </td>

                    {/* Registered Date */}
                    <td className="py-3 px-4 text-[#696558]">
                      {new Date(member.registeredDate).toLocaleDateString('uz-UZ')}
                    </td>

                    {/* Active Loans */}
                    <td className="py-3 px-4 text-center">
                      <span className="font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full text-xs">
                        {member.activeLoansCount} ta
                      </span>
                    </td>

                    {/* Overdue */}
                    <td className="py-3 px-4 text-center">
                      {member.overdueLoansCount > 0 ? (
                        <span className="font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-full text-xs animate-pulse">
                          {member.overdueLoansCount} ta
                        </span>
                      ) : (
                        <span className="text-[#8C8677] font-bold">0</span>
                      )}
                    </td>

                    {/* Total Borrowed */}
                    <td className="py-3 px-4 text-center font-bold text-[#2D2A26]">
                      {member.totalBorrowedCount} ta
                    </td>

                    {/* Action View */}
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedMember(member)}
                        className="px-3 py-1.5 rounded-xl bg-[#5A5A40] hover:bg-[#484833] text-white text-xs font-bold transition-all shadow-xs inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Ko'rish</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Member Details Modal */}
      {selectedMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="p-5 border-b border-[#ECE7DC] flex items-center justify-between bg-white/70">
              <div className="flex items-center gap-3">
                <img
                  src={selectedMember.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                  alt={selectedMember.name}
                  className="w-12 h-12 rounded-2xl object-cover border border-[#E6E1D6]"
                />
                <div>
                  <h3 className="font-bold text-[#2D2A26] text-base">{selectedMember.name}</h3>
                  <p className="text-xs text-[#6E6A5F]">{selectedMember.email} • {selectedMember.phone}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedMember(null)}
                className="p-1.5 rounded-xl text-[#8C8677] hover:text-[#2D2A26] hover:bg-[#F2ECE1] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs flex-1">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-[#F2ECE1] p-3 rounded-2xl">
                  <span className="text-[10px] text-[#7A7568] block">Faol Kitoblari</span>
                  <span className="text-base font-bold text-blue-700">{selectedMember.activeLoansCount} ta</span>
                </div>
                <div className="bg-[#F2ECE1] p-3 rounded-2xl">
                  <span className="text-[10px] text-[#7A7568] block">Kechikkan</span>
                  <span className="text-base font-bold text-rose-700">{selectedMember.overdueLoansCount} ta</span>
                </div>
                <div className="bg-[#F2ECE1] p-3 rounded-2xl">
                  <span className="text-[10px] text-[#7A7568] block">Jami O‘qilgan</span>
                  <span className="text-base font-bold text-[#2D2A26]">{selectedMember.totalBorrowedCount} ta</span>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-[#2D2A26] mb-2 flex items-center justify-between">
                  <span>Kitobxonning Ijaralari Tarixi:</span>
                  <span className="text-[10px] text-[#8C8677]">{memberLoans.length} ta operatsiya</span>
                </h4>

                <div className="space-y-2">
                  {memberLoans.length === 0 ? (
                    <p className="text-center py-6 text-xs text-[#9E988A]">Ijaralar mavjud emas.</p>
                  ) : (
                    memberLoans.map((loan) => (
                      <div
                        key={loan.id}
                        className="p-3 rounded-2xl bg-white border border-[#ECE7DC] flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img
                            src={loan.bookCover || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=80'}
                            alt={loan.bookTitle}
                            className="w-8 h-11 object-cover rounded shadow-xs shrink-0"
                          />
                          <div className="min-w-0">
                            <p className="font-bold text-[#2D2A26] truncate">{loan.bookTitle}</p>
                            <p className="text-[10px] text-[#8C8677]">
                              Olingan: {new Date(loan.borrowedAt).toLocaleDateString('uz-UZ')} • Muddat: {new Date(loan.dueDate).toLocaleDateString('uz-UZ')}
                            </p>
                          </div>
                        </div>

                        <span
                          className={`text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full shrink-0 ${
                            loan.status === 'ACTIVE'
                              ? 'bg-blue-100 text-blue-800'
                              : loan.status === 'RETURNED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {loan.status === 'ACTIVE' ? 'Faol' : loan.status === 'RETURNED' ? 'Qaytarildi' : 'Kechikkan'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-[#ECE7DC] bg-white/70">
              <button
                onClick={() => setSelectedMember(null)}
                className="w-full py-2.5 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                Yopish
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Member Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl max-w-md w-full shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-5 border-b border-[#ECE7DC] flex items-center justify-between bg-white/70">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#5A5A40]/10 text-[#5A5A40] flex items-center justify-center">
                  <UserPlus className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-[#2D2A26] text-sm">Yangi A'zo Ro'yxatdan O'tkazish</h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-xl text-[#8C8677] hover:text-[#2D2A26] hover:bg-[#F2ECE1] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddMember} className="p-5 space-y-3.5 text-xs">
              {submitError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs">
                  {submitError}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#4B473D] mb-1">
                  Kitobxon F.I.O *
                </label>
                <input
                  type="text"
                  required
                  value={newMemberName}
                  onChange={(e) => setNewMemberName(e.target.value)}
                  placeholder="Masalan: Sardor Aliyev"
                  className="w-full bg-white border border-[#DDD5C5] rounded-xl px-3 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#4B473D] mb-1">
                  Email Manzili *
                </label>
                <input
                  type="email"
                  required
                  value={newMemberEmail}
                  onChange={(e) => setNewMemberEmail(e.target.value)}
                  placeholder="kitobxon@mail.uz"
                  className="w-full bg-white border border-[#DDD5C5] rounded-xl px-3 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#4B473D] mb-1">
                  Telefon Raqami *
                </label>
                <input
                  type="tel"
                  required
                  value={newMemberPhone}
                  onChange={(e) => setNewMemberPhone(e.target.value)}
                  placeholder="+998 90 123-45-67"
                  className="w-full bg-white border border-[#DDD5C5] rounded-xl px-3 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-white border border-[#DDD5C5] text-[#555] hover:bg-[#F2ECE1] font-bold text-xs rounded-xl cursor-pointer"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Saqlanmoqda...</span>
                    </>
                  ) : (
                    <span>A'zoni Saqlash</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
