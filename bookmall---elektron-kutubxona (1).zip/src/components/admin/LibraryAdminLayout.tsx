import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Users,
  Bookmark,
  TrendingUp,
  Settings,
  ShieldCheck,
  Building2,
  ChevronDown,
  UserCheck,
  Eye,
  LogOut,
  Bell,
  Menu,
  X,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useRealtime } from '../../context/RealtimeContext';
import { api } from '../../services/api';
import { DbBook, DbLoan, DbMember, LibraryStats } from '../../types';
import { AdminDashboardTab } from './AdminDashboardTab';
import { AdminBooksTab } from './AdminBooksTab';
import { AdminLoansTab } from './AdminLoansTab';
import { AdminMembersTab } from './AdminMembersTab';
import { AdminStatisticsTab } from './AdminStatisticsTab';
import { AdminSettingsTab } from './AdminSettingsTab';
import { SecurityAuditModal } from './SecurityAuditModal';

interface LibraryAdminLayoutProps {
  showToast: (msg: string) => void;
}

export function LibraryAdminLayout({ showToast }: LibraryAdminLayoutProps) {
  const {
    currentUser,
    activeLibrary,
    allLibraries,
    allUsers,
    switchUser,
    setActiveAppView,
    token,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'dashboard' | 'books' | 'members' | 'loans' | 'stats' | 'settings'>('dashboard');
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Loaded Data state
  const [books, setBooks] = useState<DbBook[]>([]);
  const [loans, setLoans] = useState<DbLoan[]>([]);
  const [members, setMembers] = useState<DbMember[]>([]);
  const [stats, setStats] = useState<LibraryStats>({
    totalBooks: 0,
    availableBooks: 0,
    borrowedBooks: 0,
    totalMembers: 0,
    overdueBooks: 0,
    recentBooks: [],
    recentLoans: [],
    genreDistribution: [],
  });

  const { isConnected, latestActivity, subscribe } = useRealtime();

  const fetchData = async () => {
    try {
      const [fetchedBooks, fetchedLoans, fetchedMembers, fetchedStats] = await Promise.all([
        api.books.getAll({ libraryId: activeLibrary.id }),
        api.loans.getAll(token),
        api.members.getAll(token),
        api.stats.get(token),
      ]);
      setBooks(fetchedBooks);
      setLoans(fetchedLoans);
      setMembers(fetchedMembers);
      setStats(fetchedStats);
    } catch (err) {
      console.warn("Error loading admin data:", err);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeLibrary.id, token]);

  // Real-time synchronization
  useEffect(() => {
    const unsubBookCreated = subscribe('BOOK_CREATED', (e) => {
      if (e.data.libraryId === activeLibrary.id) {
        setBooks((prev) => {
          if (prev.some((b) => b.id === e.data.book.id)) return prev;
          return [e.data.book, ...prev];
        });
        if (e.data.stats) setStats(e.data.stats);
      }
    });

    const unsubBookUpdated = subscribe('BOOK_UPDATED', (e) => {
      if (e.data.libraryId === activeLibrary.id) {
        setBooks((prev) => prev.map((b) => (b.id === e.data.book.id ? e.data.book : b)));
        if (e.data.stats) setStats(e.data.stats);
      }
    });

    const unsubBookDeleted = subscribe('BOOK_DELETED', (e) => {
      if (e.data.libraryId === activeLibrary.id) {
        setBooks((prev) => prev.filter((b) => b.id !== e.data.bookId));
        if (e.data.stats) setStats(e.data.stats);
      }
    });

    const unsubLoanCreated = subscribe('LOAN_CREATED', (e) => {
      if (e.data.libraryId === activeLibrary.id) {
        setLoans((prev) => {
          if (prev.some((l) => l.id === e.data.loan.id)) return prev;
          return [e.data.loan, ...prev];
        });
        if (e.data.book) {
          setBooks((prev) => prev.map((b) => (b.id === e.data.book.id ? e.data.book : b)));
        }
        if (e.data.stats) setStats(e.data.stats);
      }
    });

    const unsubLoanReturned = subscribe('LOAN_RETURNED', (e) => {
      if (e.data.libraryId === activeLibrary.id) {
        setLoans((prev) => prev.map((l) => (l.id === e.data.loan.id ? e.data.loan : l)));
        if (e.data.book) {
          setBooks((prev) => prev.map((b) => (b.id === e.data.book.id ? e.data.book : b)));
        }
        if (e.data.stats) setStats(e.data.stats);
      }
    });

    const unsubMemberCreated = subscribe('MEMBER_CREATED', (e) => {
      if (e.data.libraryId === activeLibrary.id) {
        setMembers((prev) => {
          if (prev.some((m) => m.id === e.data.member.id)) return prev;
          return [e.data.member, ...prev];
        });
        if (e.data.stats) setStats(e.data.stats);
      }
    });

    const unsubStatsUpdated = subscribe('STATS_UPDATED', (e) => {
      if (e.data.libraryId === activeLibrary.id) {
        setStats(e.data.stats);
      }
    });

    return () => {
      unsubBookCreated();
      unsubBookUpdated();
      unsubBookDeleted();
      unsubLoanCreated();
      unsubLoanReturned();
      unsubMemberCreated();
      unsubStatsUpdated();
    };
  }, [activeLibrary.id, subscribe]);

  interface NavItem {
    id: 'dashboard' | 'books' | 'members' | 'loans' | 'stats' | 'settings';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string | number;
  }

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'books', label: 'Kitoblar (Books)', icon: BookOpen, badge: books.length },
    { id: 'loans', label: 'Kitob berish (Loans)', icon: Bookmark, badge: loans.filter((l) => l.status === 'OVERDUE').length > 0 ? '!' : undefined },
    { id: 'members', label: "A'zolar (Members)", icon: Users, badge: members.length },
    { id: 'stats', label: 'Statistika', icon: TrendingUp },
    { id: 'settings', label: 'Kutubxona sozlamalari', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#F7F4EE] text-[#2D2A26] flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="sticky top-0 z-30 bg-[#2D2A26] text-white border-b border-[#433F39] px-4 sm:px-6 py-3 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
            className="md:hidden p-2 rounded-xl text-[#C8C2B4] hover:text-white hover:bg-[#3D3A34] transition-colors cursor-pointer"
          >
            {isMobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Brand Logo & Name */}
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#D49A3D] to-[#E06A26] flex items-center justify-center font-serif-book font-black text-white text-base shadow-sm">
              B
            </span>
            <div className="flex items-baseline">
              <span className="font-serif-book font-bold text-lg tracking-tight text-[#E8B96A]">Book</span>
              <span className="font-serif-book font-bold text-lg tracking-tight text-[#68BA7F]">Mall</span>
              <span className="ml-2 text-[10px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded-full bg-[#E8B96A]/20 text-[#F2CE8D] border border-[#E8B96A]/30">
                Admin Panel
              </span>
            </div>
          </div>
        </div>

        {/* Center / Right controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Real-time WebSocket Live Sync Badge */}
          <div
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-[#3E3B34] border border-[#524E46] text-[11px]"
            title={isConnected ? "Real-time WebSocket ulandi: barcha o'zgarishlar jonli sinxronlanadi" : "Ulanish tiklanmoqda..."}
          >
            <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span className="font-semibold text-[#E6E0D2] hidden md:inline">
              {isConnected ? 'Jonli Sinxron' : 'Ulanmoqda...'}
            </span>
          </div>

          {/* Active Library Badge */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#3E3B34] border border-[#524E46] text-xs">
            <Building2 className="w-4 h-4 text-[#E8B96A]" />
            <span className="font-semibold text-[#E6E0D2] truncate max-w-[200px]">
              {activeLibrary.name}
            </span>
          </div>

          {/* RBAC Security Test Button */}
          <button
            onClick={() => setShowSecurityModal(true)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-300 font-bold text-xs transition-all cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>RBAC Test</span>
          </button>

          {/* Quick Switch to Member View */}
          <button
            onClick={() => setActiveAppView('member')}
            className="px-3 py-1.5 rounded-xl bg-[#4A463E] hover:bg-[#5A554C] text-[#E6E0D2] font-semibold text-xs border border-[#605B52] transition-all flex items-center gap-1.5 cursor-pointer"
            title="Kitobxon interfeysiga o'tish"
          >
            <Eye className="w-3.5 h-3.5 text-[#E8B96A]" />
            <span className="hidden sm:inline">Kitobxon Ko'rinishi</span>
          </button>

          {/* User Profile & Role Switcher */}
          <div className="relative">
            <button
              onClick={() => setShowRoleDropdown(!showRoleDropdown)}
              className="flex items-center gap-2 p-1.5 pr-2.5 rounded-xl bg-[#3D3A34] hover:bg-[#48453E] border border-[#524E46] text-xs transition-all cursor-pointer"
            >
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                alt={currentUser.name}
                className="w-7 h-7 rounded-lg object-cover border border-[#666]"
              />
              <div className="text-left hidden md:block">
                <p className="font-bold text-[#FAF8F5] leading-tight text-[11px] truncate max-w-[120px]">
                  {currentUser.name}
                </p>
                <p className="text-[9px] text-[#E8B96A] font-semibold uppercase">{currentUser.role}</p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-[#A8A294]" />
            </button>

            {/* Switch User Dropdown */}
            {showRoleDropdown && (
              <div className="absolute right-0 top-full mt-2 w-72 bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl shadow-2xl p-3 z-50 text-[#2D2A26] animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="pb-2 mb-2 border-b border-[#ECE7DC]">
                  <p className="text-[10px] font-black uppercase tracking-wider text-[#8C8677]">
                    Foydalanuvchi & Rolni Almashtirish (RBAC)
                  </p>
                </div>

                <div className="space-y-1.5 max-h-60 overflow-y-auto">
                  {allUsers.map((u) => (
                    <button
                      key={u.id}
                      onClick={async () => {
                        await switchUser(u.id);
                        setShowRoleDropdown(false);
                      }}
                      className={`w-full p-2 rounded-xl text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                        currentUser.id === u.id
                          ? 'bg-[#5A5A40] text-white font-bold shadow-xs'
                          : 'hover:bg-[#F2ECE1] text-[#4A473E]'
                      }`}
                    >
                      <div className="truncate pr-2">
                        <p className="truncate font-semibold">{u.name}</p>
                        <p className={`text-[10px] ${currentUser.id === u.id ? 'text-[#E8B96A]' : 'text-[#8C8677]'}`}>
                          {u.role} • {u.libraryId}
                        </p>
                      </div>
                      {currentUser.id === u.id && (
                        <span className="w-2 h-2 rounded-full bg-[#E8B96A] shrink-0" />
                      )}
                    </button>
                  ))}
                </div>

                <div className="pt-2 mt-2 border-t border-[#ECE7DC]">
                  <button
                    onClick={() => {
                      setShowRoleDropdown(false);
                      setShowSecurityModal(true);
                    }}
                    className="w-full py-1.5 px-2 text-center text-xs font-bold text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Xavfsizlik auditini tekshirish</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Body: Sidebar + Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex flex-col w-64 bg-white border-r border-[#ECE7DC] p-4 space-y-6 shrink-0 shadow-xs">
          {/* Active Library Card */}
          <div className="bg-[#FAF8F5] border border-[#ECE7DC] rounded-2xl p-3.5 space-y-1.5">
            <span className="text-[10px] font-black uppercase text-[#8C8677] tracking-wider block">
              Boshqarilayotgan Kutubxona:
            </span>
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#5A5A40] text-white flex items-center justify-center shrink-0 shadow-xs font-bold text-xs">
                {activeLibrary.name.charAt(0)}
              </div>
              <div className="min-w-0">
                <p className="font-bold text-xs text-[#2D2A26] truncate">{activeLibrary.name}</p>
                <p className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Multi-Library Active</span>
                </p>
              </div>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1.5 flex-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#5A5A40] text-white shadow-sm'
                      : 'text-[#5C584E] hover:bg-[#FAF8F5] hover:text-[#2D2A26]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#E8B96A]' : 'text-[#8C8677]'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-black ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : item.badge === '!'
                          ? 'bg-rose-100 text-rose-800 animate-pulse'
                          : 'bg-[#F2ECE1] text-[#696558]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Bottom Card */}
          <div className="p-3.5 rounded-2xl bg-[#F2ECE1] border border-[#E2D8C6] text-xs space-y-1 text-[#555]">
            <p className="font-bold text-[#2D2A26] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>RBAC Himoyalangan</span>
            </p>
            <p className="text-[10px] text-[#7A7568]">
              Admin huquqlari server-side API orqali qat'iy nazorat qilinadi.
            </p>
          </div>
        </aside>

        {/* Mobile Slide-over Sidebar */}
        {isMobileSidebarOpen && (
          <div className="fixed inset-0 z-40 md:hidden flex">
            <div
              onClick={() => setIsMobileSidebarOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            />
            <div className="relative w-64 bg-white p-4 space-y-5 flex flex-col z-50 shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-[#ECE7DC]">
                <span className="font-bold text-sm text-[#2D2A26]">Admin Menyusi</span>
                <button
                  onClick={() => setIsMobileSidebarOpen(false)}
                  className="p-1 rounded-lg text-[#8C8677]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="space-y-1.5 flex-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id as any);
                        setIsMobileSidebarOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-bold text-xs transition-all ${
                        isActive
                          ? 'bg-[#5A5A40] text-white'
                          : 'text-[#5C584E] hover:bg-[#FAF8F5]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </div>
                      {item.badge !== undefined && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-stone-100 text-stone-700">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>

              <button
                onClick={() => {
                  setIsMobileSidebarOpen(false);
                  setActiveAppView('member');
                }}
                className="w-full py-2.5 bg-[#4A463E] text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2"
              >
                <Eye className="w-4 h-4 text-[#E8B96A]" />
                <span>Kitobxon ko'rinishiga o'tish</span>
              </button>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {activeTab === 'dashboard' && (
            <AdminDashboardTab
              stats={stats}
              onNavigateTab={(tab) => setActiveTab(tab as any)}
              onOpenAddBook={() => setActiveTab('books')}
              onOpenNewLoan={() => setActiveTab('loans')}
              onOpenSecurityModal={() => setShowSecurityModal(true)}
            />
          )}

          {activeTab === 'books' && (
            <AdminBooksTab
              books={books}
              onRefresh={fetchData}
              showToast={showToast}
            />
          )}

          {activeTab === 'loans' && (
            <AdminLoansTab
              loans={loans}
              books={books}
              members={members}
              onRefresh={fetchData}
              showToast={showToast}
            />
          )}

          {activeTab === 'members' && (
            <AdminMembersTab
              members={members}
              loans={loans}
            />
          )}

          {activeTab === 'stats' && (
            <AdminStatisticsTab
              stats={stats}
              books={books}
              loans={loans}
            />
          )}

          {activeTab === 'settings' && (
            <AdminSettingsTab
              showToast={showToast}
            />
          )}
        </main>
      </div>

      {/* Security Audit Modal */}
      {showSecurityModal && (
        <SecurityAuditModal onClose={() => setShowSecurityModal(false)} />
      )}
    </div>
  );
}
