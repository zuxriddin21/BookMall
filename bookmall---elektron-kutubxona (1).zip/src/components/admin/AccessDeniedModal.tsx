import React from 'react';
import { ShieldAlert, Lock, ArrowRight, UserCheck, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export function AccessDeniedModal() {
  const { showAccessDeniedModal, setShowAccessDeniedModal, switchUser, allUsers } = useAuth();

  if (!showAccessDeniedModal) return null;

  const adminUser = allUsers.find((u) => u.role === 'LIBRARY_ADMIN');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#FAF8F5] border border-[#E8DFC8] rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl space-y-5 text-center relative overflow-hidden">
        {/* Glow effect */}
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-red-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="w-16 h-16 rounded-2xl bg-red-100 border-2 border-red-200 text-red-600 flex items-center justify-center mx-auto shadow-inner">
          <ShieldAlert className="w-8 h-8 animate-pulse" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-50 border border-red-200 text-red-700 text-xs font-bold uppercase tracking-wider">
            <Lock className="w-3.5 h-3.5" />
            <span>403 Forbidden — Ruxsat berilmadi</span>
          </div>
          <h3 className="text-xl font-black text-[#2D2A26]">
            Kutubxona Admin Paneliga Kirish Cheklangan
          </h3>
          <p className="text-xs sm:text-sm text-[#6E6A5F] leading-relaxed">
            Siz hozirda <b className="text-[#C8523A]">MEMBER</b> (oddiy kutubxona a'zosi) sifatida tizimdasiz. 
            Xavfsizlik qoidalariga (RBAC) binoan, ushbu panelga faqat <b>LIBRARY_ADMIN</b> roli ruxsat oladi.
          </p>
        </div>

        {/* Security Info Box */}
        <div className="bg-[#F2ECE1] p-3.5 rounded-2xl text-left text-xs space-y-1.5 text-[#545045]">
          <div className="flex items-center gap-2 font-bold text-[#35322B]">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Backend RBAC himoyasi faol</span>
          </div>
          <p className="text-[11px] text-[#6E6A5F] pl-6">
            Frontend va backend API endpointlari (kitob qo'shish, o'chirish, tahrirlash) avtomatik tarzda MEMBER uchun 403 status bilan himoyalangan.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
          {adminUser && (
            <button
              onClick={async () => {
                await switchUser(adminUser.id);
                setShowAccessDeniedModal(false);
              }}
              className="flex-1 py-3 px-4 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-[#E8B96A]" />
              <span>Admin sifatida kirish</span>
            </button>
          )}

          <button
            onClick={() => setShowAccessDeniedModal(false)}
            className="py-3 px-4 bg-white border border-[#DDD5C5] text-[#4A473E] hover:bg-[#F5EFE3] font-bold text-xs rounded-xl transition-all cursor-pointer"
          >
            Tushundim, qaytish
          </button>
        </div>
      </div>
    </div>
  );
}
