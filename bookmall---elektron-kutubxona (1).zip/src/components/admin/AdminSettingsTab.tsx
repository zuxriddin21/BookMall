import React, { useState } from 'react';
import {
  Settings,
  Building2,
  Phone,
  Clock,
  MapPin,
  FileText,
  Save,
  CheckCircle2,
  ShieldCheck,
  Image as ImageIcon
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

interface AdminSettingsTabProps {
  showToast: (msg: string) => void;
}

export function AdminSettingsTab({ showToast }: AdminSettingsTabProps) {
  const { activeLibrary, updateCurrentLibrary, currentUser, token } = useAuth();

  const [name, setName] = useState(activeLibrary.name);
  const [logo, setLogo] = useState(activeLibrary.logo || '');
  const [address, setAddress] = useState(activeLibrary.address);
  const [phone, setPhone] = useState(activeLibrary.phone);
  const [workingHours, setWorkingHours] = useState(activeLibrary.workingHours);
  const [description, setDescription] = useState(activeLibrary.description);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const res = await api.libraries.update(
        activeLibrary.id,
        {
          name,
          logo,
          address,
          phone,
          workingHours,
          description,
        },
        token
      );

      updateCurrentLibrary(res.library);
      showToast("Kutubxona ma'lumotlari muvaffaqiyatli yangilandi");
    } catch (err: any) {
      showToast(err.message || "Xatolik yuz berdi");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 shadow-xs">
        <h2 className="text-lg font-bold text-[#2D2A26] flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#5A5A40]" />
          <span>Kutubxona Profili va Sozlamalari</span>
        </h2>
        <p className="text-xs text-[#827D70]">
          <b>{activeLibrary.name}</b> profilini, aloqa vositalarini va ish tartibini yangilang.
        </p>
      </div>

      {/* Multi-library Guard Info */}
      <div className="p-4 bg-[#F2ECE1] border border-[#E2D8C6] rounded-2xl flex items-start gap-3 text-xs text-[#524E43]">
        <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold text-[#2D2A26]">Multi-Library Boshqaruv Tizimi</p>
          <p className="text-[11px] text-[#696558] mt-0.5">
            Siz hozirda faqat <b>{activeLibrary.id}</b> identifikatoriga ega bo'lgan kutubxonaga mas'ul adminsiz. 
            Boshqa kutubxonalarning profili va kitoblari xavfsiz tarzda izolyatsiya qilingan.
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSave} className="bg-white border border-[#ECE7DC] rounded-3xl p-6 space-y-5 shadow-xs text-xs">
        {/* Library Name */}
        <div className="space-y-1.5">
          <label className="font-bold text-[#2D2A26] flex items-center gap-1.5">
            <Building2 className="w-4 h-4 text-[#7A7568]" />
            <span>Kutubxona Nomi *</span>
          </label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-4 py-2.5 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors"
          />
        </div>

        {/* Logo URL */}
        <div className="space-y-1.5">
          <label className="font-bold text-[#2D2A26] flex items-center gap-1.5">
            <ImageIcon className="w-4 h-4 text-[#7A7568]" />
            <span>Logotip / Rasm (URL)</span>
          </label>
          <div className="flex gap-3 items-center">
            {logo && (
              <img
                src={logo}
                alt="Logo preview"
                className="w-10 h-10 rounded-xl object-cover border border-[#E4DDD0] shrink-0"
              />
            )}
            <input
              type="url"
              value={logo}
              onChange={(e) => setLogo(e.target.value)}
              placeholder="https://..."
              className="flex-1 bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-4 py-2.5 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Phone */}
          <div className="space-y-1.5">
            <label className="font-bold text-[#2D2A26] flex items-center gap-1.5">
              <Phone className="w-4 h-4 text-[#7A7568]" />
              <span>Telefon Raqami *</span>
            </label>
            <input
              type="text"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-4 py-2.5 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors"
            />
          </div>

          {/* Working Hours */}
          <div className="space-y-1.5">
            <label className="font-bold text-[#2D2A26] flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-[#7A7568]" />
              <span>Ish Tartibi / Vaqti *</span>
            </label>
            <input
              type="text"
              required
              value={workingHours}
              onChange={(e) => setWorkingHours(e.target.value)}
              className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-4 py-2.5 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors"
            />
          </div>
        </div>

        {/* Address */}
        <div className="space-y-1.5">
          <label className="font-bold text-[#2D2A26] flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-[#7A7568]" />
            <span>Manzil *</span>
          </label>
          <input
            type="text"
            required
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-4 py-2.5 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors"
          />
        </div>

        {/* Description */}
        <div className="space-y-1.5">
          <label className="font-bold text-[#2D2A26] flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-[#7A7568]" />
            <span>Kutubxona Haqida Tavsif</span>
          </label>
          <textarea
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-4 py-2.5 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors leading-relaxed"
          />
        </div>

        {/* Save Button */}
        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 bg-[#2D7A4D] hover:bg-[#22633E] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer active:scale-95 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? "Saqlanmoqda..." : "Sozlamalarni Saqlash"}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
