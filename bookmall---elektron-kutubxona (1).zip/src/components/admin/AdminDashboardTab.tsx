import React from 'react';
import {
  BookOpen,
  CheckCircle,
  Clock,
  Users,
  AlertCircle,
  Plus,
  ArrowUpRight,
  Sparkles,
  ShieldCheck,
  Bookmark
} from 'lucide-react';
import { DbBook, DbLoan, LibraryStats } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface AdminDashboardTabProps {
  stats: LibraryStats;
  onNavigateTab: (tab: string) => void;
  onOpenAddBook: () => void;
  onOpenNewLoan: () => void;
  onOpenSecurityModal: () => void;
}

export function AdminDashboardTab({
  stats,
  onNavigateTab,
  onOpenAddBook,
  onOpenNewLoan,
  onOpenSecurityModal,
}: AdminDashboardTabProps) {
  const { activeLibrary, currentUser } = useAuth();

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#3E3B35] via-[#2A2924] to-[#1E1D19] rounded-3xl p-6 sm:p-7 text-white relative overflow-hidden shadow-lg border border-[#524E46]">
        {/* Glow & subtle decor */}
        <div className="absolute right-0 top-0 w-80 h-full bg-gradient-to-l from-[#E8B96A]/10 to-transparent pointer-events-none" />
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-[#2D7A4D]/20 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-xl">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-black tracking-wider px-2.5 py-0.5 rounded-full bg-[#E8B96A]/20 text-[#F2CE8D] border border-[#E8B96A]/30">
                {activeLibrary.name}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Admin Rejimi
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-serif-book font-bold text-[#FAF8F5]">
              Xush kelibsiz, {currentUser.name}!
            </h2>
            <p className="text-xs sm:text-sm text-[#C8C2B4] leading-relaxed">
              Kutubxona fondi, kitoblar inventarizatsiyasi, a'zolar ro'yxati va faol ijaralarni to'liq nazorat qiling.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 pt-2 md:pt-0">
            <button
              onClick={onOpenAddBook}
              className="px-4 py-2.5 bg-gradient-to-r from-[#D49A3D] to-[#E06A26] hover:from-[#BF862E] hover:to-[#C65B1D] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>+ Yangi Kitob</span>
            </button>
            <button
              onClick={onOpenNewLoan}
              className="px-4 py-2.5 bg-[#2D7A4D] hover:bg-[#24633E] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Bookmark className="w-4 h-4" />
              <span>Kitob Berish</span>
            </button>
            <button
              onClick={onOpenSecurityModal}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-[#E6E0D2] font-semibold text-xs rounded-xl border border-white/15 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>RBAC Auditi</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards (5 Major Metric Blocks specified in prompt) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5 sm:gap-4">
        {/* 1. Total Books */}
        <div
          onClick={() => onNavigateTab('books')}
          className="bg-white border border-[#ECE7DC] hover:border-[#D5CDBD] rounded-2xl p-4 space-y-2 shadow-xs transition-all hover:shadow-md cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-[#B5B0A2] group-hover:text-[#3D3B35] transition-colors" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-[#827D70] block">Jami kitoblar</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl sm:text-2xl font-black text-[#2D2A26]">{stats.totalBooks}</span>
              <span className="text-[11px] text-[#827D70]">nusxa</span>
            </div>
          </div>
        </div>

        {/* 2. Available Books */}
        <div
          onClick={() => onNavigateTab('books')}
          className="bg-white border border-[#ECE7DC] hover:border-[#D5CDBD] rounded-2xl p-4 space-y-2 shadow-xs transition-all hover:shadow-md cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <CheckCircle className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
              {stats.totalBooks > 0 ? Math.round((stats.availableBooks / stats.totalBooks) * 100) : 0}%
            </span>
          </div>
          <div>
            <span className="text-[11px] font-semibold text-[#827D70] block">Mavjud kitoblar</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl sm:text-2xl font-black text-emerald-700">{stats.availableBooks}</span>
              <span className="text-[11px] text-[#827D70]">javonda</span>
            </div>
          </div>
        </div>

        {/* 3. Borrowed Books */}
        <div
          onClick={() => onNavigateTab('loans')}
          className="bg-white border border-[#ECE7DC] hover:border-[#D5CDBD] rounded-2xl p-4 space-y-2 shadow-xs transition-all hover:shadow-md cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-[#B5B0A2] group-hover:text-[#3D3B35] transition-colors" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-[#827D70] block">Berilgan kitoblar</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl sm:text-2xl font-black text-blue-700">{stats.borrowedBooks}</span>
              <span className="text-[11px] text-[#827D70]">qo'lda</span>
            </div>
          </div>
        </div>

        {/* 4. Total Members */}
        <div
          onClick={() => onNavigateTab('members')}
          className="bg-white border border-[#ECE7DC] hover:border-[#D5CDBD] rounded-2xl p-4 space-y-2 shadow-xs transition-all hover:shadow-md cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <ArrowUpRight className="w-4 h-4 text-[#B5B0A2] group-hover:text-[#3D3B35] transition-colors" />
          </div>
          <div>
            <span className="text-[11px] font-semibold text-[#827D70] block">Jami a'zolar</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl sm:text-2xl font-black text-[#2D2A26]">{stats.totalMembers}</span>
              <span className="text-[11px] text-[#827D70]">kitobxon</span>
            </div>
          </div>
        </div>

        {/* 5. Overdue Books */}
        <div
          onClick={() => onNavigateTab('loans')}
          className={`border rounded-2xl p-4 space-y-2 shadow-xs transition-all hover:shadow-md cursor-pointer group col-span-2 sm:col-span-1 ${
            stats.overdueBooks > 0
              ? 'bg-rose-50/70 border-rose-200'
              : 'bg-white border-[#ECE7DC]'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
              stats.overdueBooks > 0 ? 'bg-rose-100 text-rose-700' : 'bg-stone-100 text-stone-600'
            }`}>
              <AlertCircle className="w-5 h-5" />
            </div>
            {stats.overdueBooks > 0 && (
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-rose-200 text-rose-800 animate-pulse">
                Diqqat
              </span>
            )}
          </div>
          <div>
            <span className="text-[11px] font-semibold text-[#827D70] block">Kechiktirilgan kitoblar</span>
            <div className="flex items-baseline gap-1.5">
              <span className={`text-xl sm:text-2xl font-black ${stats.overdueBooks > 0 ? 'text-rose-700' : 'text-[#2D2A26]'}`}>
                {stats.overdueBooks}
              </span>
              <span className="text-[11px] text-[#827D70]">ta asar</span>
            </div>
          </div>
        </div>
      </div>

      {/* Two Column Layout: So'nggi berilgan kitoblar & So'nggi qo'shilgan kitoblar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* 1. So'nggi berilgan kitoblar (Recent Loans) */}
        <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-[#2D2A26] text-sm sm:text-base">So'nggi berilgan kitoblar</h3>
              <p className="text-[11px] text-[#827D70]">Oxirgi kitob berish operatsiyalari</p>
            </div>
            <button
              onClick={() => onNavigateTab('loans')}
              className="text-xs font-bold text-[#5A5A40] hover:text-[#2D2A26] flex items-center gap-1 cursor-pointer"
            >
              <span>Barchasi</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {stats.recentLoans.length === 0 ? (
              <div className="text-center py-8 text-xs text-[#9E988A]">
                Hozircha kitob berish operatsiyalari mavjud emas.
              </div>
            ) : (
              stats.recentLoans.slice(0, 5).map((loan) => (
                <div
                  key={loan.id}
                  className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#ECE7DC] flex items-center justify-between gap-3 hover:bg-[#F5F2EC] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={loan.bookCover || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=100'}
                      alt={loan.bookTitle}
                      className="w-10 h-13 object-cover rounded-lg shadow-xs shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-[#2D2A26] truncate">{loan.bookTitle}</p>
                      <p className="text-[11px] text-[#6E6A5F] truncate">Kitobxon: <b>{loan.memberName}</b></p>
                      <p className="text-[10px] text-[#948F82]">
                        Qaytarish: {new Date(loan.dueDate).toLocaleDateString('uz-UZ')}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full whitespace-nowrap shrink-0 ${
                      loan.status === 'ACTIVE'
                        ? 'bg-blue-100 text-blue-800'
                        : loan.status === 'RETURNED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800 animate-pulse'
                    }`}
                  >
                    {loan.status === 'ACTIVE' ? 'Faol' : loan.status === 'RETURNED' ? 'Qaytarildi' : 'Kechikkan'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* 2. So'nggi qo'shilgan kitoblar (Recent Books) */}
        <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-[#2D2A26] text-sm sm:text-base">So'nggi qo'shilgan kitoblar</h3>
              <p className="text-[11px] text-[#827D70]">{activeLibrary.name} fondiga qo'shilganlar</p>
            </div>
            <button
              onClick={() => onNavigateTab('books')}
              className="text-xs font-bold text-[#5A5A40] hover:text-[#2D2A26] flex items-center gap-1 cursor-pointer"
            >
              <span>Katalog</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {stats.recentBooks.length === 0 ? (
              <div className="text-center py-8 text-xs text-[#9E988A]">
                Kutubxonaga hali kitob kiritilmagan.
              </div>
            ) : (
              stats.recentBooks.slice(0, 5).map((book) => (
                <div
                  key={book.id}
                  className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#ECE7DC] flex items-center justify-between gap-3 hover:bg-[#F5F2EC] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={book.coverImage}
                      alt={book.title}
                      className="w-10 h-13 object-cover rounded-lg shadow-xs shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-[#2D2A26] truncate">{book.title}</p>
                      <p className="text-[11px] text-[#6E6A5F] truncate">{book.author}</p>
                      <p className="text-[10px] text-[#948F82] truncate">{book.genre}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs font-black text-emerald-700">{book.availableCopies}</span>
                    <span className="text-[10px] text-[#827D70]">/{book.totalCopies} nusxa</span>
                    <p className="text-[10px] text-[#948F82] font-mono">{book.isbn.slice(0, 13)}...</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
