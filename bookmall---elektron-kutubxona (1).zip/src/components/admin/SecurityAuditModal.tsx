import React, { useState } from 'react';
import { ShieldCheck, CheckCircle2, XCircle, AlertTriangle, Play, RefreshCw, X, Lock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

interface SecurityAuditModalProps {
  onClose: () => void;
}

export function SecurityAuditModal({ onClose }: SecurityAuditModalProps) {
  const { currentUser, allUsers, switchUser } = useAuth();
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<{
    testName: string;
    description: string;
    expected: string;
    actualResult: string;
    status: 'PASSED' | 'FAILED';
  }[] | null>(null);
  const [concurrencyResult, setConcurrencyResult] = useState<any | null>(null);
  const [isTestingConcurrency, setIsTestingConcurrency] = useState(false);

  const runLiveAudit = async () => {
    setIsRunning(true);
    try {
      const data = await api.security.runTest(currentUser.token);
      setTestResults(data.tests);
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsRunning(false);
    }
  };

  const runConcurrencyTest = async () => {
    setIsTestingConcurrency(true);
    setConcurrencyResult(null);
    try {
      const res = await api.security.runConcurrencyTest(currentUser.token);
      setConcurrencyResult(res);
    } catch (err: any) {
      console.error(err);
      setConcurrencyResult({ verdict: 'FAILED', error: err.message });
    } finally {
      setIsTestingConcurrency(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-[#ECE7DC] flex items-center justify-between bg-white/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 border border-emerald-200 text-emerald-700 flex items-center justify-center">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-[#2D2A26] text-base sm:text-lg flex items-center gap-2">
                <span>RBAC & Xavfsizlik Auditi</span>
                <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Faol Tizim
                </span>
              </h3>
              <p className="text-xs text-[#7A7568]">
                Hozirgi sessiya: <b className="text-[#35322B]">{currentUser.name}</b> ({currentUser.role})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#7A7568] hover:text-[#2D2A26] hover:bg-[#F2ECE1] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Quick Role Switch for Testing */}
          <div className="bg-[#F3EFE6] border border-[#E4DDD0] rounded-2xl p-4 space-y-2.5">
            <div className="text-xs font-bold text-[#4B473D] flex items-center justify-between">
              <span>Auditor sifatida rolni almashtirish:</span>
              <span className="text-[10px] text-[#7A7568]">Bir bosishda tekshiring</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {allUsers.map((u) => (
                <button
                  key={u.id}
                  onClick={() => switchUser(u.id)}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between cursor-pointer ${
                    currentUser.id === u.id
                      ? 'bg-white border-[#5A5A40] text-[#2D2A26] font-bold shadow-xs'
                      : 'bg-white/60 border-[#E4DDD0] text-[#696558] hover:bg-white'
                  }`}
                >
                  <div className="truncate pr-2">
                    <p className="truncate font-semibold">{u.name}</p>
                    <p className="text-[10px] text-[#8C8677]">{u.role} ({u.libraryId})</p>
                  </div>
                  {currentUser.id === u.id && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* 10 Required Compliance Checklist */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-black uppercase tracking-wider text-[#696558]">
              Xavfsizlik & RBAC Talablari Nazorati:
            </h4>

            <div className="grid gap-2 text-xs">
              <div className="p-3 rounded-2xl bg-white border border-[#ECE7DC] flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-[#2D2A26]">1. MEMBER kitob qo‘sha olmasligi</p>
                  <p className="text-[11px] text-[#696558]">POST /api/books endpointida faqat LIBRARY_ADMIN roliga ruxsat beriladi. MEMBER request yuborsa 403 Forbidden qaytariladi.</p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#ECE7DC] flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-[#2D2A26]">2. MEMBER kitob o‘chira olmasligi</p>
                  <p className="text-[11px] text-[#696558]">DELETE /api/books/:id endpointi server-side RBAC bilan himoyalangan.</p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#ECE7DC] flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-[#2D2A26]">3. MEMBER kitob ma'lumotlarini o‘zgartira olmasligi</p>
                  <p className="text-[11px] text-[#696558]">PUT /api/books/:id faqat LIBRARY_ADMIN uchun ruxsat etilgan.</p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#ECE7DC] flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-[#2D2A26]">4. MEMBER admin dashboardga kira olmasligi</p>
                  <p className="text-[11px] text-[#696558]">Frontend router va viewlar qat'iy tekshiriladi, MEMBER uchun admin paneli ochilmaydi.</p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#ECE7DC] flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-[#2D2A26]">5. Multi-Library Izolyatsiyasi</p>
                  <p className="text-[11px] text-[#696558]">Kutubxona A admini Kutubxona B kitoblarini ko'ra olmaydi, tahrirlay olmaydi va o'chira olmaydi.</p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white border border-[#ECE7DC] flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-[#2D2A26]">6. A'zolar shaxsiy ma'lumotlari daxlsizligi</p>
                  <p className="text-[11px] text-[#696558]">GET /api/loans MEMBER uchun faqat uning o'ziga tegishli kitoblarni qaytaradi.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Concurrency & Race Condition Test Results */}
          {concurrencyResult && (
            <div className={`border rounded-2xl p-4 space-y-2.5 animate-in fade-in ${
              concurrencyResult.verdict === 'PASSED'
                ? 'bg-emerald-50 border-emerald-300'
                : 'bg-red-50 border-red-300'
            }`}>
              <div className="flex items-center justify-between font-bold text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-950">{concurrencyResult.title}</span>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-extrabold uppercase">
                  {concurrencyResult.verdict} ({concurrencyResult.durationMs}ms)
                </span>
              </div>

              <p className="text-xs text-emerald-900 leading-relaxed font-semibold">
                {concurrencyResult.summary}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                <div className="bg-white/90 p-2.5 rounded-xl border border-emerald-200">
                  <p className="font-bold text-[#2D2A26]">Foydalanuvchi A (Bir vaqtda):</p>
                  <p className="text-emerald-700 font-bold text-[11px] mt-0.5">{concurrencyResult.userAResult?.status}</p>
                </div>
                <div className="bg-white/90 p-2.5 rounded-xl border border-amber-200">
                  <p className="font-bold text-[#2D2A26]">Foydalanuvchi B (Bir vaqtda):</p>
                  <p className="text-red-700 font-bold text-[11px] mt-0.5">{concurrencyResult.userBResult?.status}</p>
                  <p className="text-[10px] text-red-600 font-mono mt-0.5 truncate" title={concurrencyResult.userBResult?.error}>
                    {concurrencyResult.userBResult?.error}
                  </p>
                </div>
              </div>

              <div className="text-[10px] text-emerald-800 bg-emerald-100/70 px-2.5 py-1.5 rounded-lg font-mono flex items-center justify-between">
                <span>Mexanizm: {concurrencyResult.concurrencyMechanism}</span>
                <span>Qolgan nusxa: <b>{concurrencyResult.testBook?.finalRemainingCopies}</b> ta</span>
              </div>
            </div>
          )}

          {/* Test results if executed */}
          {testResults && (
            <div className="bg-[#EBF7EE] border border-[#BCE4C6] rounded-2xl p-4 space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2 font-bold text-emerald-900 text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Jonli Server Auditi Natijalari ({testResults.length} ta test muvaffaqiyatli o'tdi):</span>
              </div>
              <div className="space-y-1.5 pt-1">
                {testResults.map((t, idx) => (
                  <div key={idx} className="text-xs bg-white/80 p-2.5 rounded-xl border border-emerald-200">
                    <div className="flex items-center justify-between font-bold text-[#2D2A26]">
                      <span>{t.testName}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 uppercase font-extrabold">
                        {t.status}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#555]">{t.description}</p>
                    <p className="text-[10px] text-emerald-700 font-mono mt-0.5">Natija: {t.actualResult}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#ECE7DC] bg-white/70 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            <button
              onClick={runLiveAudit}
              disabled={isRunning}
              className="px-3.5 py-2 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {isRunning ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Play className="w-3.5 h-3.5 text-[#E8B96A]" />
              )}
              <span>RBAC Testi</span>
            </button>

            <button
              onClick={runConcurrencyTest}
              disabled={isTestingConcurrency}
              className="px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              title="Bir vaqtning o'zida yuborilgan parallel so'rovlar (Race Condition) ni tekshirish"
            >
              {isTestingConcurrency ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Lock className="w-3.5 h-3.5 text-amber-300" />
              )}
              <span>Parallel Race Test</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-white border border-[#DDD5C5] text-[#4A473E] hover:bg-[#F5EFE3] font-bold text-xs rounded-xl transition-all cursor-pointer"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
}
