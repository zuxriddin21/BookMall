import React from 'react';
import {
  TrendingUp,
  PieChart,
  BarChart3,
  Award,
  CheckCircle,
  Clock,
  AlertTriangle,
  BookOpen,
  ArrowUpRight
} from 'lucide-react';
import { LibraryStats, DbBook, DbLoan } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface AdminStatisticsTabProps {
  stats: LibraryStats;
  books: DbBook[];
  loans: DbLoan[];
}

export function AdminStatisticsTab({ stats, books, loans }: AdminStatisticsTabProps) {
  const { activeLibrary } = useAuth();

  const libraryBooks = books.filter((b) => b.libraryId === activeLibrary.id);
  const libraryLoans = loans.filter((l) => l.libraryId === activeLibrary.id);

  const returnedCount = libraryLoans.filter((l) => l.status === 'RETURNED').length;
  const activeCount = libraryLoans.filter((l) => l.status === 'ACTIVE').length;
  const overdueCount = libraryLoans.filter((l) => l.status === 'OVERDUE').length;
  const totalLoanRecords = libraryLoans.length;

  const returnRate = totalLoanRecords > 0 ? Math.round((returnedCount / totalLoanRecords) * 100) : 100;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 shadow-xs">
        <h2 className="text-lg font-bold text-[#2D2A26] flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-[#5A5A40]" />
          <span>Kutubxona Tahlili va Statistikasi</span>
        </h2>
        <p className="text-xs text-[#827D70]">
          <b>{activeLibrary.name}</b> bo'yicha fond aylanmasi, ijaralar ko'rsatkichlari va mashhur kitoblar tahlili.
        </p>
      </div>

      {/* Summary KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* On-Time Return Rate */}
        <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#7A7568]">O'z vaqtida qaytarish darajasi</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1">
            <span className="text-3xl font-black text-emerald-700">{returnRate}%</span>
            <div className="w-full bg-[#F2ECE1] h-2 rounded-full overflow-hidden">
              <div
                className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${returnRate}%` }}
              />
            </div>
            <p className="text-[11px] text-[#8C8677] pt-1">
              Kitobxonlar kitoblarni belgilangan muddatda qaytarish intizomi.
            </p>
          </div>
        </div>

        {/* Fond Aylanmasi */}
        <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#7A7568]">Fonddan foydalanish ulushi</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1">
            <span className="text-3xl font-black text-blue-700">
              {stats.totalBooks > 0 ? Math.round((stats.borrowedBooks / stats.totalBooks) * 100) : 0}%
            </span>
            <div className="w-full bg-[#F2ECE1] h-2 rounded-full overflow-hidden">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${stats.totalBooks > 0 ? Math.round((stats.borrowedBooks / stats.totalBooks) * 100) : 0}%`,
                }}
              />
            </div>
            <p className="text-[11px] text-[#8C8677] pt-1">
              Jami {stats.totalBooks} nusxadan {stats.borrowedBooks} tasi faol o'qilmoqda.
            </p>
          </div>
        </div>

        {/* Kechikishlar */}
        <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#7A7568]">Kechiktirilgan ijaralar</span>
            <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-1">
            <span className={`text-3xl font-black ${overdueCount > 0 ? 'text-rose-700' : 'text-[#2D2A26]'}`}>
              {overdueCount} ta
            </span>
            <p className="text-[11px] text-[#8C8677] pt-1">
              Muddatidan o'tib ketgan kitoblar bo'yicha kitobxonlarga eslatma yuborilishi lozim.
            </p>
          </div>
        </div>
      </div>

      {/* Two Column Visuals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Genre Distribution */}
        <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-4 shadow-xs">
          <h3 className="font-bold text-[#2D2A26] text-sm flex items-center gap-2">
            <PieChart className="w-4 h-4 text-[#5A5A40]" />
            <span>Janrlar bo'yicha kitoblar soni</span>
          </h3>

          <div className="space-y-3 pt-1">
            {stats.genreDistribution.map((item, idx) => {
              const pct = stats.totalBooks > 0 ? Math.round((item.count / stats.totalBooks) * 100) : 0;
              return (
                <div key={idx} className="space-y-1 text-xs">
                  <div className="flex justify-between font-semibold text-[#3D3B35]">
                    <span>{item.genre}</span>
                    <span>{item.count} nusxa ({pct}%)</span>
                  </div>
                  <div className="w-full bg-[#FAF8F5] border border-[#ECE7DC] h-2.5 rounded-full overflow-hidden">
                    <div
                      className="bg-[#5A5A40] h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top Books */}
        <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-4 shadow-xs">
          <h3 className="font-bold text-[#2D2A26] text-sm flex items-center gap-2">
            <Award className="w-4 h-4 text-[#D49A3D]" />
            <span>Kutubxonadagi eng ommabop asarlar</span>
          </h3>

          <div className="space-y-2.5 pt-1">
            {libraryBooks.slice(0, 4).map((book, idx) => (
              <div
                key={book.id}
                className="p-3 rounded-2xl bg-[#FAF8F5] border border-[#ECE7DC] flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="w-6 h-6 rounded-full bg-[#ECE7DC] text-[#555] font-black text-xs flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <img
                    src={book.coverImage}
                    alt={book.title}
                    className="w-8 h-11 object-cover rounded shadow-xs shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="font-bold text-xs text-[#2D2A26] truncate">{book.title}</p>
                    <p className="text-[10px] text-[#777] truncate">{book.author}</p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-bold text-emerald-700">{book.availableCopies}</span>
                  <span className="text-[10px] text-[#8C8677]">/{book.totalCopies} nusxa</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
