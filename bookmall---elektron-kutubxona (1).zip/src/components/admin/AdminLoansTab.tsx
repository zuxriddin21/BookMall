import React, { useState, useMemo } from 'react';
import {
  Bookmark,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  Calendar,
  UserCheck,
  BookOpen,
  ArrowRight,
  X,
  RotateCcw
} from 'lucide-react';
import { DbLoan, DbBook, DbMember } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

interface AdminLoansTabProps {
  loans: DbLoan[];
  books: DbBook[];
  members: DbMember[];
  onRefresh: () => void;
  showToast: (msg: string) => void;
}

export function AdminLoansTab({
  loans,
  books,
  members,
  onRefresh,
  showToast,
}: AdminLoansTabProps) {
  const { activeLibrary, token } = useAuth();

  const [activeFilter, setActiveFilter] = useState<'ALL' | 'ACTIVE' | 'RETURNED' | 'OVERDUE'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State for Issuing Book
  const [selectedBookId, setSelectedBookId] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState('');
  const [loanDays, setLoanDays] = useState(14);

  // Available books of this library with copies > 0
  const availableBooks = useMemo(() => {
    return books.filter((b) => b.libraryId === activeLibrary.id && b.availableCopies > 0);
  }, [books, activeLibrary.id]);

  // Members of this library
  const libraryMembers = useMemo(() => {
    return members.filter((m) => m.libraryId === activeLibrary.id);
  }, [members, activeLibrary.id]);

  // Loans of this library
  const libraryLoans = useMemo(() => {
    return loans.filter((l) => l.libraryId === activeLibrary.id);
  }, [loans, activeLibrary.id]);

  // Filtered loans
  const filteredLoans = useMemo(() => {
    return libraryLoans.filter((loan) => {
      const matchesStatus = activeFilter === 'ALL' || loan.status === activeFilter;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        loan.bookTitle.toLowerCase().includes(q) ||
        loan.memberName.toLowerCase().includes(q) ||
        loan.id.toLowerCase().includes(q);
      return matchesStatus && matchesSearch;
    });
  }, [libraryLoans, activeFilter, searchQuery]);

  // Open Issue Modal
  const handleOpenIssueModal = () => {
    if (availableBooks.length > 0) setSelectedBookId(availableBooks[0].id);
    if (libraryMembers.length > 0) setSelectedMemberId(libraryMembers[0].id);
    setLoanDays(14);
    setShowIssueModal(true);
  };

  // Submit Issue Book
  const handleIssueBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBookId || !selectedMemberId) {
      showToast("Iltimos, kitob va a'zoni tanlang");
      return;
    }

    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + loanDays);

    setIsSubmitting(true);
    try {
      await api.loans.create(
        {
          bookId: selectedBookId,
          memberId: selectedMemberId,
          dueDate: dueDate.toISOString(),
        },
        token
      );
      showToast("Kitob a'zoga muvaffaqiyatli berildi");
      setShowIssueModal(false);
      onRefresh();
    } catch (err: any) {
      showToast(err.message || "Kitob berishda xatolik yuz berdi");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Return Book Action
  const handleReturnBook = async (loan: DbLoan) => {
    setIsSubmitting(true);
    try {
      await api.loans.returnLoan(loan.id, token);
      showToast(`"${loan.bookTitle}" kutubxonaga qaytarildi`);
      onRefresh();
    } catch (err: any) {
      showToast(err.message || "Kitobni qaytarishda xatolik yuz berdi");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Top Controls */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-[#2D2A26] flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-[#5A5A40]" />
              <span>Kitob Berish va Ijaralar Nazorati</span>
            </h2>
            <p className="text-xs text-[#827D70]">
              Faol ijaralar, qaytarish muddatlari va kechiktirilgan kitoblarni boshqaring.
            </p>
          </div>

          <button
            onClick={handleOpenIssueModal}
            className="px-4 py-2.5 bg-[#2D7A4D] hover:bg-[#22633E] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>+ Yangi Kitob Berish</span>
          </button>
        </div>

        {/* Status Filter Tabs & Search */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#FAF8F5] border border-[#ECE7DC] text-xs font-bold">
            {(['ALL', 'ACTIVE', 'RETURNED', 'OVERDUE'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveFilter(tab)}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  activeFilter === tab
                    ? 'bg-white text-[#2D2A26] shadow-xs border border-[#E4DDD0]'
                    : 'text-[#7A7568] hover:text-[#2D2A26]'
                }`}
              >
                {tab === 'ALL' && 'Barchasi'}
                {tab === 'ACTIVE' && 'Faol (Qo‘lda)'}
                {tab === 'RETURNED' && 'Qaytarilgan'}
                {tab === 'OVERDUE' && 'Kechikkan'}
              </button>
            ))}
          </div>

          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-[#8C8677] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Kitob yoki a'zo ismi..."
              className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl pl-9 pr-3 py-1.5 text-xs text-[#2D2A26] placeholder-[#9E988A] focus:outline-none focus:border-[#5A5A40]"
            />
          </div>
        </div>
      </div>

      {/* Loans Table */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#FAF8F5] border-b border-[#ECE7DC] text-[#7A7568] font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Kitob</th>
                <th className="py-3 px-4">Kitobxon (A'zo)</th>
                <th className="py-3 px-4">Berilgan Sana</th>
                <th className="py-3 px-4">Qaytarish Muddati</th>
                <th className="py-3 px-4">Qaytarilgan Sana</th>
                <th className="py-3 px-4 text-center">Holat</th>
                <th className="py-3 px-4 text-right">Amal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F2ECE1]">
              {filteredLoans.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#9E988A] space-y-2">
                    <Clock className="w-8 h-8 mx-auto text-[#C8C2B4]" />
                    <p className="font-semibold">Ijaralar topilmadi</p>
                    <p className="text-[11px]">Hozircha ushbu toifada kitob berish yozuvlari mavjud emas.</p>
                  </td>
                </tr>
              ) : (
                filteredLoans.map((loan) => {
                  const isOverdue = loan.status === 'OVERDUE';
                  const isActive = loan.status === 'ACTIVE';
                  const isReturned = loan.status === 'RETURNED';

                  return (
                    <tr key={loan.id} className="hover:bg-[#FAF8F5] transition-colors">
                      {/* Book */}
                      <td className="py-2.5 px-4 max-w-[200px]">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={loan.bookCover || 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=80'}
                            alt={loan.bookTitle}
                            className="w-8 h-11 object-cover rounded-md shadow-xs shrink-0"
                          />
                          <div className="min-w-0">
                            <p className="font-bold text-[#2D2A26] truncate">{loan.bookTitle}</p>
                            {loan.bookAuthor && (
                              <p className="text-[10px] text-[#8C8677] truncate">{loan.bookAuthor}</p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Member */}
                      <td className="py-2.5 px-4 max-w-[160px]">
                        <p className="font-bold text-[#2D2A26] truncate">{loan.memberName}</p>
                        <p className="text-[10px] text-[#8C8677] truncate">{loan.memberPhone || loan.memberEmail}</p>
                      </td>

                      {/* Borrowed At */}
                      <td className="py-2.5 px-4 text-[#696558]">
                        {new Date(loan.borrowedAt).toLocaleDateString('uz-UZ')}
                      </td>

                      {/* Due Date */}
                      <td className="py-2.5 px-4 font-semibold">
                        <span className={isOverdue ? 'text-rose-600 font-bold' : 'text-[#2D2A26]'}>
                          {new Date(loan.dueDate).toLocaleDateString('uz-UZ')}
                        </span>
                      </td>

                      {/* Returned At */}
                      <td className="py-2.5 px-4 text-[#8C8677]">
                        {loan.returnedAt ? new Date(loan.returnedAt).toLocaleDateString('uz-UZ') : '—'}
                      </td>

                      {/* Status Badge */}
                      <td className="py-2.5 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-blue-100 text-blue-800'
                              : isReturned
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800 animate-pulse'
                          }`}
                        >
                          {isActive && <Clock className="w-3 h-3" />}
                          {isReturned && <CheckCircle2 className="w-3 h-3" />}
                          {isOverdue && <AlertCircle className="w-3 h-3" />}
                          <span>
                            {isActive ? 'Faol' : isReturned ? 'Qaytarildi' : 'Kechikkan'}
                          </span>
                        </span>
                      </td>

                      {/* Action */}
                      <td className="py-2.5 px-4 text-right">
                        {(isActive || isOverdue) ? (
                          <button
                            onClick={() => handleReturnBook(loan)}
                            disabled={isSubmitting}
                            className="px-2.5 py-1 bg-[#5A5A40] hover:bg-[#484833] text-white text-[11px] font-bold rounded-lg shadow-xs transition-all inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                          >
                            <RotateCcw className="w-3 h-3 text-[#E8B96A]" />
                            <span>Qaytarildi</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-emerald-700 font-bold">Topshirilgan</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Issue Book Modal */}
      {showIssueModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#ECE7DC] pb-3">
              <h3 className="font-bold text-[#2D2A26] text-base flex items-center gap-2">
                <Bookmark className="w-5 h-5 text-[#2D7A4D]" />
                <span>Kitobxon a'zoga kitob berish</span>
              </h3>
              <button
                onClick={() => setShowIssueModal(false)}
                className="p-1 rounded-lg text-[#8C8677] hover:text-[#2D2A26] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleIssueBook} className="space-y-3.5 text-xs">
              {/* Select Member */}
              <div className="space-y-1">
                <label className="font-bold text-[#3E3B35]">Kutubxona a'zosi *</label>
                <select
                  required
                  value={selectedMemberId}
                  onChange={(e) => setSelectedMemberId(e.target.value)}
                  className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] cursor-pointer"
                >
                  {libraryMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.phone})
                    </option>
                  ))}
                </select>
              </div>

              {/* Select Book */}
              <div className="space-y-1">
                <label className="font-bold text-[#3E3B35]">Kitobni tanlang *</label>
                <select
                  required
                  value={selectedBookId}
                  onChange={(e) => setSelectedBookId(e.target.value)}
                  className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] cursor-pointer"
                >
                  {availableBooks.length === 0 ? (
                    <option disabled>Mavjud kitoblar qolmagan</option>
                  ) : (
                    availableBooks.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.title} — {b.author} ({b.availableCopies} ta nusxa mavjud)
                      </option>
                    ))
                  )}
                </select>
              </div>

              {/* Duration / Due Date Preset */}
              <div className="space-y-1.5">
                <label className="font-bold text-[#3E3B35]">Qaytarish muddati:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[7, 14, 30].map((days) => (
                    <button
                      type="button"
                      key={days}
                      onClick={() => setLoanDays(days)}
                      className={`py-2 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                        loanDays === days
                          ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                          : 'bg-white border-[#E4DDD0] text-[#696558] hover:bg-[#FAF8F5]'
                      }`}
                    >
                      {days} kun
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-[#7A7568] pt-1">
                  Muddati: <b>{new Date(Date.now() + loanDays * 24 * 60 * 60 * 1000).toLocaleDateString('uz-UZ')}</b> gacha
                </p>
              </div>

              <div className="p-3 bg-[#F2ECE1] rounded-2xl text-[11px] text-[#555] space-y-1">
                <p className="font-bold text-[#333]">Izoh:</p>
                <p>Kitob berilgach, fonddagi mavjud nusxalar soni avtomatik 1 taga kamayadi. Qaytarilganda esa qayta tiklanadi.</p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowIssueModal(false)}
                  className="flex-1 py-2.5 bg-white border border-[#DDD5C5] text-[#4A473E] font-bold text-xs rounded-xl hover:bg-[#F5EFE3] transition-colors cursor-pointer"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || availableBooks.length === 0}
                  className="flex-1 py-2.5 bg-[#2D7A4D] hover:bg-[#22633E] text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? "Berilmoqda..." : "Kitobni Berish"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
