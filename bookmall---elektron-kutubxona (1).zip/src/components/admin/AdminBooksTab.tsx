import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Filter,
  Eye,
  Edit,
  Trash2,
  BookOpen,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Upload,
  X,
  Sparkles,
  ShieldAlert
} from 'lucide-react';
import { DbBook } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';

interface AdminBooksTabProps {
  books: DbBook[];
  onRefresh: () => void;
  showToast: (msg: string) => void;
}

export function AdminBooksTab({ books, onRefresh, showToast }: AdminBooksTabProps) {
  const { activeLibrary, currentUser, token } = useAuth();

  // Search and filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');
  const [selectedAvailability, setSelectedAvailability] = useState<'all' | 'available' | 'out_of_stock'>('all');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingBook, setEditingBook] = useState<DbBook | null>(null);
  const [viewingBook, setViewingBook] = useState<DbBook | null>(null);
  const [deletingBook, setDeletingBook] = useState<DbBook | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formAuthor, setFormAuthor] = useState('');
  const [formGenre, setFormGenre] = useState('Badiiy adabiyot');
  const [formPublisher, setFormPublisher] = useState('');
  const [formPublishedYear, setFormPublishedYear] = useState<number | string>(2023);
  const [formIsbn, setFormIsbn] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formCoverImage, setFormCoverImage] = useState('');
  const [formTotalCopies, setFormTotalCopies] = useState<number>(10);
  const [formAvailableCopies, setFormAvailableCopies] = useState<number>(10);

  // Multi-library enforcement: only books of active library
  const libraryBooks = useMemo(() => {
    return books.filter((b) => b.libraryId === activeLibrary.id);
  }, [books, activeLibrary.id]);

  // Filtered books
  const filteredBooks = useMemo(() => {
    return libraryBooks.filter((book) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        book.title.toLowerCase().includes(q) ||
        book.author.toLowerCase().includes(q) ||
        book.genre.toLowerCase().includes(q) ||
        book.isbn.toLowerCase().includes(q);

      const matchesGenre = selectedGenre === 'all' || book.genre.toLowerCase().includes(selectedGenre.toLowerCase());

      const matchesAvailability =
        selectedAvailability === 'all' ||
        (selectedAvailability === 'available' && book.availableCopies > 0) ||
        (selectedAvailability === 'out_of_stock' && book.availableCopies === 0);

      return matchesSearch && matchesGenre && matchesAvailability;
    });
  }, [libraryBooks, searchQuery, selectedGenre, selectedAvailability]);

  // Unique genres for filter
  const allGenres = useMemo(() => {
    const set = new Set<string>();
    libraryBooks.forEach((b) => {
      b.genre.split(',').forEach((g) => set.add(g.trim()));
    });
    return Array.from(set);
  }, [libraryBooks]);

  const openAddModal = () => {
    setEditingBook(null);
    setFormTitle('');
    setFormAuthor('');
    setFormGenre('Badiiy adabiyot');
    setFormPublisher('BookMall Nashriyot');
    setFormPublishedYear(2023);
    setFormIsbn(`978-9943-${Math.floor(100 + Math.random() * 900)}-${Math.floor(10 + Math.random() * 90)}-${Math.floor(1 + Math.random() * 9)}`);
    setFormDescription('');
    setFormCoverImage('https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&auto=format&fit=crop&q=80');
    setFormTotalCopies(10);
    setFormAvailableCopies(10);
    setShowAddModal(true);
  };

  const openEditModal = (book: DbBook) => {
    setEditingBook(book);
    setFormTitle(book.title);
    setFormAuthor(book.author);
    setFormGenre(book.genre);
    setFormPublisher(book.publisher);
    setFormPublishedYear(book.publishedYear);
    setFormIsbn(book.isbn);
    setFormDescription(book.description);
    setFormCoverImage(book.coverImage);
    setFormTotalCopies(book.totalCopies);
    setFormAvailableCopies(book.availableCopies);
    setShowAddModal(true);
  };

  const handleSaveBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formAuthor) {
      showToast("Iltimos, kitob nomi va muallifini kiriting");
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingBook) {
        // Update
        await api.books.update(
          editingBook.id,
          {
            title: formTitle,
            author: formAuthor,
            genre: formGenre,
            publisher: formPublisher,
            publishedYear: formPublishedYear,
            isbn: formIsbn,
            description: formDescription,
            coverImage: formCoverImage,
            totalCopies: Number(formTotalCopies),
            availableCopies: Number(formAvailableCopies),
          },
          token
        );
        showToast(`"${formTitle}" kitobi tahrirlandi`);
      } else {
        // Create
        await api.books.create(
          {
            libraryId: activeLibrary.id,
            title: formTitle,
            author: formAuthor,
            genre: formGenre,
            publisher: formPublisher,
            publishedYear: formPublishedYear,
            isbn: formIsbn,
            description: formDescription,
            coverImage: formCoverImage,
            totalCopies: Number(formTotalCopies),
            availableCopies: Number(formAvailableCopies),
          },
          token
        );
        showToast(`"${formTitle}" yangi kitob sifatida qo'shildi`);
      }

      setShowAddModal(false);
      onRefresh();
    } catch (err: any) {
      showToast(err.message || "Xatolik yuz berdi");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteBook = async () => {
    if (!deletingBook) return;
    setIsSubmitting(true);
    try {
      await api.books.delete(deletingBook.id, token);
      showToast(`"${deletingBook.title}" o'chirildi`);
      setDeletingBook(null);
      onRefresh();
    } catch (err: any) {
      showToast(err.message || "Kitobni o'chirishda xatolik yuz berdi");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Top Controls Bar */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl p-5 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-[#2D2A26] flex items-center gap-2">
              <span>Kitoblar Boshqaruvi</span>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#F5F2EB] text-[#6E6A5F] border border-[#E6E1D6]">
                {libraryBooks.length} ta kitob
              </span>
            </h2>
            <p className="text-xs text-[#827D70]">
              <b>{activeLibrary.name}</b> kutubxonasi fondidagi barcha asarlar ro'yxati (Multi-Library izolyatsiyasi)
            </p>
          </div>

          <button
            id="admin-add-book-btn"
            onClick={openAddModal}
            className="px-4 py-2.5 bg-[#2D7A4D] hover:bg-[#22633E] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>+ Yangi Kitob Qo'shish</span>
          </button>
        </div>

        {/* Search & Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-1">
          {/* Search by Title, Author, Genre, ISBN */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-[#8C8677] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Nomi, muallifi, janri yoki ISBN bo'yicha qidiring..."
              className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl pl-9.5 pr-4 py-2 text-xs text-[#2D2A26] placeholder-[#9E988A] focus:outline-none focus:border-[#5A5A40] transition-colors"
            />
          </div>

          {/* Genre Filter */}
          <div className="sm:col-span-3">
            <select
              value={selectedGenre}
              onChange={(e) => setSelectedGenre(e.target.value)}
              className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-3 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors cursor-pointer"
            >
              <option value="all">Barcha Janrlar</option>
              {allGenres.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          {/* Availability Filter */}
          <div className="sm:col-span-3">
            <select
              value={selectedAvailability}
              onChange={(e) => setSelectedAvailability(e.target.value as any)}
              className="w-full bg-[#FAF8F5] border border-[#E4DDD0] rounded-xl px-3 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40] transition-colors cursor-pointer"
            >
              <option value="all">Barcha Holatlar</option>
              <option value="available">Mavjud (Javonda)</option>
              <option value="out_of_stock">Tugagan (0 nusxa)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Books Table View matching exact user specification */}
      <div className="bg-white border border-[#ECE7DC] rounded-3xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#FAF8F5] border-b border-[#ECE7DC] text-[#7A7568] font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">Muqova</th>
                <th className="py-3 px-4">Kitob Nomi</th>
                <th className="py-3 px-4">Muallif</th>
                <th className="py-3 px-4">Janr</th>
                <th className="py-3 px-4">ISBN</th>
                <th className="py-3 px-4 text-center">Nusxalar</th>
                <th className="py-3 px-4 text-center">Mavjud</th>
                <th className="py-3 px-4 text-center">Holat</th>
                <th className="py-3 px-4 text-right">Amallar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F2ECE1]">
              {filteredBooks.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-[#9E988A] space-y-2">
                    <BookOpen className="w-8 h-8 mx-auto text-[#C8C2B4]" />
                    <p className="font-semibold">Kitoblar topilmadi</p>
                    <p className="text-[11px]">Qidiruv mezonlarini o'zgartiring yoki yangi kitob qo'shing.</p>
                  </td>
                </tr>
              ) : (
                filteredBooks.map((book) => {
                  const isAvailable = book.availableCopies > 0;
                  return (
                    <tr key={book.id} className="hover:bg-[#FAF8F5] transition-colors">
                      {/* Cover */}
                      <td className="py-2.5 px-4">
                        <img
                          src={book.coverImage}
                          alt={book.title}
                          className="w-9 h-12 object-cover rounded-lg shadow-xs border border-[#E6E1D6]"
                        />
                      </td>

                      {/* Title */}
                      <td className="py-2.5 px-4 max-w-[200px]">
                        <p className="font-bold text-[#2D2A26] truncate">{book.title}</p>
                        <p className="text-[10px] text-[#8C8677] truncate">{book.publisher}, {book.publishedYear}</p>
                      </td>

                      {/* Author */}
                      <td className="py-2.5 px-4 font-medium text-[#4A473E] truncate max-w-[140px]">
                        {book.author}
                      </td>

                      {/* Genre */}
                      <td className="py-2.5 px-4 text-[#696558] truncate max-w-[140px]">
                        {book.genre}
                      </td>

                      {/* ISBN */}
                      <td className="py-2.5 px-4 font-mono text-[10px] text-[#8C8677]">
                        {book.isbn}
                      </td>

                      {/* Total Copies */}
                      <td className="py-2.5 px-4 text-center font-bold text-[#2D2A26]">
                        {book.totalCopies}
                      </td>

                      {/* Available Copies */}
                      <td className="py-2.5 px-4 text-center">
                        <span className={`font-black ${isAvailable ? 'text-emerald-700' : 'text-rose-600'}`}>
                          {book.availableCopies}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="py-2.5 px-4 text-center">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                            isAvailable
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isAvailable ? 'bg-emerald-600' : 'bg-rose-600'}`} />
                          {isAvailable ? 'Mavjud' : 'Tugagan'}
                        </span>
                      </td>

                      {/* Actions: View, Edit, Delete */}
                      <td className="py-2.5 px-4 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => setViewingBook(book)}
                            className="p-1.5 rounded-lg text-[#6E6A5F] hover:text-[#2D2A26] hover:bg-[#F2ECE1] transition-colors cursor-pointer"
                            title="Ko'rish"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => openEditModal(book)}
                            className="p-1.5 rounded-lg text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors cursor-pointer"
                            title="Tahrirlash"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeletingBook(book)}
                            className="p-1.5 rounded-lg text-rose-600 hover:text-rose-800 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="O'chirish"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Book Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="p-5 border-b border-[#ECE7DC] flex items-center justify-between bg-white/70">
              <h3 className="font-bold text-[#2D2A26] text-base flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#5A5A40]" />
                <span>{editingBook ? "Kitob ma'lumotlarini tahrirlash" : "Yangi kitob qo'shish"}</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-xl text-[#8C8677] hover:text-[#2D2A26] hover:bg-[#F2ECE1] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBook} className="p-5 overflow-y-auto space-y-3.5 text-xs flex-1">
              <div className="space-y-1">
                <label className="font-bold text-[#3E3B35]">Kitob Nomi *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="Masalan: Alkimyogar"
                  className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-[#3E3B35]">Muallifi *</label>
                  <input
                    type="text"
                    required
                    value={formAuthor}
                    onChange={(e) => setFormAuthor(e.target.value)}
                    placeholder="Masalan: Paulo Coelho"
                    className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-[#3E3B35]">Janri *</label>
                  <input
                    type="text"
                    required
                    value={formGenre}
                    onChange={(e) => setFormGenre(e.target.value)}
                    placeholder="Badiiy, Falsafa, IT..."
                    className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-[#3E3B35]">Nashriyot</label>
                  <input
                    type="text"
                    value={formPublisher}
                    onChange={(e) => setFormPublisher(e.target.value)}
                    placeholder="Sharq, Yangi Asr..."
                    className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-[#3E3B35]">Nashr Yili</label>
                  <input
                    type="number"
                    value={formPublishedYear}
                    onChange={(e) => setFormPublishedYear(e.target.value)}
                    placeholder="2023"
                    className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-[#3E3B35]">ISBN</label>
                  <input
                    type="text"
                    value={formIsbn}
                    onChange={(e) => setFormIsbn(e.target.value)}
                    placeholder="978-..."
                    className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-[#3E3B35]">Jami Nusxalar Soni</label>
                  <input
                    type="number"
                    min="1"
                    value={formTotalCopies}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setFormTotalCopies(val);
                      if (val < formAvailableCopies) setFormAvailableCopies(val);
                    }}
                    className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                  />
                </div>
                <div className="space-y-1">
                  <label className="font-bold text-[#3E3B35]">Mavjud Nusxalar Soni</label>
                  <input
                    type="number"
                    min="0"
                    max={formTotalCopies}
                    value={formAvailableCopies}
                    onChange={(e) => setFormAvailableCopies(Number(e.target.value))}
                    className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-[#3E3B35]">Kitob Rasmi (URL)</label>
                <input
                  type="url"
                  value={formCoverImage}
                  onChange={(e) => setFormCoverImage(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-[#3E3B35]">Kitob Tavsifi</label>
                <textarea
                  rows={3}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Kitobning qisqacha mazmuni va annotatsiyasi..."
                  className="w-full bg-white border border-[#E4DDD0] rounded-xl px-3.5 py-2 text-xs text-[#2D2A26] focus:outline-none focus:border-[#5A5A40]"
                />
              </div>

              <div className="p-4 border-t border-[#ECE7DC] bg-white/60 -mx-5 -mb-5 mt-4 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-white border border-[#DDD5C5] text-[#4A473E] font-bold text-xs rounded-xl hover:bg-[#F5EFE3] transition-colors cursor-pointer"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-[#2D7A4D] hover:bg-[#22633E] text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? "Saqlanmoqda..." : editingBook ? "O'zgarishlarni Saqlash" : "Kitobni Qo'shish"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingBook && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] border border-rose-200 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-base font-black text-[#2D2A26]">Kitobni o'chirishni tasdiqlaysizmi?</h3>
              <p className="text-xs text-[#6E6A5F] mt-1">
                <b>"{deletingBook.title}"</b> kitobi {activeLibrary.name} fondidan o'chiriladi.
              </p>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setDeletingBook(null)}
                className="flex-1 py-2.5 bg-white border border-[#DDD5C5] text-[#4A473E] font-bold text-xs rounded-xl hover:bg-[#F5EFE3] transition-colors cursor-pointer"
              >
                Bekor qilish
              </button>
              <button
                onClick={handleDeleteBook}
                disabled={isSubmitting}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? "O'chirilmoqda..." : "Ha, o'chirilsin"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Book Modal */}
      {viewingBook && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-start gap-4">
              <img
                src={viewingBook.coverImage}
                alt={viewingBook.title}
                className="w-20 h-28 object-cover rounded-xl shadow-md shrink-0 border border-[#E4DDD0]"
              />
              <div className="space-y-1 min-w-0">
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-[#ECE7DC] text-[#555]">
                  {viewingBook.genre}
                </span>
                <h3 className="font-bold text-base text-[#2D2A26] leading-snug">{viewingBook.title}</h3>
                <p className="text-xs text-[#6E6A5F] font-medium">{viewingBook.author}</p>
                <p className="text-[11px] text-[#8C8677] font-mono">ISBN: {viewingBook.isbn}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-[#F2ECE1] p-3 rounded-2xl text-xs">
              <div>
                <span className="text-[#8C8677] text-[10px]">Nashriyot:</span>
                <p className="font-bold text-[#2D2A26]">{viewingBook.publisher} ({viewingBook.publishedYear})</p>
              </div>
              <div>
                <span className="text-[#8C8677] text-[10px]">Nusxalar:</span>
                <p className="font-bold text-[#2D2A26]">{viewingBook.availableCopies} ta mavjud / {viewingBook.totalCopies} jami</p>
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <span className="font-bold text-[#3E3B35]">Tavsif:</span>
              <p className="text-[#6E6A5F] leading-relaxed max-h-32 overflow-y-auto">
                {viewingBook.description || "Tavsif kiritilmagan."}
              </p>
            </div>

            <button
              onClick={() => setViewingBook(null)}
              className="w-full py-2.5 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
            >
              Yopish
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
