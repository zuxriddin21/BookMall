import React, { useState } from 'react';
import {
  X,
  Star,
  Bookmark,
  Share2,
  BookOpen,
  Volume2,
  Calendar,
  Layers,
  Globe,
  Building,
  CheckCircle2,
  Clock,
  ThumbsUp,
  MessageSquare,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { Book, LibraryItem, UserReview } from '../types';

interface BookDetailModalProps {
  book: Book | null;
  activeLibrary: LibraryItem;
  isSaved: boolean;
  onClose: () => void;
  onToggleSave: (book: Book) => void;
  onOpenReader: (book: Book) => void;
  onOpenAudio: (book: Book) => void;
  onOpenBorrow: (book: Book) => void;
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({
  book,
  activeLibrary,
  isSaved,
  onClose,
  onToggleSave,
  onOpenReader,
  onOpenAudio,
  onOpenBorrow,
}) => {
  const [activeTab, setActiveTab] = useState<'about' | 'details' | 'reviews'>('about');
  const [copied, setCopied] = useState(false);
  const [reviews, setReviews] = useState<UserReview[]>([
    {
      id: 'r-1',
      bookTitle: book?.title || '',
      userName: 'Azizbek Rahimov',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      rating: 5,
      comment: "Juda ajoyib kitob! Har bir sahifasida ibratli fikrlar bor. Barcha kitobxonlarga tavsiya qilaman.",
      date: "3 kun oldin"
    },
    {
      id: 'r-2',
      bookTitle: book?.title || '',
      userName: 'Nilufar Qosimova',
      userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
      rating: 5,
      comment: "Kutubxonadan olib o'qigan edim, judayam yoqdi. Qayta-qayta mutolaa qilsa bo'ladigan asar.",
      date: "1 hafta oldin"
    }
  ]);
  const [newComment, setNewComment] = useState('');
  const [userRating, setUserRating] = useState(5);

  if (!book) return null;

  const handleShare = () => {
    navigator.clipboard?.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const newRev: UserReview = {
      id: `rev-${Date.now()}`,
      bookTitle: book.title,
      userName: 'Siz (Kitobxon)',
      userAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
      rating: userRating,
      comment: newComment,
      date: 'Hozirgina'
    };
    setReviews([newRev, ...reviews]);
    setNewComment('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="book-detail-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full sm:max-w-lg md:max-w-xl max-h-[90vh] sm:max-h-[85vh] rounded-t-3xl sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6]"
      >
        {/* Top Header Controls */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#EAE5DA] bg-[#F2EFE8]/70">
          <div className="flex items-center gap-2">
            <span
              className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                book.available
                  ? 'bg-[#E3EFE5] text-[#2C5338] border border-[#C5DEC9]'
                  : 'bg-[#FBEAE7] text-[#933625] border border-[#F2C7BE]'
              }`}
            >
              {book.available ? '● Kutubxonada mavjud' : '○ Hozirda band qilingan'}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              id="share-book-btn"
              onClick={handleShare}
              className="p-2 text-[#757268] hover:text-[#2D2B26] rounded-full hover:bg-[#EAE5DA] transition-colors cursor-pointer"
              title="Ulashish"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              id="save-book-detail-btn"
              onClick={() => onToggleSave(book)}
              className={`p-2 rounded-full transition-colors cursor-pointer ${
                isSaved
                  ? 'text-[#D49A3D] bg-[#FAF2E3]'
                  : 'text-[#757268] hover:text-[#2D2B26] hover:bg-[#EAE5DA]'
              }`}
              title={isSaved ? "Saqlanganlardan chiqarish" : "Saqlab qo'yish"}
            >
              <Bookmark className="w-4 h-4" fill={isSaved ? 'currentColor' : 'none'} />
            </button>
            <button
              id="close-book-detail-btn"
              onClick={onClose}
              className="p-2 text-[#757268] hover:text-[#2D2B26] rounded-full hover:bg-[#EAE5DA] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="overflow-y-auto custom-scrollbar flex-1 p-5 space-y-6">
          {/* Main Book Overview Row */}
          <div className="flex gap-4 sm:gap-6 items-start">
            {/* Book Cover */}
            <div className="w-28 sm:w-36 aspect-[3/4.4] flex-shrink-0 rounded-xl overflow-hidden shadow-md relative bg-[#EFECE3]">
              <div
                className="w-full h-full flex flex-col justify-between p-2.5 relative"
                style={{
                  background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
                    ? book.cover
                    : `url(${book.cover}) center/cover no-repeat`,
                }}
              >
                <div className="absolute top-0 left-0 bottom-0 w-2.5 bg-gradient-to-r from-black/25 via-white/10 to-transparent pointer-events-none" />
                <div className="my-auto text-center px-1">
                  <p className={`font-serif-book text-xs font-bold line-clamp-3 ${book.light ? 'text-[#2D2B26]' : 'text-white'}`}>
                    {book.title}
                  </p>
                  <p className={`text-[9px] mt-1 line-clamp-1 opacity-80 ${book.light ? 'text-[#4A473D]' : 'text-[#FAF6EE]'}`}>
                    {book.author}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Details */}
            <div className="flex-1 flex flex-col justify-between min-h-[140px]">
              <div>
                <span className="text-[11px] font-semibold text-[#5A5A40] uppercase tracking-wider">
                  {book.genre || 'Adabiyot'}
                </span>
                <h2 className="font-serif-book text-lg sm:text-xl font-bold text-[#2D2B26] mt-0.5 leading-tight">
                  {book.title}
                </h2>
                <p className="text-xs sm:text-sm text-[#757268] font-medium mt-1">
                  {book.author}
                </p>
              </div>

              {/* Rating and Reads pills */}
              <div className="flex flex-wrap items-center gap-2 mt-3">
                <div className="flex items-center gap-1 bg-[#FAF2E3] border border-[#E6D4B4] px-2 py-1 rounded-lg text-xs font-bold text-[#8C5D19]">
                  <Star className="w-3.5 h-3.5 fill-[#D49A3D] text-[#D49A3D]" />
                  <span>{book.rating}</span>
                </div>
                <div className="text-xs font-medium text-[#615E54] bg-[#EFECE3] px-2 py-1 rounded-lg">
                  {book.sold || `${book.reads || 250} o'qilgan`}
                </div>
              </div>

              {/* Action Buttons for Reader & Audio */}
              <div className="flex items-center gap-2 mt-3">
                <button
                  id="open-reader-sample-btn"
                  onClick={() => onOpenReader(book)}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-[#ECEAE1] hover:bg-[#E3E0D5] text-[#5A5A40] text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Namuna o'qish</span>
                </button>
                <button
                  id="open-audio-sample-btn"
                  onClick={() => onOpenAudio(book)}
                  className="flex items-center justify-center gap-1 py-2 px-3 bg-[#FAF2E3] hover:bg-[#F3E7CF] text-[#8C5D19] text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                  title="Ovozli tinglash"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Audio</span>
                </button>
              </div>
            </div>
          </div>

          {copied && (
            <div className="p-2.5 bg-[#E3EFE5] text-[#2C5338] border border-[#C5DEC9] rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#3F6146]" />
              <span>Havola nusxalandi! Do'stlaringizga ulashing.</span>
            </div>
          )}

          {/* Library Connection Card */}
          <div className="bg-[#FAF6EE] border border-[#E6DDCA] rounded-xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#5A5A40] text-white flex items-center justify-center shadow-xs">
                <Building className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[11px] text-[#757268] font-medium">Saqlanayotgan kutubxona:</p>
                <p className="text-xs font-bold text-[#3D3B35]">{activeLibrary.name}</p>
              </div>
            </div>
            <span className="text-[11px] font-semibold text-[#5A5A40] bg-[#ECEAE1] px-2 py-1 rounded-md">
              Andijon
            </span>
          </div>

          {/* Tabs: Tavsif, Ma'lumotlar, Fikrlar */}
          <div>
            <div className="flex border-b border-[#EAE5DA]">
              <button
                onClick={() => setActiveTab('about')}
                className={`py-2 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'about'
                    ? 'border-[#5A5A40] text-[#5A5A40]'
                    : 'border-transparent text-[#757268] hover:text-[#3D3B35]'
                }`}
              >
                Kitob tavsifi
              </button>
              <button
                onClick={() => setActiveTab('details')}
                className={`py-2 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'details'
                    ? 'border-[#5A5A40] text-[#5A5A40]'
                    : 'border-transparent text-[#757268] hover:text-[#3D3B35]'
                }`}
              >
                Xususiyatlar
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`py-2 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'reviews'
                    ? 'border-[#5A5A40] text-[#5A5A40]'
                    : 'border-transparent text-[#757268] hover:text-[#3D3B35]'
                }`}
              >
                Fikrlar ({reviews.length})
              </button>
            </div>

            <div className="pt-3">
              {activeTab === 'about' && (
                <div className="space-y-3">
                  <p className="text-xs sm:text-sm text-[#4A473D] leading-relaxed">
                    {book.description ||
                      "Ushbu asar o'quvchini hayotning teran qirralari, insoniy munosabatlar va ma'naviy kamolot sari yo'naltiruvchi sara adabiyot namunasi hisoblanadi. Kitobxonlar orasida yuqori baholangan bo'lib, kutubxonamiz fondining faxri hisoblanadi."}
                  </p>

                  <div className="bg-[#FAF2E3]/80 border border-[#E8DFC8] rounded-xl p-3 flex items-start gap-2.5">
                    <Sparkles className="w-4 h-4 text-[#D49A3D] flex-shrink-0 mt-0.5" />
                    <div>
                      <h5 className="text-xs font-bold text-[#8C5D19]">Kitobxon tavsiyasi</h5>
                      <p className="text-[11px] text-[#785419] mt-0.5">
                        Kitobni o'qish o'rtacha 4-6 soat vaqt oladi. Talabalar va kitob ixlosmandlari uchun tavsiya etiladi.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'details' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-[#F2EFE8] p-2.5 rounded-lg border border-[#E6E1D6]">
                    <span className="text-[#8F8B7F] block text-[10px]">Sahifalar soni</span>
                    <span className="font-semibold text-[#3D3B35]">{book.pages || 240} bet</span>
                  </div>
                  <div className="bg-[#F2EFE8] p-2.5 rounded-lg border border-[#E6E1D6]">
                    <span className="text-[#8F8B7F] block text-[10px]">Nashr yili</span>
                    <span className="font-semibold text-[#3D3B35]">{book.year || '2021'}</span>
                  </div>
                  <div className="bg-[#F2EFE8] p-2.5 rounded-lg border border-[#E6E1D6]">
                    <span className="text-[#8F8B7F] block text-[10px]">Tili</span>
                    <span className="font-semibold text-[#3D3B35]">{book.language || "O'zbekcha"}</span>
                  </div>
                  <div className="bg-[#F2EFE8] p-2.5 rounded-lg border border-[#E6E1D6]">
                    <span className="text-[#8F8B7F] block text-[10px]">Formati</span>
                    <span className="font-semibold text-[#3D3B35]">Qattiq muqova / ePub</span>
                  </div>
                  <div className="bg-[#F2EFE8] p-2.5 rounded-lg border border-[#E6E1D6] col-span-2">
                    <span className="text-[#8F8B7F] block text-[10px]">Kutubxona inventar raqami</span>
                    <span className="font-mono font-semibold text-[#3D3B35]">INV-UZ-{book.id.toUpperCase()}-2024</span>
                  </div>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-4">
                  {/* Write a comment */}
                  <form onSubmit={handleAddReview} className="bg-[#F2EFE8] p-3 rounded-xl border border-[#E6E1D6]">
                    <p className="text-xs font-semibold text-[#3D3B35] mb-1.5">Fikringizni qoldiring:</p>
                    <div className="flex items-center gap-1 mb-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setUserRating(star)}
                          className="p-0.5 focus:outline-none cursor-pointer"
                        >
                          <Star
                            className={`w-4 h-4 ${
                              star <= userRating
                                ? 'fill-[#D49A3D] text-[#D49A3D]'
                                : 'text-[#C9C4B6]'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                    <textarea
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Kitob haqida taassurotlaringiz..."
                      className="w-full text-xs p-2.5 bg-[#FAF8F5] border border-[#E6E1D6] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5A5A40] resize-none h-16 text-[#3D3B35] placeholder-[#9B978C]"
                    />
                    <div className="flex justify-end mt-2">
                      <button
                        type="submit"
                        disabled={!newComment.trim()}
                        className="px-3 py-1.5 bg-[#5A5A40] hover:bg-[#484833] disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Yuborish
                      </button>
                    </div>
                  </form>

                  {/* Reviews List */}
                  <div className="space-y-3">
                    {reviews.map((rev) => (
                      <div key={rev.id} className="p-3 bg-[#FAF8F5] border border-[#EAE5DA] rounded-xl space-y-1.5 shadow-xs">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <img
                              src={rev.userAvatar}
                              alt={rev.userName}
                              className="w-6 h-6 rounded-full object-cover"
                            />
                            <span className="text-xs font-bold text-[#3D3B35]">{rev.userName}</span>
                          </div>
                          <div className="flex items-center gap-0.5">
                            {Array.from({ length: rev.rating }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-[#D49A3D] text-[#D49A3D]" />
                            ))}
                          </div>
                        </div>
                        <p className="text-xs text-[#5A5850]">{rev.comment}</p>
                        <span className="text-[10px] text-[#8F8B7F] block">{rev.date}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Bottom Bar: Borrow / Band qilish */}
        <div className="p-4 border-t border-[#EAE5DA] bg-[#FAF8F5] flex items-center gap-3">
          <div className="flex-1">
            <span className="text-[10px] text-[#8F8B7F] block">Kutubxona xizmati</span>
            <span className="text-xs font-bold text-[#3D3B35]">
              {book.available ? "Bepul ijaraga beriladi" : "Navbatga yozilish mumkin"}
            </span>
          </div>

          <button
            id="borrow-main-action-btn"
            onClick={() => onOpenBorrow(book)}
            className={`px-5 py-3 rounded-xl font-bold text-xs sm:text-sm shadow-md transition-all duration-200 cursor-pointer flex items-center gap-2 ${
              book.available
                ? 'bg-[#5A5A40] hover:bg-[#484833] text-white shadow-[#5A5A40]/20 active:scale-95'
                : 'bg-[#D49A3D] hover:bg-[#BF872E] text-white shadow-[#D49A3D]/20 active:scale-95'
            }`}
          >
            {book.available ? (
              <>
                <BookOpen className="w-4 h-4" />
                <span>Kitobni band qilish</span>
              </>
            ) : (
              <>
                <Clock className="w-4 h-4" />
                <span>Navbatga yozilish</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
