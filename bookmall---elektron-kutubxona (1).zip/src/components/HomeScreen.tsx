import React from 'react';
import {
  Bell,
  Landmark,
  Search,
  Bookmark,
  HandCoins,
  ChevronRight,
  Sparkles,
  BookOpen,
  TrendingUp,
  Layers,
  ArrowRight,
  Info
} from 'lucide-react';
import { Book, StoreItem, LibraryItem, DonationCampaign } from '../types';
import { StoryCircle } from './StoryCircle';
import { BookCard } from './BookCard';
import { MostReadCard } from './MostReadCard';
import { CatalogBookCard } from './CatalogBookCard';
import { CATALOG_SECTIONS, MAIN_FEATURED_BOOKS, NEW_ARRIVAL_HERO_BOOKS, STORES_DATA } from '../data/bookData';
import bookmallLogoImg from '../assets/images/bookmall_logo_1788418721778.jpg';

interface HomeScreenProps {
  activeLibrary: LibraryItem;
  unreadNotifsCount: number;
  donationCampaign: DonationCampaign;
  savedBookIds: string[];
  onOpenNotifications: () => void;
  onOpenLibrarySwitcher: () => void;
  onOpenLibraryInfo: (lib: LibraryItem) => void;
  onOpenDonationModal: () => void;
  onOpenEnteredBooksModal: () => void;
  onSelectStore: (store: StoreItem) => void;
  onSelectBook: (book: Book) => void;
  onToggleSaveBook: (book: Book) => void;
  onQuickReadBook: (book: Book) => void;
  onNavigateToSearch: (query?: string) => void;
  onOpenWelcomeSplash?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  activeLibrary,
  unreadNotifsCount,
  donationCampaign,
  savedBookIds,
  onOpenNotifications,
  onOpenLibrarySwitcher,
  onOpenLibraryInfo,
  onOpenDonationModal,
  onOpenEnteredBooksModal,
  onSelectStore,
  onSelectBook,
  onToggleSaveBook,
  onQuickReadBook,
  onNavigateToSearch,
  onOpenWelcomeSplash,
}) => {
  const percentRaised = Math.min(100, Math.round((donationCampaign.raised / donationCampaign.goal) * 100));

  return (
    <div className="space-y-6 pb-24 pt-1">
      {/* 1. Partner Bookstores & Libraries Stories Circles */}
      <div>
        <div className="flex gap-4 overflow-x-auto scrollbar-hide py-1 px-0.5 -mx-1">
          {STORES_DATA.map((store) => (
            <StoryCircle key={store.id} store={store} onClick={onSelectStore} />
          ))}
        </div>
      </div>

      {/* 3. Library Literature Overview Card */}
      <div
        className="rounded-3xl p-5 sm:p-6 text-white shadow-lg relative overflow-hidden transition-transform duration-300"
        style={{ background: activeLibrary.gradient }}
      >
        {/* Background decorative circles */}
        <div className="absolute -right-8 -bottom-8 w-40 h-40 rounded-full bg-white/5 pointer-events-none" />
        <div className="absolute right-12 -top-6 w-24 h-24 rounded-full bg-white/5 pointer-events-none" />

        <div className="relative z-10 flex flex-col justify-between h-full space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
                <Landmark className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-serif-book text-base sm:text-lg font-bold">{activeLibrary.name}</h3>
                <p className="text-[11px] opacity-80">Viloyat universal ilmiy kutubxonasi</p>
              </div>
            </div>

            <button
              onClick={() => onOpenLibraryInfo(activeLibrary)}
              className="text-[11px] font-semibold bg-white/15 hover:bg-white/25 px-2.5 py-1 rounded-full backdrop-blur-md border border-white/20 transition-colors cursor-pointer"
            >
              Ma'lumot
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="bg-black/25 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
              <span className="text-[10px] font-medium opacity-80 block">Kutubxona fondi</span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-xl sm:text-2xl font-black text-white">
                  {activeLibrary.totalLiterature.toLocaleString()}
                </span>
                <span className="text-[10px] opacity-75">nusxa</span>
              </div>
            </div>

            <div
              onClick={onOpenEnteredBooksModal}
              className="bg-white/15 backdrop-blur-xs rounded-2xl p-3 border border-white/25 cursor-pointer hover:bg-white/25 transition-colors group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-white block">Kiritilgan kitoblar</span>
                <ArrowRight className="w-3 h-3 text-white transform group-hover:translate-x-1 transition-transform" />
              </div>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="text-xl sm:text-2xl font-black text-[#E8B96A]">
                  {activeLibrary.enteredBooks}
                </span>
                <span className="text-[10px] text-[#F3DEB8]">ta kitob</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Donation Campaign Widget */}
      <div className="bg-gradient-to-br from-[#F0FDF4] via-[#FFFBEB] to-[#ECFDF5] border-2 border-[#10B981]/60 rounded-3xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md shadow-emerald-600/10 relative overflow-hidden">
        {/* Subtle decorative dollar glow */}
        <div className="absolute -right-8 -top-8 w-28 h-28 bg-[#10B981]/15 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -left-8 -bottom-8 w-24 h-24 bg-[#059669]/10 rounded-full blur-lg pointer-events-none" />
        <div className="flex items-start gap-3.5 flex-1 min-w-0 relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#059669] via-[#10B981] to-[#047857] text-white flex items-center justify-center flex-shrink-0 shadow-lg shadow-emerald-600/30">
            <HandCoins className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0 space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[10.5px] uppercase font-extrabold text-[#047857] bg-[#ECFDF5] px-2.5 py-0.5 rounded-full border border-[#A7F3D0] shadow-xs flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
                Xayriya loyihasi
              </span>
              <span className="text-xs font-bold text-[#1C1917] truncate">
                {donationCampaign.bookTitle}
              </span>
            </div>
            <p className="text-xs text-[#2D3A31]">
              Kutubxonamiz fondiga <b>{donationCampaign.copiesNeeded} ta yangi nusxa</b> xarid qilish uchun mablag' yig'ilmoqda.
            </p>

            {/* Mini Progress */}
            <div className="flex items-center gap-3 pt-1">
              <div className="flex-1 bg-white/90 border border-emerald-200/90 h-2.5 rounded-full overflow-hidden shadow-inner">
                <div
                  className="bg-gradient-to-r from-[#10B981] via-[#059669] to-[#047857] h-full rounded-full transition-all duration-500"
                  style={{ width: `${percentRaised}%` }}
                />
              </div>
              <span className="text-xs font-black text-[#047857]">{percentRaised}%</span>
            </div>
          </div>
        </div>

        <button
          id="donate-btn-home"
          onClick={onOpenDonationModal}
          className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-[#047857] via-[#059669] to-[#10B981] hover:from-[#065F46] hover:to-[#047857] text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-700/25 transition-all cursor-pointer flex items-center justify-center gap-1.5 whitespace-nowrap active:scale-95 relative z-10"
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
          <span>Donatsiya qilish</span>
        </button>
      </div>

      {/* 5. Most Read Books Section (Horizontal Slider) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#ECEAE1] text-[#5A5A40] flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-[#3D3B35]">Ko'p o'qilgan kitoblar</h3>
              <p className="text-[11px] text-[#757268]">Kitobxonlar tanlovi bo'yicha TOP asarlar</p>
            </div>
          </div>
          <button
            onClick={() => onNavigateToSearch()}
            className="text-xs font-semibold text-[#5A5A40] hover:underline"
          >
            Barchasi →
          </button>
        </div>

        <div className="flex gap-3.5 overflow-x-auto scrollbar-hide py-1 -mx-1 px-1">
          {MAIN_FEATURED_BOOKS.map((book, idx) => (
            <MostReadCard
              key={book.id}
              book={book}
              rank={idx + 1}
              onSelect={onSelectBook}
              isSaved={savedBookIds.includes(book.id)}
              onToggleSave={(b, e) => {
                e.stopPropagation();
                onToggleSaveBook(b);
              }}
            />
          ))}
        </div>
      </div>

      {/* 6. New Arrival Books Showcase */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#EAF1EC] text-[#2C5338] flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-[#3D3B35]">Yangi kelgan kitoblar</h3>
              <p className="text-[11px] text-[#757268]">Fondimizga yaqinda qabul qilingan adabiyotlar</p>
            </div>
          </div>
          <button
            onClick={() => onNavigateToSearch('Yangi')}
            className="text-xs font-semibold text-[#5A5A40] hover:underline"
          >
            Barchasi →
          </button>
        </div>

        <div className="flex gap-3.5 overflow-x-auto scrollbar-hide py-1 -mx-1 px-1">
          {NEW_ARRIVAL_HERO_BOOKS.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              onSelect={onSelectBook}
              isSaved={savedBookIds.includes(book.id)}
              onToggleSave={(b, e) => {
                e.stopPropagation();
                onToggleSaveBook(b);
              }}
              onQuickRead={(b, e) => {
                e.stopPropagation();
                onQuickReadBook(b);
              }}
            />
          ))}
        </div>
      </div>

      {/* 7. Catalog Sections */}
      {CATALOG_SECTIONS.map((section, secIdx) => (
        <div key={secIdx} className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg">{section.icon}</span>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-[#3D3B35] leading-tight">
                  {section.title}
                </h3>
                <p className="text-[10px] text-[#757268]">
                  Jami {section.items.length} ta sara asarlar to'plami
                </p>
              </div>
            </div>
            <button
              onClick={() => onNavigateToSearch(section.title.split(' ')[0])}
              className="text-xs font-semibold text-[#5A5A40] hover:underline whitespace-nowrap"
            >
              Ko'rish →
            </button>
          </div>

          <div className="flex gap-3.5 overflow-x-auto scrollbar-hide py-1 -mx-1 px-1">
            {section.items.slice(0, 8).map((book) => {
              const fullBook: Book = {
                id: book.id,
                title: book.title,
                author: book.author,
                rating: (4.6 + ((book.reads || 100) % 5) * 0.08).toFixed(1),
                sold: `${book.reads} o'qilgan`,
                reads: book.reads,
                cover: book.cover,
                light: !!book.light,
                available: book.available !== undefined ? book.available : true,
                genre: book.genre,
                description: book.description,
              };

              return (
                <CatalogBookCard
                  key={book.id}
                  book={fullBook}
                  onSelect={onSelectBook}
                  isSaved={savedBookIds.includes(book.id)}
                  onToggleSave={(b, e) => {
                    e.stopPropagation();
                    onToggleSaveBook(b);
                  }}
                />
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};
