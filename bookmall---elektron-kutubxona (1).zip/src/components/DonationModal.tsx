import React, { useState } from 'react';
import { X, HandCoins, Heart, CheckCircle2, Sparkles, CreditCard, Shield, Users } from 'lucide-react';
import confetti from 'canvas-confetti';
import { DonationCampaign } from '../types';

interface DonationModalProps {
  campaign: DonationCampaign;
  onClose: () => void;
  onDonateSuccess: (amount: number) => void;
}

export const DonationModal: React.FC<DonationModalProps> = ({
  campaign,
  onClose,
  onDonateSuccess,
}) => {
  const [selectedAmount, setSelectedAmount] = useState<number>(25000);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [paymentProvider, setPaymentProvider] = useState<'payme' | 'click' | 'uzum'>('payme');
  const [isSuccess, setIsSuccess] = useState(false);

  const presetAmounts = [10000, 25000, 50000, 100000];

  const handleSelectPreset = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmount('');
  };

  const handleCustomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '');
    setCustomAmount(val);
    if (val) {
      setSelectedAmount(Number(val));
    }
  };

  const handleDonate = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAmount = customAmount ? Number(customAmount) : selectedAmount;
    if (!finalAmount || finalAmount < 1000) return;

    setIsSuccess(true);
    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 },
    });

    setTimeout(() => {
      onDonateSuccess(finalAmount);
      onClose();
    }, 2000);
  };

  const percentRaised = Math.min(100, Math.round((campaign.raised / campaign.goal) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="donation-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#EAE5DA] bg-[#FAF2E3]/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#F3E7CF] text-[#8C5D19] flex items-center justify-center">
              <Heart className="w-4 h-4 fill-[#D49A3D] text-[#D49A3D]" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#3D3B35]">Kitob donatsiyasi</h3>
              <p className="text-[11px] text-[#757268]">Kutubxona fondini birgalikda boyitamiz</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8F8B7F] hover:text-[#2D2B26] hover:bg-[#EAE5DA] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 flex flex-col items-center text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#E3EFE5] text-[#2C5338] flex items-center justify-center animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-lg font-bold text-[#3D3B35]">Katta rahmat!</h3>
            <p className="text-xs text-[#757268] max-w-xs">
              Sizning <b>{selectedAmount.toLocaleString()} so'm</b>lik ehsoningiz yangi kitoblar sotib olishga yo'naltirildi.
            </p>
            <div className="bg-[#FAF2E3] border border-[#E8DFC8] rounded-xl p-3 text-xs text-[#8C5D19] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#D49A3D] flex-shrink-0" />
              <span>Siz kitobxonlik harakatining faol homiysiga aylandingiz!</span>
            </div>
          </div>
        ) : (
          <form onSubmit={handleDonate} className="p-5 space-y-4">
            {/* Campaign info */}
            <div className="bg-[#F2EFE8] border border-[#E6E1D6] rounded-xl p-3 space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#8C5D19] bg-[#FAF2E3] px-1.5 py-0.5 rounded">
                    Loyiha maqsadi
                  </span>
                  <h4 className="text-xs font-bold text-[#3D3B35] mt-1">{campaign.bookTitle}</h4>
                  <p className="text-[11px] text-[#757268]">{campaign.library} uchun {campaign.copiesNeeded} nusxa</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-[#5A5A40]">{percentRaised}%</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-[#E3E0D5] h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-[#D49A3D] to-[#5A5A40] h-full rounded-full transition-all duration-500"
                  style={{ width: `${percentRaised}%` }}
                />
              </div>

              <div className="flex justify-between text-[10px] text-[#757268] pt-0.5">
                <span>Yig'ildi: <b>{campaign.raised.toLocaleString()} so'm</b></span>
                <span>Maqsad: <b>{campaign.goal.toLocaleString()} so'm</b></span>
              </div>
            </div>

            {/* Donation Amounts */}
            <div>
              <label className="block text-xs font-semibold text-[#3D3B35] mb-2">
                Ehson miqdorini tanlang:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {presetAmounts.map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => handleSelectPreset(amt)}
                    className={`py-2.5 px-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      selectedAmount === amt && !customAmount
                        ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-md shadow-[#5A5A40]/20 scale-102'
                        : 'bg-[#F2EFE8] text-[#3D3B35] border-[#E6E1D6] hover:bg-[#EAE5DA]'
                    }`}
                  >
                    {amt.toLocaleString()} so'm
                  </button>
                ))}
              </div>

              {/* Custom amount input */}
              <div className="mt-2.5">
                <input
                  type="text"
                  placeholder="Boshqa miqdor (so'm)..."
                  value={customAmount}
                  onChange={handleCustomChange}
                  className="w-full text-xs p-2.5 bg-[#FAF8F5] border border-[#E6E1D6] rounded-xl focus:ring-2 focus:ring-[#5A5A40] focus:outline-none text-[#3D3B35] placeholder-[#9B978C]"
                />
              </div>
            </div>

            {/* Payment provider tabs */}
            <div>
              <label className="block text-xs font-semibold text-[#3D3B35] mb-1.5 flex items-center gap-1">
                <CreditCard className="w-3.5 h-3.5 text-[#757268]" />
                To'lov tizimi
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['payme', 'click', 'uzum'] as const).map((prov) => (
                  <button
                    key={prov}
                    type="button"
                    onClick={() => setPaymentProvider(prov)}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border capitalize transition-all cursor-pointer ${
                      paymentProvider === prov
                        ? 'bg-[#3D3B35] text-white border-[#3D3B35] shadow-xs'
                        : 'bg-[#F2EFE8] text-[#3D3B35] border-[#E6E1D6] hover:bg-[#EAE5DA]'
                    }`}
                  >
                    {prov === 'payme' ? 'Payme' : prov === 'click' ? 'Click' : 'Uzum Pay'}
                  </button>
                ))}
              </div>
            </div>

            {/* Safety badge */}
            <div className="flex items-center gap-2 text-[10px] text-[#757268] pt-1">
              <Shield className="w-3.5 h-3.5 text-[#2C5338]" />
              <span>Barcha mablag'lar shaffof tarzda kitob xaridiga sarflanadi.</span>
            </div>

            {/* Submit button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-[#5A5A40]/25 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98"
              >
                <Heart className="w-4 h-4 fill-white" />
                <span>{selectedAmount.toLocaleString()} so'm ehson qilish</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
