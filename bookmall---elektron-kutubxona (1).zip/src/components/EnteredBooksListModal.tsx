import React, { useState } from 'react';
import { X, Search, BookOpen, Star, Bookmark, Filter } from 'lucide-react';
import { Book, LibraryItem } from '../types';

interface EnteredBooksListModalProps {
  library: LibraryItem;
  books: Book[];
  savedBookIds: string[];
  onSelectBook: (book: Book) => void;
  onToggleSave: (book: Book) => void;
  onClose: () => void;
}

export const EnteredBooksListModal: React.FC<EnteredBooksListModalProps> = ({
  library,
  books,
  savedBookIds,
  onSelectBook,
  onToggleSave,
  onClose,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('all');

  const genres = ['all', "Kutubxona fondi", "Yangi kelgan", "Bestseller", "Roman", "Biznes"];

  const filteredBooks = books.filter((b) => {
    const matchesSearch =
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre =
      selectedGenre === 'all' ||
      (b.genre && b.genre.toLowerCase().includes(selectedGenre.toLowerCase())) ||
      (b.category && b.category.toLowerCase().includes(selectedGenre.toLowerCase()));
    return matchesSearch && matchesGenre;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="entered-books-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full h-full sm:h-[88vh] sm:max-w-2xl sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6]"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#EAE5DA] flex items-center justify-between bg-[#F2EFE8]/80">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#5A5A40] tracking-wider">
              {library.name}
            </span>
            <h2 className="text-sm sm:text-base font-bold text-[#3D3B35]">
              Kiritilgan kitoblar ({library.enteredBooks} ta)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8F8B7F] hover:text-[#2D2B26] hover:bg-[#EAE5DA] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 border-b border-[#EAE5DA] bg-[#FAF8F5] space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-[#8F8B7F] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Kitob nomi yoki muallif bo'yicha qidiruv..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-[#F2EFE8] border border-[#E6E1D6] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#5A5A40] text-[#3D3B35] placeholder-[#9B978C]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8F8B7F] hover:text-[#3D3B35] cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Genre Chips */}
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-1">
            {genres.map((g) => (
              <button
                key={g}
                onClick={() => setSelectedGenre(g)}
                className={`text-[11px] font-semibold px-3 py-1 rounded-full whitespace-nowrap transition-colors cursor-pointer ${
                  selectedGenre === g
                    ? 'bg-[#5A5A40] text-white shadow-xs'
                    : 'bg-[#EFECE3] text-[#5A5850] hover:bg-[#E6E1D6]'
                }`}
              >
                {g === 'all' ? 'Barchasi' : g}
              </button>
            ))}
          </div>
        </div>

        {/* Books Grid */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
          {filteredBooks.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-center">
              <BookOpen className="w-10 h-10 text-[#8F8B7F]/60 mb-2" />
              <p className="text-xs text-[#757268]">Hech qanday kitob topilmadi</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {filteredBooks.map((book) => {
                const isSaved = savedBookIds.includes(book.id);
                return (
                  <div
                    key={book.id}
                    onClick={() => onSelectBook(book)}
                    className="p-2 bg-[#F2EFE8] border border-[#E6E1D6] rounded-xl hover:border-[#5A5A40]/50 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                  >
                    <div className="relative aspect-[3/4.2] rounded-lg overflow-hidden mb-2 bg-[#EFECE3]">
                      <div
                        className="w-full h-full flex flex-col justify-between p-2 relative"
                        style={{
                          background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
                            ? book.cover
                            : `url(${book.cover}) center/cover no-repeat`,
                        }}
                      >
                        <div className="flex justify-between items-start z-10">
                          <span
                            className={`text-[8px] font-bold px-1.5 py-0.5 rounded ${
                              book.available ? 'bg-[#2C5338] text-white' : 'bg-[#933625] text-white'
                            }`}
                          >
                            {book.available ? 'Mavjud' : 'Band'}
                          </span>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onToggleSave(book);
                            }}
                            className={`p-1 rounded-full cursor-pointer ${
                              isSaved ? 'bg-[#D49A3D] text-white' : 'bg-black/30 text-white/80'
                            }`}
                          >
                            <Bookmark className="w-3 h-3" fill={isSaved ? 'currentColor' : 'none'} />
                          </button>
                        </div>

                        <div className="text-center my-auto px-1 z-10">
                          <p className={`font-serif-book text-[10px] font-bold line-clamp-2 ${book.light ? 'text-[#2D2B26]' : 'text-white'}`}>
                            {book.title}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-[11px] font-bold text-[#3D3B35] line-clamp-1 group-hover:text-[#5A5A40]">
                        {book.title}
                      </h4>
                      <p className="text-[10px] text-[#757268] line-clamp-1">{book.author}</p>
                      <div className="flex items-center justify-between mt-1 text-[9px] text-[#8F8B7F]">
                        <span className="flex items-center gap-0.5 text-[#8C5D19] font-bold">
                          <Star className="w-2.5 h-2.5 fill-[#D49A3D] text-[#D49A3D]" />
                          {book.rating}
                        </span>
                        <span>{book.sold || `${book.reads || 100} o'qildi`}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
