import React from 'react';
import { X, Check, SlidersHorizontal, ArrowUpDown } from 'lucide-react';

interface FilterModalProps {
  selectedGenre: string;
  onSelectGenre: (genre: string) => void;
  selectedAvailability: 'all' | 'available' | 'borrowed';
  onSelectAvailability: (val: 'all' | 'available' | 'borrowed') => void;
  sortBy: 'popular' | 'rating' | 'newest' | 'alphabetical';
  onSelectSortBy: (sort: 'popular' | 'rating' | 'newest' | 'alphabetical') => void;
  onReset: () => void;
  onClose: () => void;
}

export const FilterModal: React.FC<FilterModalProps> = ({
  selectedGenre,
  onSelectGenre,
  selectedAvailability,
  onSelectAvailability,
  sortBy,
  onSelectSortBy,
  onReset,
  onClose,
}) => {
  const genres = [
    'all',
    'Klassika',
    'Bestseller',
    'Roman',
    'Biznes',
    'Bolalar',
    'Detektiv',
    'Motivatsiya',
    'Kutubxona fondi',
    'Yangi kelgan'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="filter-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#EAE5DA] bg-[#F2EFE8]/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#ECEAE1] text-[#5A5A40] flex items-center justify-center">
              <SlidersHorizontal className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#3D3B35]">Filtrlar va saralash</h3>
              <p className="text-[11px] text-[#757268]">Qidiruv parametrlarini sozlash</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8F8B7F] hover:text-[#2D2B26] hover:bg-[#EAE5DA] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters Body */}
        <div className="p-5 space-y-5 overflow-y-auto max-h-[70vh] custom-scrollbar">
          {/* Availability */}
          <div>
            <label className="block text-xs font-bold text-[#3D3B35] mb-2">Holati</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'all', label: 'Barchasi' },
                { id: 'available', label: 'Mavjud' },
                { id: 'borrowed', label: 'Band qilingan' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSelectAvailability(item.id as any)}
                  className={`py-2 px-2 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
                    selectedAvailability === item.id
                      ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                      : 'bg-[#F2EFE8] text-[#3D3B35] border-[#E6E1D6] hover:bg-[#EAE5DA]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sort By */}
          <div>
            <label className="block text-xs font-bold text-[#3D3B35] mb-2 flex items-center gap-1.5">
              <ArrowUpDown className="w-3.5 h-3.5 text-[#5A5A40]" />
              Saralash tartibi
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'popular', label: "Ko'p o'qilganlar" },
                { id: 'rating', label: 'Eng yuqori reyting' },
                { id: 'newest', label: "Yangi qo'shilganlar" },
                { id: 'alphabetical', label: "Alifbo bo'yicha (A-Z)" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => onSelectSortBy(item.id as any)}
                  className={`py-2 px-2.5 text-xs font-semibold rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                    sortBy === item.id
                      ? 'bg-[#FAF2E3] border-[#E8DFC8] text-[#8C5D19] font-bold'
                      : 'bg-[#F2EFE8] text-[#3D3B35] border-[#E6E1D6] hover:bg-[#EAE5DA]'
                  }`}
                >
                  <span>{item.label}</span>
                  {sortBy === item.id && <Check className="w-3.5 h-3.5 text-[#8C5D19]" />}
                </button>
              ))}
            </div>
          </div>

          {/* Genres */}
          <div>
            <label className="block text-xs font-bold text-[#3D3B35] mb-2">Janr va toifalar</label>
            <div className="flex flex-wrap gap-1.5">
              {genres.map((g) => (
                <button
                  key={g}
                  onClick={() => onSelectGenre(g)}
                  className={`py-1.5 px-3 text-xs font-semibold rounded-full border transition-all cursor-pointer ${
                    selectedGenre === g
                      ? 'bg-[#5A5A40] text-white border-[#5A5A40] shadow-xs'
                      : 'bg-[#EFECE3] text-[#3D3B35] border-transparent hover:bg-[#E6E1D6]'
                  }`}
                >
                  {g === 'all' ? 'Barcha janrlar' : g}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-[#EAE5DA] bg-[#F2EFE8] flex items-center justify-between gap-3">
          <button
            onClick={onReset}
            className="text-xs font-semibold text-[#757268] hover:text-[#2D2B26] px-3 py-2 cursor-pointer"
          >
            Filtrlarni tozalash
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-[#5A5A40] hover:bg-[#484833] text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
          >
            Natijalarni ko'rish
          </button>
        </div>
      </div>
    </div>
  );
};
