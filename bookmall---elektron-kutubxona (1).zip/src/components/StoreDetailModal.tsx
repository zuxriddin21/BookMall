import React from 'react';
import { X, Store, MapPin, Globe, Phone, ExternalLink, Sparkles, BookOpen } from 'lucide-react';
import { StoreItem, Book } from '../types';

interface StoreDetailModalProps {
  store: StoreItem | null;
  onClose: () => void;
  onSelectBook: (book: Book) => void;
}

export const StoreDetailModal: React.FC<StoreDetailModalProps> = ({
  store,
  onClose,
  onSelectBook,
}) => {
  if (!store) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="store-detail-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6]"
      >
        {/* Header */}
        <div className="p-6 pb-4 relative" style={{ background: store.ring }}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-3 text-white">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg border border-white/20"
              style={{ background: store.bg }}
            >
              {store.label ? (
                <span className="text-xs font-black" style={{ color: store.labelColor || '#fff' }}>
                  {store.label}
                </span>
              ) : (
                <Store className="w-6 h-6 text-[#3D3B35]" />
              )}
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-widest text-[#FAF8F5] bg-black/25 px-2 py-0.5 rounded-md">
                Hamkor kitob do'koni
              </span>
              <h3 className="text-lg font-bold text-white mt-1">{store.name}</h3>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <p className="text-xs sm:text-sm text-[#5A5850] leading-relaxed">
            {store.description ||
              "BookMall platformasining rasmiy hamkori. Eng so'nggi nashrlar, kitobxonlar uchun chegirmalar va yangi kelgan adabiyotlar."}
          </p>

          <div className="space-y-2.5 text-xs text-[#5A5850] bg-[#F2EFE8] p-3.5 rounded-xl border border-[#E6E1D6]">
            <div className="flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-[#5A5A40] flex-shrink-0" />
              <span>{store.location || "Toshkent shahri"}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Globe className="w-4 h-4 text-[#2C5338] flex-shrink-0" />
              <span className="font-semibold text-[#5A5A40]">{store.website || "bookmall.uz"}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-[#D49A3D] flex-shrink-0" />
              <span>BookMall a'zolari uchun <b>10% chegirma</b> kodi: <code className="bg-[#FAF2E3] px-1 py-0.5 rounded text-[#8C5D19] border border-[#E8DFC8] font-bold">BOOKMALL2024</code></span>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={onClose}
              className="w-full py-2.5 bg-[#5A5A40] hover:bg-[#484833] text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Yopish
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
