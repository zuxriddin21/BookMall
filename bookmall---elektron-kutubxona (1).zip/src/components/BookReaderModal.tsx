import React, { useState } from 'react';
import { X, Type, Sun, Moon, Coffee, ChevronLeft, ChevronRight, Bookmark, Check } from 'lucide-react';
import { Book } from '../types';

interface BookReaderModalProps {
  book: Book | null;
  onClose: () => void;
}

export const BookReaderModal: React.FC<BookReaderModalProps> = ({ book, onClose }) => {
  const [theme, setTheme] = useState<'light' | 'sepia' | 'dark'>('sepia');
  const [fontSize, setFontSize] = useState<number>(18);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const totalPages = 8;
  const [savedBookmark, setSavedBookmark] = useState(false);

  if (!book) return null;

  const sampleParagraphs = [
    "Muallif so'zboshisi: Har bir buyuk kitob inson qalbining eng chuqur tuyg'ulariga yo'l ochadi. Bu sahifalarda siz o'zingizni, orzularingizni va hayotning mazmunini qaytadan kashf etasiz.",
    book.sampleText || "Santyagoning ismi bor edi, lekin qo'ylari unga shunchaki cho'pon deb qarashardi. Ular o't-o'lan va suvdan boshqa hech narsani o'ylamasdilar. Cho'pon yigit esa yulduzlar ostida butun olamning yagona tili borligini his qilar edi...",
    "Vaqt shiddat bilan o'tib borardi. Har kuni yangi bilimlar va yangi qiyinchiliklar bilan to'qnash kelar ekan, inson sabr-toqat va iroda kuchi orqaligina o'z maqsadiga yetishi mumkinligini tushunib yetadi.",
    "Kutubxonalar — bu shunchaki kitoblar saqlanadigan bino emas, balki asrlar osha yig'ilgan insoniyat aql-zakovati va ma'naviyatining eng so'nggi xazinasi. Har bir varaqlangan sahifa bizni o'tmish donishmandlari bilan yuzlashtiradi.",
    "Qalbida ezgu niyati bo'lgan har bir kishi yo'lida uchragan to'siqlarni yengib o'tadi. O'zbek xalqining boy madaniyati, mumtoz adabiyoti va zamonaviy ilm-fani ana shunday mustahkam poydevor ustiga qurilgan.",
  ];

  const themeClasses = {
    light: 'bg-[#FDFCF9] text-[#3D3B35] border-[#E6E1D6]',
    sepia: 'bg-[#FAF2E3] text-[#433422] border-[#E8DFC8]',
    dark: 'bg-[#252420] text-[#EFECE3] border-[#3F3D37]',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-0 sm:p-4 animate-in fade-in duration-200">
      <div
        id="book-reader-modal"
        className={`w-full h-full sm:h-[90vh] sm:max-w-3xl sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-colors duration-300 ${themeClasses[theme]}`}
      >
        {/* Reader Top Controls */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-inherit bg-black/5">
          <div className="flex items-center gap-2 truncate">
            <h3 className="text-xs sm:text-sm font-bold truncate max-w-[200px] sm:max-w-xs">
              {book.title}
            </h3>
            <span className="text-[10px] opacity-70 hidden sm:inline">— {book.author}</span>
          </div>

          {/* Controls: Font size, Theme, Bookmark, Close */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Font Size controls */}
            <div className="flex items-center gap-1 bg-black/10 rounded-lg p-1">
              <button
                onClick={() => setFontSize(Math.max(14, fontSize - 2))}
                className="w-6 h-6 flex items-center justify-center text-xs font-bold rounded hover:bg-black/10 transition-colors"
                title="Kichikroq matn"
              >
                A-
              </button>
              <span className="text-[11px] font-semibold px-1">{fontSize}</span>
              <button
                onClick={() => setFontSize(Math.min(26, fontSize + 2))}
                className="w-6 h-6 flex items-center justify-center text-xs font-bold rounded hover:bg-black/10 transition-colors"
                title="Kattaroq matn"
              >
                A+
              </button>
            </div>

            {/* Theme switcher */}
            <div className="flex items-center gap-1 bg-black/10 rounded-lg p-1">
              <button
                onClick={() => setTheme('light')}
                className={`p-1.5 rounded transition-colors ${theme === 'light' ? 'bg-white text-slate-900 shadow-xs' : 'opacity-70 hover:opacity-100'}`}
                title="Yorug' mavzu"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setTheme('sepia')}
                className={`p-1.5 rounded transition-colors ${theme === 'sepia' ? 'bg-[#ebdcc0] text-[#433422] shadow-xs' : 'opacity-70 hover:opacity-100'}`}
                title="Sepiya (Ko'zga qulay)"
              >
                <Coffee className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={`p-1.5 rounded transition-colors ${theme === 'dark' ? 'bg-[#2c3032] text-white shadow-xs' : 'opacity-70 hover:opacity-100'}`}
                title="Tungi mavzu"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={() => setSavedBookmark(!savedBookmark)}
              className={`p-2 rounded-lg transition-colors ${savedBookmark ? 'bg-amber-500 text-white' : 'bg-black/10 hover:bg-black/20'}`}
              title="Xatcho'p qo'yish"
            >
              <Bookmark className="w-3.5 h-3.5" fill={savedBookmark ? 'currentColor' : 'none'} />
            </button>

            <button
              id="close-reader-modal-btn"
              onClick={onClose}
              className="p-2 rounded-lg bg-black/10 hover:bg-black/20 transition-colors ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Reader Reading Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar px-6 sm:px-12 py-8 max-w-2xl mx-auto w-full">
          <div className="text-center mb-8 border-b border-inherit pb-6">
            <span className="text-[11px] font-bold uppercase tracking-widest opacity-60">1-BOB: MUQADDIMA</span>
            <h1 className="font-serif-book text-2xl sm:text-3xl font-bold mt-2">{book.title}</h1>
            <p className="text-xs sm:text-sm mt-1 opacity-80">{book.author}</p>
          </div>

          <div
            className="space-y-6 leading-relaxed font-serif-book"
            style={{ fontSize: `${fontSize}px`, lineHeight: 1.7 }}
          >
            {sampleParagraphs.map((para, idx) => (
              <p key={idx} className="first-letter:text-3xl first-letter:font-bold first-letter:mr-1 first-letter:float-left">
                {para}
              </p>
            ))}

            <div className="my-8 p-4 rounded-xl border border-dashed border-inherit bg-black/5 text-center">
              <p className="text-xs italic opacity-90">
                — Bu kitobning rasmiy namunaviy bobi. To'liq variantini kutubxonadan bepul ijaraga olishingiz yoki band qilishingiz mumkin.
              </p>
            </div>
          </div>
        </div>

        {/* Reader Bottom Bar: Page Navigation & Progress */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-inherit bg-black/5 text-xs">
          <button
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-black/10 hover:bg-black/20 disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Oldingi</span>
          </button>

          <div className="flex flex-col items-center gap-1">
            <span className="font-semibold text-[11px]">
              Sahifa {currentPage} / {totalPages}
            </span>
            <div className="w-28 sm:w-40 h-1.5 bg-black/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-[#5A5A40] rounded-full transition-all duration-300"
                style={{ width: `${(currentPage / totalPages) * 100}%` }}
              />
            </div>
          </div>

          <button
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-black/10 hover:bg-black/20 disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
          >
            <span className="hidden sm:inline">Keyingi</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
