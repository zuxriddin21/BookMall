import React, { useState } from 'react';
import { X, Landmark, Check, MapPin, GraduationCap, Clock, AlertCircle } from 'lucide-react';
import { LibraryItem } from '../types';
import { UPCOMING_UNIVERSITIES_DATA } from '../data/bookData';

interface LibrarySwitcherModalProps {
  libraries: LibraryItem[];
  activeLibrary: LibraryItem;
  onSelectLibrary: (lib: LibraryItem) => void;
  onClose: () => void;
}

export const LibrarySwitcherModal: React.FC<LibrarySwitcherModalProps> = ({
  libraries,
  activeLibrary,
  onSelectLibrary,
  onClose,
}) => {
  const [pendingNotice, setPendingNotice] = useState<string | null>(null);

  const handlePendingClick = (name: string) => {
    setPendingNotice(`"${name}" hali tizimga ulanmagan. Integratsiya jarayoni olib borilmoqda.`);
    setTimeout(() => {
      setPendingNotice(null);
    }, 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="library-switcher-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6] max-h-[85vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#EAE5DA] bg-[#F2EFE8]/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#ECEAE1] text-[#5A5A40] flex items-center justify-center">
              <Landmark className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#3D3B35]">Kutubxonani tanlang</h3>
              <p className="text-[11px] text-[#757268]">Mavjud axborot-resurs markazlari</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8F8B7F] hover:text-[#2D2B26] hover:bg-[#EAE5DA] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Temporary Notice Banner if pending clicked */}
        {pendingNotice && (
          <div className="mx-4 mt-3 p-2.5 bg-[#FAF2E3] border border-[#E8DFC8] rounded-xl flex items-center gap-2 text-xs text-[#8C5D19] animate-in fade-in duration-200">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span className="text-[11px] leading-tight font-medium">{pendingNotice}</span>
          </div>
        )}

        {/* List of Libraries */}
        <div className="p-4 space-y-4 overflow-y-auto max-h-[65vh] custom-scrollbar">
          {/* Active Libraries Section */}
          <div>
            <div className="flex items-center justify-between mb-2 px-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#757268]">
                Faol kutubxonalar ({libraries.length})
              </span>
              <span className="text-[10px] text-[#2C5338] font-semibold bg-[#E8F2EA] px-2 py-0.5 rounded-full border border-[#CDE3D2]">
                Uланган
              </span>
            </div>

            <div className="space-y-2">
              {libraries.map((lib) => {
                const isCurrent = lib.id === activeLibrary.id;
                return (
                  <div
                    key={lib.id}
                    onClick={() => {
                      onSelectLibrary(lib);
                      onClose();
                    }}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group ${
                      isCurrent
                        ? 'border-[#5A5A40] bg-[#FAF2E3] shadow-xs ring-1 ring-[#5A5A40]'
                        : 'border-[#E6E1D6] hover:border-[#5A5A40]/40 hover:bg-[#F2EFE8]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-xs flex-shrink-0"
                        style={{ background: lib.gradient }}
                      >
                        <Landmark className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-[#3D3B35] group-hover:text-[#5A5A40] transition-colors">
                          {lib.name}
                        </h4>
                        <p className="text-[11px] text-[#757268] flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-[#8F8B7F]" />
                          <span>{lib.address.split(',')[0]}</span>
                        </p>
                        <div className="flex items-center gap-2 mt-1 text-[10px]">
                          <span className="text-[#8C5D19] font-semibold bg-[#FAF2E3] px-1.5 py-0.2 rounded border border-[#E8DFC8]">
                            {lib.enteredBooks} ta kiritilgan
                          </span>
                          <span className="text-[#8F8B7F]">
                            {lib.totalLiterature.toLocaleString()} umumiy
                          </span>
                        </div>
                      </div>
                    </div>

                    {isCurrent && (
                      <div className="w-6 h-6 rounded-full bg-[#5A5A40] text-white flex items-center justify-center flex-shrink-0">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Uzbekistan State Universities (Not Connected Yet / Dimmed) */}
          <div>
            <div className="flex items-center justify-between mb-2 px-1 pt-1 border-t border-[#EAE5DA]">
              <div className="flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-[#8F8B7F]" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#757268]">
                  O'zbekiston Davlat Universitetlari ({UPCOMING_UNIVERSITIES_DATA.length})
                </span>
              </div>
              <span className="text-[10px] text-[#8F8B7F] font-semibold bg-[#EFECE3] px-2 py-0.5 rounded-full border border-[#DDD8CA]">
                Hali qo'shilmagan
              </span>
            </div>

            <div className="space-y-2">
              {UPCOMING_UNIVERSITIES_DATA.map((uni) => {
                return (
                  <div
                    key={uni.id}
                    onClick={() => handlePendingClick(uni.name)}
                    className="p-3 rounded-2xl border border-dashed border-[#DDD7C9] bg-[#F5F2EB]/50 opacity-65 hover:opacity-85 hover:bg-[#F2EFE8] transition-all cursor-pointer flex items-center justify-between group grayscale-[25%]"
                    title="Ushbu oliygoh kutubxonasi hali ulanmagan"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center text-white/90 shadow-xs flex-shrink-0 opacity-80"
                        style={{ background: uni.gradient }}
                      >
                        <GraduationCap className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="text-xs font-semibold text-[#5A5850] group-hover:text-[#3D3B35] transition-colors">
                            {uni.name}
                          </h4>
                        </div>
                        <p className="text-[10.5px] text-[#8F8B7F] flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-[#A5A195]" />
                          <span className="truncate max-w-[210px]">{uni.address.split(',')[0]}</span>
                        </p>
                        <div className="flex items-center gap-2 mt-1 text-[9.5px]">
                          <span className="text-[#8F8B7F] font-medium bg-[#EFECE3] px-1.5 py-0.2 rounded border border-[#E0DBD0] flex items-center gap-1">
                            <Clock className="w-2.5 h-2.5 text-[#A5A195]" />
                            {uni.statusLabel || "Hali qo'shilmagan"}
                          </span>
                          <span className="text-[#9B978C]">
                            {uni.totalLiterature.toLocaleString()} fond
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1 flex-shrink-0">
                      <span className="text-[9px] font-semibold text-[#8F8B7F] bg-[#EAE5DA] px-2 py-0.5 rounded-md border border-[#DDD8CA] whitespace-nowrap">
                        Tez kunda
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

