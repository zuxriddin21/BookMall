import React, { useState } from 'react';
import { Search, X, SlidersHorizontal, BookOpen, Clock, Trash2, Star, Bookmark } from 'lucide-react';
import { Book } from '../types';
import { ALL_BOOKS_DATABASE, POPULAR_TAGS, RECENT_SEARCHES } from '../data/bookData';

interface SearchScreenProps {
  initialQuery?: string;
  savedBookIds: string[];
  onSelectBook: (book: Book) => void;
  onToggleSaveBook: (book: Book) => void;
  onOpenFilter: () => void;
  activeFilterGenre: string;
  activeFilterAvailability: 'all' | 'available' | 'borrowed';
  activeSortBy: 'popular' | 'rating' | 'newest' | 'alphabetical';
}

export const SearchScreen: React.FC<SearchScreenProps> = ({
  initialQuery = '',
  savedBookIds,
  onSelectBook,
  onToggleSaveBook,
  onOpenFilter,
  activeFilterGenre,
  activeFilterAvailability,
  activeSortBy,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [recentSearches, setRecentSearches] = useState<string[]>(RECENT_SEARCHES);

  const handleSearchSubmit = (keyword: string) => {
    setQuery(keyword);
    if (keyword.trim() && !recentSearches.includes(keyword)) {
      setRecentSearches([keyword, ...recentSearches.slice(0, 5)]);
    }
  };

  const handleRemoveRecent = (term: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches(recentSearches.filter((t) => t !== term));
  };

  const handleClearAllRecent = () => {
    setRecentSearches([]);
  };

  // Filter & Sort books
  let results = ALL_BOOKS_DATABASE.filter((book) => {
    const q = query.toLowerCase().trim();
    const matchesQuery =
      !q ||
      book.title.toLowerCase().includes(q) ||
      book.author.toLowerCase().includes(q) ||
      (book.genre && book.genre.toLowerCase().includes(q)) ||
      (book.category && book.category.toLowerCase().includes(q));

    const matchesGenre =
      activeFilterGenre === 'all' ||
      (book.genre && book.genre.toLowerCase().includes(activeFilterGenre.toLowerCase())) ||
      (book.category && book.category.toLowerCase().includes(activeFilterGenre.toLowerCase()));

    const matchesAvailability =
      activeFilterAvailability === 'all' ||
      (activeFilterAvailability === 'available' && book.available) ||
      (activeFilterAvailability === 'borrowed' && !book.available);

    return matchesQuery && matchesGenre && matchesAvailability;
  });

  // Sort
  if (activeSortBy === 'rating') {
    results = results.sort((a, b) => Number(b.rating) - Number(a.rating));
  } else if (activeSortBy === 'popular') {
    results = results.sort((a, b) => (b.reads || 0) - (a.reads || 0));
  } else if (activeSortBy === 'alphabetical') {
    results = results.sort((a, b) => a.title.localeCompare(b.title));
  }

  const hasActiveFilters =
    activeFilterGenre !== 'all' ||
    activeFilterAvailability !== 'all' ||
    activeSortBy !== 'popular';

  return (
    <div className="space-y-4 pb-24">
      {/* Search Bar & Filter Button */}
      <div className="flex items-center gap-2 pt-1">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-[#8F8B7F] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="main-search-input"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Kitob nomi, muallif yoki janr..."
            className="w-full pl-10 pr-9 py-3 bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl text-xs sm:text-sm text-[#3D3B35] focus:outline-none focus:ring-2 focus:ring-[#5A5A40] shadow-xs placeholder-[#9B978C]"
            autoFocus={!initialQuery}
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-[#8F8B7F] hover:text-[#3D3B35] rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <button
          id="open-filter-btn"
          onClick={onOpenFilter}
          className={`p-3 rounded-2xl border transition-all cursor-pointer relative ${
            hasActiveFilters
              ? 'bg-[#ECEAE1] border-[#5A5A40] text-[#5A5A40] shadow-xs'
              : 'bg-[#FAF8F5] border-[#E6E1D6] text-[#5A5850] hover:bg-[#F2EFE8]'
          }`}
          title="Filtrlar"
        >
          <SlidersHorizontal className="w-5 h-5" />
          {hasActiveFilters && (
            <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-[#5A5A40] rounded-full ring-2 ring-[#FAF8F5]" />
          )}
        </button>
      </div>

      {/* When no query typed: Recent Searches & Popular Tags */}
      {!query && (
        <div className="space-y-5 pt-1">
          {/* Recent Searches */}
          {recentSearches.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#5A5850] flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#8F8B7F]" />
                  So'nggi qidiruvlar
                </span>
                <button
                  onClick={handleClearAllRecent}
                  className="text-[11px] text-[#8F8B7F] hover:text-[#AD4D39] transition-colors"
                >
                  Tozalash
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {recentSearches.map((term, i) => (
                  <div
                    key={i}
                    onClick={() => handleSearchSubmit(term)}
                    className="flex items-center gap-1.5 bg-[#FAF8F5] border border-[#E6E1D6] px-3 py-1.5 rounded-full text-xs font-medium text-[#4A473D] hover:border-[#5A5A40] hover:text-[#5A5A40] cursor-pointer shadow-xs transition-all"
                  >
                    <span>{term}</span>
                    <button
                      onClick={(e) => handleRemoveRecent(term, e)}
                      className="text-[#8F8B7F] hover:text-[#AD4D39] p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Popular Search Tags */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-[#5A5850] block">
              Ommabop toifalar va teglar
            </span>
            <div className="flex flex-wrap gap-2">
              {POPULAR_TAGS.map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleSearchSubmit(tag)}
                  className="px-3 py-1.5 rounded-xl bg-[#F2EFE8] hover:bg-[#ECEAE1] text-[#4A473D] hover:text-[#5A5A40] text-xs font-semibold border border-transparent hover:border-[#D8D2C4] transition-all cursor-pointer"
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Results Header */}
      <div className="flex items-center justify-between pt-1">
        <span className="text-xs font-bold text-[#4A473D]">
          {query ? `Qidiruv natijalari: "${query}"` : 'Katalogdagi kitoblar'}
        </span>
        <span className="text-[11px] text-[#757268]">
          <b>{results.length}</b> ta kitob topildi
        </span>
      </div>

      {/* Results Grid */}
      {results.length === 0 ? (
        <div className="py-16 text-center space-y-3 bg-[#FAF8F5] rounded-3xl border border-[#E6E1D6] p-6">
          <div className="w-14 h-14 bg-[#EFECE3] rounded-full flex items-center justify-center mx-auto text-[#8F8B7F]">
            <BookOpen className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-bold text-[#3D3B35]">Hech qanday natija topilmadi</h4>
          <p className="text-xs text-[#757268] max-w-xs mx-auto">
            So'rovni o'zgartirib ko'ring yoki boshqa janr va mualliflar bo'yicha qidiring.
          </p>
          <button
            onClick={() => {
              setQuery('');
            }}
            className="px-4 py-2 bg-[#5A5A40] text-white text-xs font-bold rounded-xl"
          >
            Barcha kitoblarni ko'rish
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
          {results.map((book) => {
            const isSaved = savedBookIds.includes(book.id);
            return (
              <div
                key={book.id}
                onClick={() => onSelectBook(book)}
                className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl p-2.5 flex flex-col justify-between hover:border-[#5A5A40]/50 hover:shadow-lg transition-all cursor-pointer group"
              >
                {/* Cover representation */}
                <div className="relative aspect-[3/4.4] rounded-xl overflow-hidden mb-2 bg-[#EFECE3]">
                  <div
                    className="w-full h-full flex flex-col justify-between p-2.5 relative"
                    style={{
                      background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
                        ? book.cover
                        : `url(${book.cover}) center/cover no-repeat`,
                    }}
                  >
                    <div className="flex items-start justify-between z-10">
                      <span
                        className={`text-[8px] font-bold px-1.5 py-0.5 rounded-md ${
                          book.available ? 'bg-[#3F6146]/95 text-white' : 'bg-[#B34734]/95 text-white'
                        }`}
                      >
                        {book.available ? 'Mavjud' : 'Band'}
                      </span>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleSaveBook(book);
                        }}
                        className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
                          isSaved ? 'bg-[#D49A3D] text-white' : 'bg-black/30 text-white/80'
                        }`}
                      >
                        <Bookmark className="w-3.5 h-3.5" fill={isSaved ? 'currentColor' : 'none'} />
                      </button>
                    </div>

                    <div className="text-center my-auto px-1 z-10">
                      <p className={`font-serif-book text-xs font-bold line-clamp-3 ${book.light ? 'text-[#2D2B26]' : 'text-white'}`}>
                        {book.title}
                      </p>
                      <p className={`text-[9px] mt-0.5 line-clamp-1 opacity-80 ${book.light ? 'text-[#4A473D]' : 'text-[#FAF6EE]'}`}>
                        {book.author}
                      </p>
                    </div>

                    <div className="flex items-center justify-between z-10 text-[9px] font-semibold text-[#F5CA7B]">
                      <div className="flex items-center gap-0.5 bg-black/40 px-1.5 py-0.5 rounded-md">
                        <Star className="w-2.5 h-2.5 fill-[#D49A3D] text-[#D49A3D]" />
                        <span>{book.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Info block */}
                <div>
                  <h4 className="text-xs font-bold text-[#3D3B35] line-clamp-1 group-hover:text-[#5A5A40] transition-colors">
                    {book.title}
                  </h4>
                  <p className="text-[11px] text-[#757268] line-clamp-1 mt-0.5">
                    {book.author}
                  </p>
                  <div className="flex items-center justify-between mt-1.5 text-[10px] text-[#8F8B7F]">
                    <span className="truncate max-w-[90px]">{book.genre || 'Adabiyot'}</span>
                    <span>{book.sold || `${book.reads || 120} o'qildi`}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
