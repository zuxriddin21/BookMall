import React from 'react';
import { Star, Bookmark, BookOpen, Volume2 } from 'lucide-react';
import { Book } from '../types';

interface BookCardProps {
  book: Book;
  onSelect: (book: Book) => void;
  isSaved?: boolean;
  onToggleSave?: (book: Book, e: React.MouseEvent) => void;
  onQuickRead?: (book: Book, e: React.MouseEvent) => void;
}

export const BookCard: React.FC<BookCardProps> = ({
  book,
  onSelect,
  isSaved = false,
  onToggleSave,
  onQuickRead,
}) => {
  return (
    <div
      id={`book-card-${book.id}`}
      onClick={() => onSelect(book)}
      className="flex-shrink-0 w-36 sm:w-40 flex flex-col cursor-pointer group select-none"
    >
      {/* Book Cover Container */}
      <div className="relative w-full aspect-[3/4.4] rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 transform group-hover:-translate-y-1 bg-slate-200">
        <div
          className="w-full h-full flex flex-col justify-between p-3 relative"
          style={{
            background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
              ? book.cover
              : `url(${book.cover}) center/cover no-repeat`,
          }}
        >
          {/* Subtle Book Spine Effect */}
          <div className="absolute top-0 left-0 bottom-0 w-2.5 bg-gradient-to-r from-black/25 via-white/10 to-transparent pointer-events-none" />

          {/* Top Row: Availability Pill & Bookmark */}
          <div className="flex items-start justify-between z-10">
            <span
              className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md shadow-xs backdrop-blur-md ${
                book.available
                  ? 'bg-[#3F6146]/95 text-white'
                  : 'bg-[#B34734]/95 text-white'
              }`}
            >
              {book.available ? 'Mavjud' : 'Band'}
            </span>

            {onToggleSave && (
              <button
                id={`bookmark-btn-${book.id}`}
                onClick={(e) => onToggleSave(book, e)}
                className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
                  isSaved
                    ? 'bg-[#D49A3D] text-white shadow-sm'
                    : 'bg-black/30 text-white/80 hover:bg-black/50 hover:text-white'
                }`}
                title={isSaved ? "Saqlanganlardan o'chirish" : "Saqlab qo'yish"}
              >
                <Bookmark className="w-3.5 h-3.5" fill={isSaved ? 'currentColor' : 'none'} />
              </button>
            )}
          </div>

          {/* Center Book Title Preview on Cover */}
          <div className="my-auto text-center px-1 z-10">
            <p
              className={`font-serif-book text-xs sm:text-sm font-bold line-clamp-3 leading-snug drop-shadow-xs ${
                book.light ? 'text-[#2D2B26]' : 'text-white'
              }`}
            >
              {book.title}
            </p>
            <p
              className={`text-[10px] mt-1 line-clamp-1 opacity-80 ${
                book.light ? 'text-[#4A473D]' : 'text-[#FAF6EE]'
              }`}
            >
              {book.author}
            </p>
          </div>

          {/* Bottom Row: Quick Action icons */}
          <div className="flex items-center justify-between text-[10px] z-10">
            <div
              className={`flex items-center gap-1 font-semibold px-1.5 py-0.5 rounded-md backdrop-blur-md ${
                book.light ? 'bg-black/10 text-[#3D3B35]' : 'bg-black/40 text-[#F5CA7B]'
              }`}
            >
              <Star className="w-2.5 h-2.5 fill-[#D49A3D] text-[#D49A3D]" />
              <span>{book.rating}</span>
            </div>

            {onQuickRead && (
              <button
                id={`quick-read-btn-${book.id}`}
                onClick={(e) => onQuickRead(book, e)}
                className="p-1 rounded-md bg-white/30 hover:bg-white/50 text-white backdrop-blur-md transition-colors"
                title="Namunani o'qish"
              >
                <BookOpen className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Book Info below cover */}
      <div className="mt-2 flex flex-col">
        <h4 className="text-xs font-semibold text-[#3D3B35] line-clamp-1 group-hover:text-[#5A5A40] transition-colors">
          {book.title}
        </h4>
        <p className="text-[11px] text-[#757268] line-clamp-1 mt-0.5">
          {book.author}
        </p>
        <div className="flex items-center justify-between mt-1 text-[10px] text-[#8F8B7F]">
          <span>{book.sold || `${book.reads || 120} o'qilgan`}</span>
        </div>
      </div>
    </div>
  );
};
