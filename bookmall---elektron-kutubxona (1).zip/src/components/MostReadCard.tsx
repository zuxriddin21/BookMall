import React from 'react';
import { Star, Bookmark, BookOpen, CheckCircle, Clock } from 'lucide-react';
import { Book } from '../types';

interface MostReadCardProps {
  book: Book;
  rank: number;
  onSelect: (book: Book) => void;
  isSaved?: boolean;
  onToggleSave?: (book: Book, e: React.MouseEvent) => void;
}

export const MostReadCard: React.FC<MostReadCardProps> = ({
  book,
  rank,
  onSelect,
  isSaved = false,
  onToggleSave,
}) => {
  return (
    <div
      id={`most-read-card-${book.id}`}
      onClick={() => onSelect(book)}
      className="flex-shrink-0 w-44 sm:w-48 bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl p-2.5 flex flex-col cursor-pointer group hover:border-[#5A5A40]/50 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
    >
      {/* Cover with Rank Badge */}
      <div className="relative w-full aspect-[3/4.2] rounded-xl overflow-hidden shadow-xs bg-[#EFECE3]">
        <div
          className="w-full h-full flex flex-col justify-between p-3 relative"
          style={{
            background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
              ? book.cover
              : `url(${book.cover}) center/cover no-repeat`,
          }}
        >
          {/* Subtle Book Spine Effect */}
          <div className="absolute top-0 left-0 bottom-0 w-2.5 bg-gradient-to-r from-black/25 via-white/10 to-transparent pointer-events-none" />

          {/* Top Rank Badge & Bookmark */}
          <div className="flex items-start justify-between z-10">
            <div className="w-6 h-6 rounded-full bg-[#5A5A40] text-white font-black text-xs flex items-center justify-center shadow-md">
              {rank}
            </div>

            {onToggleSave && (
              <button
                id={`mr-bookmark-${book.id}`}
                onClick={(e) => onToggleSave(book, e)}
                className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
                  isSaved
                    ? 'bg-[#D49A3D] text-white'
                    : 'bg-black/30 text-white/80 hover:bg-black/50'
                }`}
              >
                <Bookmark className="w-3.5 h-3.5" fill={isSaved ? 'currentColor' : 'none'} />
              </button>
            )}
          </div>

          {/* Middle Title Preview */}
          <div className="my-auto text-center px-1 z-10">
            <p
              className={`font-serif-book text-xs font-bold line-clamp-3 ${
                book.light ? 'text-[#2D2B26]' : 'text-white'
              }`}
            >
              {book.title}
            </p>
            <p
              className={`text-[9px] mt-1 line-clamp-1 opacity-80 ${
                book.light ? 'text-[#4A473D]' : 'text-[#FAF6EE]'
              }`}
            >
              {book.author}
            </p>
          </div>

          {/* Bottom Rating */}
          <div className="flex items-center justify-between text-[10px] z-10">
            <div
              className={`flex items-center gap-1 font-bold px-1.5 py-0.5 rounded-md backdrop-blur-md ${
                book.light ? 'bg-black/10 text-[#3D3B35]' : 'bg-black/40 text-[#F5CA7B]'
              }`}
            >
              <Star className="w-2.5 h-2.5 fill-[#D49A3D] text-[#D49A3D]" />
              <span>{book.rating}</span>
            </div>
            <span
              className={`text-[9px] font-semibold px-1.5 py-0.5 rounded-md ${
                book.available ? 'bg-[#3F6146] text-white' : 'bg-[#B34734] text-white'
              }`}
            >
              {book.available ? 'Mavjud' : 'Band'}
            </span>
          </div>
        </div>
      </div>

      {/* Info Block */}
      <div className="mt-2.5 px-0.5 flex flex-col flex-1 justify-between">
        <div>
          <h4 className="text-xs font-bold text-[#3D3B35] line-clamp-1 group-hover:text-[#5A5A40] transition-colors">
            {book.title}
          </h4>
          <p className="text-[11px] text-[#757268] line-clamp-1 mt-0.5">
            {book.author}
          </p>
        </div>

        <div className="mt-2 pt-2 border-t border-[#EAE5DA] flex items-center justify-between text-[10px] text-[#8F8B7F]">
          <span>{book.sold || `${book.reads} marta`}</span>
          <span className="text-[#5A5A40] font-semibold group-hover:underline">Batafsil →</span>
        </div>
      </div>
    </div>
  );
};
