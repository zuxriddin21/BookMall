import React, { useState, useEffect } from 'react';
import {
  User as UserIcon,
  Calendar,
  Clock,
  BookOpen,
  Award,
  Flame,
  Heart,
  ChevronRight,
  Shield,
  HelpCircle,
  LogOut,
  Landmark,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  LayoutDashboard,
  ShieldAlert,
  Edit3,
  Camera,
  AtSign,
  Users,
  UserCheck,
  UserPlus,
  Star,
  Plus,
  BookCheck,
  Building2,
  Bookmark,
  ExternalLink,
  BookMarked,
  Crown,
  Pin,
  PinOff,
  Lock
} from 'lucide-react';
import {
  BorrowedItem,
  WaitingItem,
  LibraryItem,
  Book,
  UserProfileResponse,
  FollowingItem,
  ProfileReadBookItem
} from '../types';
import bookmallLogoImg from '../assets/images/bookmall_logo_1788418721778.jpg';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { EditProfileModal } from './profile/EditProfileModal';
import { ChangeAvatarModal } from './profile/ChangeAvatarModal';
import { MarkReadBookModal } from './profile/MarkReadBookModal';
import { ReadBooksListModal } from './profile/ReadBooksListModal';

interface ProfileScreenProps {
  activeLibrary: LibraryItem;
  borrowedBooks: BorrowedItem[];
  waitingBooks: WaitingItem[];
  onOpenDonationModal: () => void;
  onOpenLibrarySwitcher: () => void;
  onOpenWelcomeSplash?: () => void;
  onSelectBook?: (book: Book) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  activeLibrary,
  borrowedBooks,
  waitingBooks,
  onOpenDonationModal,
  onOpenLibrarySwitcher,
  onOpenWelcomeSplash,
  onSelectBook,
}) => {
  const { currentUser, token, setActiveAppView, updateCurrentUser } = useAuth();

  // Tab state
  const [activeTab, setActiveTab] = useState<'readBooks' | 'waiting' | 'following' | 'stats'>('readBooks');
  const [followingSubTab, setFollowingSubTab] = useState<'all' | 'libraries' | 'publishers' | 'bloggers'>('all');

  // Modals state
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showChangeAvatarModal, setShowChangeAvatarModal] = useState(false);
  const [showMarkReadModal, setShowMarkReadModal] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showReadBooksModal, setShowReadBooksModal] = useState(false);
  const [pinningBookId, setPinningBookId] = useState<string | null>(null);
  const [showAllReadBooks, setShowAllReadBooks] = useState(false);
  const [allReadBooksList, setAllReadBooksList] = useState<ProfileReadBookItem[]>([]);

  // Profile data from backend
  const [profileData, setProfileData] = useState<UserProfileResponse | null>(null);
  const [isLoadingProfile, setIsLoadingProfile] = useState(false);
  const [readBooksPage, setReadBooksPage] = useState(1);
  const [isLoadingReadBooks, setIsLoadingReadBooks] = useState(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  const currentReadBooksLimit = showAllReadBooks ? 50 : 8;

  // Fetch complete profile from backend
  const fetchProfile = async (page = 1, limit = currentReadBooksLimit) => {
    setIsLoadingProfile(true);
    try {
      const data = await api.profile.get(currentUser.id, page, limit, token);
      setProfileData(data);
    } catch (err) {
      console.warn("Profil ma'lumotlarini serverdan olishda xatolik:", err);
    } finally {
      setIsLoadingProfile(false);
    }
  };

  const fetchAllReadBooksForModal = async () => {
    try {
      const res = await api.profile.getReadBooks(currentUser.id, 1, 100, token);
      setAllReadBooksList(res.items);
    } catch (err) {
      console.error("Barcha o'qilgan kitoblarni yuklashda xatolik:", err);
    }
  };

  const fetchReadBooks = async (page = 1, limit = currentReadBooksLimit) => {
    setIsLoadingReadBooks(true);
    try {
      const res = await api.profile.getReadBooks(currentUser.id, page, limit, token);
      setReadBooksPage(page);
      setProfileData((prev) =>
        prev
          ? {
              ...prev,
              readBooks: res,
            }
          : null
      );
    } catch (err) {
      console.error("O'qilgan kitoblarni yuklashda xatolik:", err);
    } finally {
      setIsLoadingReadBooks(false);
    }
  };

  useEffect(() => {
    fetchProfile(readBooksPage, currentReadBooksLimit);
    fetchAllReadBooksForModal();
  }, [currentUser.id, token, showAllReadBooks]);

  const handleReadBooksPageChange = async (newPage: number) => {
    fetchReadBooks(newPage, currentReadBooksLimit);
  };

  // Toggle Pin/Unpin Read Book (Premium Only)
  const handleTogglePin = async (item: ProfileReadBookItem) => {
    const isPremium = currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM' || currentUser.subscriptionPlan === 'VIP';
    if (!isPremium) {
      setShowPremiumModal(true);
      return;
    }

    setPinningBookId(item.bookId);
    try {
      const res = await api.profile.pinBook(item.bookId, undefined, token);
      setActionSuccessMsg(res.message);
      setTimeout(() => setActionSuccessMsg(null), 3500);

      // Reload read books list to reflect updated order
      await fetchReadBooks(readBooksPage, currentReadBooksLimit);
      await fetchAllReadBooksForModal();
    } catch (err: any) {
      if (err.code === 'PREMIUM_REQUIRED') {
        setShowPremiumModal(true);
      } else {
        alert(err.message || "Kitobni qadashda xatolik yuz berdi");
      }
    } finally {
      setPinningBookId(null);
    }
  };

  // Switch between FREE and PREMIUM plan
  const handleSwitchPlan = async (plan: 'FREE' | 'PREMIUM') => {
    try {
      const res = await api.profile.setSubscriptionPlan(plan, token);
      updateCurrentUser({
        isPremium: plan === 'PREMIUM',
        subscriptionPlan: plan,
      });
      setActionSuccessMsg(res.message);
      setTimeout(() => setActionSuccessMsg(null), 3500);
      setShowPremiumModal(false);
      await fetchReadBooks(1, currentReadBooksLimit);
    } catch (err: any) {
      alert(err.message || "Tarifni o'zgartirishda xatolik");
    }
  };

  // Toggle follow action
  const handleToggleFollow = async (
    targetType: 'USER' | 'LIBRARY' | 'PUBLISHER',
    targetId: string,
    targetName: string
  ) => {
    try {
      const res = await api.profile.toggleFollow({ targetType, targetId }, token);
      // Update local state optimistically
      setProfileData((prev) => {
        if (!prev) return null;
        const updateList = (list: FollowingItem[]) =>
          list.map((item) =>
            item.id === targetId ? { ...item, isFollowing: res.isFollowing } : item
          );

        return {
          ...prev,
          stats: {
            ...prev.stats,
            followingCount: res.followingCount,
          },
          followings: {
            libraries: updateList(prev.followings.libraries),
            publishers: updateList(prev.followings.publishers),
            bloggers: updateList(prev.followings.bloggers),
          },
        };
      });

      setActionSuccessMsg(
        res.isFollowing
          ? `"${targetName}" ga obuna bo'lindi`
          : `"${targetName}" obunasi bekor qilindi`
      );
      setTimeout(() => setActionSuccessMsg(null), 3000);
    } catch (err: any) {
      alert(err.message || "Obunani yangilab bo'lmadi");
    }
  };

  // Aggregated followings for display
  const allFollowings = profileData
    ? [
        ...profileData.followings.libraries,
        ...profileData.followings.publishers,
        ...profileData.followings.bloggers,
      ]
    : [];

  const filteredFollowings =
    followingSubTab === 'all'
      ? allFollowings
      : followingSubTab === 'libraries'
      ? profileData?.followings.libraries || []
      : followingSubTab === 'publishers'
      ? profileData?.followings.publishers || []
      : profileData?.followings.bloggers || [];

  const followersCount = profileData?.stats.followersCount ?? 42;
  const followingCount = profileData?.stats.followingCount ?? 18;
  const booksReadCount = profileData?.stats.booksReadCount ?? (profileData?.readBooks.total || 23);

  return (
    <div className="space-y-5 pb-24">
      {/* Toast Notification */}
      {actionSuccessMsg && (
        <div className="fixed top-18 right-4 z-50 bg-[#2C5338] text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-semibold animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-[#BDE2C7]" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* 1. Digital Reader Pass Card */}
      <div className="rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-[#2D3025] via-[#3E4233] to-[#25281F] text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-44 h-44 rounded-full bg-white/5 pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-12 w-36 h-36 rounded-full bg-[#E8B96A]/10 pointer-events-none blur-xl" />

        <div className="relative z-10 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              {/* Avatar with Change Photo Trigger */}
              <div className="relative group cursor-pointer" onClick={() => setShowChangeAvatarModal(true)}>
                <img
                  src={
                    currentUser.avatar ||
                    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
                  }
                  alt="Profile"
                  className="w-16 h-16 rounded-2xl object-cover ring-2 ring-white/30 shadow-md group-hover:brightness-90 transition-all"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 rounded-2xl opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <Camera className="w-5 h-5 text-white" />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-[#2C5338] text-white p-1 rounded-full border-2 border-[#2D3025]">
                  <Camera className="w-3 h-3" />
                </div>
              </div>

              {/* User Details */}
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-[#E8B96A]">
                    {currentUser.role === 'LIBRARY_ADMIN' ? 'Admin Guvohnomasi' : 'Kitobxon Guvohnomasi'}
                  </span>
                  <span
                    className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      currentUser.role === 'LIBRARY_ADMIN'
                        ? 'bg-[#E8B96A] text-[#2D2A26]'
                        : 'bg-white/20 text-white'
                    }`}
                  >
                    {currentUser.role}
                  </span>
                </div>

                <div className="flex items-center gap-2 mt-0.5">
                  <h3 className="text-lg font-bold truncate">{currentUser.name}</h3>
                  <button
                    onClick={() => setShowEditProfileModal(true)}
                    className="p-1 rounded-lg hover:bg-white/10 text-[#E5E0D5] hover:text-white transition-colors"
                    title="Profilni tahrirlash"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-2 text-xs text-[#E5E0D5]">
                  <span className="font-mono text-[#E8B96A]">
                    @{currentUser.username || currentUser.email.split('@')[0]}
                  </span>
                  <span className="text-white/40">•</span>
                  <span className="font-mono text-white/70">ID: {currentUser.id}</span>
                </div>

                {/* Bio text */}
                <p className="text-[11.5px] text-[#D8D2C5] mt-1 line-clamp-2 max-w-md font-sans">
                  {currentUser.bio || "Kitoblar mutolaasi va ilm-fanga oshiq kitobxon 📖"}
                </p>
              </div>
            </div>
          </div>

          {/* Social Stats Row: Followers, Following, Books */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/15 text-center">
            <div
              onClick={() => {
                setActiveTab('following');
                setFollowingSubTab('all');
              }}
              className="cursor-pointer hover:bg-white/5 p-1.5 rounded-xl transition-colors"
            >
              <span className="text-sm sm:text-base font-black text-[#E8B96A] block">{followersCount}</span>
              <span className="text-[10px] text-white/70 font-medium">Obunachilar</span>
            </div>

            <div
              onClick={() => {
                setActiveTab('following');
                setFollowingSubTab('all');
              }}
              className="cursor-pointer hover:bg-white/5 p-1.5 rounded-xl transition-colors"
            >
              <span className="text-sm sm:text-base font-black text-white block">{followingCount}</span>
              <span className="text-[10px] text-white/70 font-medium">Obunalar</span>
            </div>

            <div
              id="profile-stat-read-books"
              onClick={() => {
                setActiveTab('readBooks');
                setShowReadBooksModal(true);
                fetchAllReadBooksForModal();
              }}
              className="cursor-pointer hover:bg-white/10 active:scale-95 p-1.5 rounded-xl transition-all border border-transparent hover:border-white/20 group"
              title="O'qilgan kitoblarni uzun oynada ko'rish (1, 2, 3 qadalgan)"
            >
              <span className="text-sm sm:text-base font-black text-[#BDE2C7] block group-hover:scale-105 transition-transform">{booksReadCount}</span>
              <span className="text-[10px] text-white/70 font-medium flex items-center justify-center gap-0.5">
                <span>O'qilgan</span>
                <span className="text-[#E8B96A] font-bold">📌</span>
              </span>
            </div>
          </div>

          {/* Library Link Bar */}
          <div
            onClick={onOpenLibrarySwitcher}
            className="pt-2 border-t border-white/15 flex items-center justify-between text-xs cursor-pointer hover:bg-white/5 p-1.5 rounded-lg transition-colors"
            title="Kutubxonani almashtirish"
          >
            <div className="flex items-center gap-1.5">
              <Landmark className="w-3.5 h-3.5 text-[#E8B96A]" />
              <span className="text-[#F2EFE8] font-medium">{activeLibrary.name}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-[#BDE2C7] bg-[#223B2A]/70 px-2 py-0.5 rounded-md border border-[#3E6349]/50 text-[11px]">
                {currentUser.role === 'LIBRARY_ADMIN' ? 'Boshqaruvchi' : "Faol a'zo"}
              </span>
              <ChevronRight className="w-3.5 h-3.5 text-white/70" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Edit & Actions Row */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setShowEditProfileModal(true)}
          className="flex-1 py-2.5 px-3 bg-[#FAF8F5] hover:bg-[#F2EFE8] border border-[#E6E1D6] rounded-2xl text-xs font-bold text-[#3D3B35] flex items-center justify-center gap-1.5 shadow-2xs transition-colors"
        >
          <Edit3 className="w-3.5 h-3.5 text-[#2C5338]" />
          <span>Profilni tahrirlash</span>
        </button>

        <button
          onClick={() => setShowChangeAvatarModal(true)}
          className="py-2.5 px-3 bg-[#FAF8F5] hover:bg-[#F2EFE8] border border-[#E6E1D6] rounded-2xl text-xs font-bold text-[#3D3B35] flex items-center justify-center gap-1.5 shadow-2xs transition-colors"
        >
          <Camera className="w-3.5 h-3.5 text-[#8C5D19]" />
          <span>Rasmni o'zgartirish</span>
        </button>

        <button
          onClick={() => setShowMarkReadModal(true)}
          className="py-2.5 px-3.5 bg-[#2C5338] hover:bg-[#23422C] text-white rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Kitob belgilash</span>
        </button>
      </div>

      {/* 2. Main Navigation Tabs: ReadBooks, Waiting, Following, Stats */}
      <div className="space-y-3">
        <div className="flex gap-1.5 bg-[#EFECE3] p-1 rounded-2xl overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('readBooks')}
            className={`flex-1 min-w-[105px] py-2 px-2 text-xs font-semibold rounded-xl transition-all cursor-pointer text-center whitespace-nowrap ${
              activeTab === 'readBooks'
                ? 'bg-[#FAF8F5] text-[#3D3B35] shadow-xs font-bold'
                : 'text-[#757268] hover:text-[#3D3B35]'
            }`}
          >
            O'qilganlar ({booksReadCount})
          </button>
          <button
            onClick={() => setActiveTab('waiting')}
            className={`flex-1 min-w-[100px] py-2 px-2 text-xs font-semibold rounded-xl transition-all cursor-pointer text-center whitespace-nowrap ${
              activeTab === 'waiting'
                ? 'bg-[#FAF8F5] text-[#3D3B35] shadow-xs font-bold'
                : 'text-[#757268] hover:text-[#3D3B35]'
            }`}
          >
            Navbatda ({waitingBooks.length})
          </button>
          <button
            onClick={() => setActiveTab('following')}
            className={`flex-1 min-w-[95px] py-2 px-2 text-xs font-semibold rounded-xl transition-all cursor-pointer text-center whitespace-nowrap ${
              activeTab === 'following'
                ? 'bg-[#FAF8F5] text-[#3D3B35] shadow-xs font-bold'
                : 'text-[#757268] hover:text-[#3D3B35]'
            }`}
          >
            Obunalar ({followingCount})
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`flex-1 min-w-[85px] py-2 px-2 text-xs font-semibold rounded-xl transition-all cursor-pointer text-center whitespace-nowrap ${
              activeTab === 'stats'
                ? 'bg-[#FAF8F5] text-[#3D3B35] shadow-xs font-bold'
                : 'text-[#757268] hover:text-[#3D3B35]'
            }`}
          >
            Statistika
          </button>
        </div>

        {/* Tab 1: Waiting List */}
        {activeTab === 'waiting' && (
          <div className="space-y-3">
            {waitingBooks.length === 0 ? (
              <div className="py-8 text-center bg-[#FAF8F5] rounded-2xl border border-[#E6E1D6] p-4">
                <Clock className="w-8 h-8 text-[#8F8B7F] mx-auto mb-2" />
                <p className="text-xs text-[#757268]">Hozircha navbatdagi kitoblar mavjud emas</p>
              </div>
            ) : (
              waitingBooks.map((item) => (
                <div
                  key={item.id}
                  className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl p-3 flex items-center justify-between gap-3 shadow-2xs"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-12 h-16 rounded-xl flex items-center justify-center p-1 shadow-2xs text-center flex-shrink-0 bg-[#EFECE3]"
                      style={{
                        background:
                          item.cover.startsWith('linear-gradient') || item.cover.startsWith('#')
                            ? item.cover
                            : `url(${item.cover}) center/cover no-repeat`,
                      }}
                    >
                      <span
                        className={`text-[8px] font-serif-book font-bold line-clamp-2 ${
                          item.light ? 'text-[#2D2B26]' : 'text-white'
                        }`}
                      >
                        {item.title}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-[#3D3B35]">{item.title}</h4>
                      <p className="text-[11px] text-[#757268]">{item.author}</p>
                      <div className="flex items-center gap-2 mt-1.5 text-[10px]">
                        <span className="text-[#8C5D19] bg-[#FAF2E3] px-1.5 py-0.5 rounded font-bold">
                          Navbatingiz: {item.queuePosition}-o'rin
                        </span>
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] text-[#8F8B7F]">{item.requestedDate} so'ralgan</span>
                </div>
              ))
            )}
          </div>
        )}

        {/* Tab 3: Read Books (O'qilgan Kitoblar) */}
        {activeTab === 'readBooks' && (
          <div className="space-y-3">
            {/* Header with Tariff Status & Mark Read Trigger */}
            <div className="bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#E6E1D6] space-y-2.5">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold text-[#2D2B26] flex items-center gap-1.5">
                      <BookCheck className="w-4 h-4 text-[#2C5338]" />
                      <span>Mutolaa qilingan asarlar</span>
                    </h4>

                    {/* Active Tariff Badge */}
                    {currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM' ? (
                      <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#FAF0DC] border border-[#E5C687] text-[#8C5D19] text-[10px] font-extrabold shadow-2xs">
                        <Crown className="w-3 h-3 text-[#B87D1B]" />
                        <span>Premium Tarif</span>
                        <span className="text-[#2C5338] ml-0.5 font-black">• 📌 Qadash faol</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#EFECE6] border border-[#DDD8CE] text-[#5A574F] text-[10px] font-bold">
                        <Lock className="w-2.5 h-2.5 text-[#757268]" />
                        <span>Standart Tarif</span>
                        <button
                          onClick={() => setShowPremiumModal(true)}
                          className="text-[#8C5D19] underline font-extrabold ml-1 hover:text-[#B87D1B]"
                        >
                          ⭐ Premiumga o'tish
                        </button>
                      </div>
                    )}
                  </div>

                  <p className="text-[11px] text-[#757268] mt-0.5">
                    Jami {profileData?.readBooks.total || 0} ta asar o'qib tugatilgan
                    {profileData?.readBooks.items.some((i) => i.isPinned) && (
                      <span className="text-[#8C5D19] font-medium ml-1">
                        ({profileData.readBooks.items.filter((i) => i.isPinned).length} ta saralangan kitob qadalgan)
                      </span>
                    )}
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Test Switcher between Free and Premium */}
                  <button
                    onClick={() =>
                      handleSwitchPlan(
                        currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM' ? 'FREE' : 'PREMIUM'
                      )
                    }
                    className="px-2.5 py-1 text-[10.5px] font-semibold bg-white border border-[#DDD7CD] hover:border-[#C8C1B4] text-[#5A574F] rounded-xl transition-all shadow-2xs flex items-center gap-1"
                    title="Tarifni almashtirib sinab ko'rish"
                  >
                    <Sparkles className="w-3 h-3 text-[#C08528]" />
                    <span>
                      {currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM'
                        ? "Standartga o'tish (Test)"
                        : "Premiumga o'tish (Test)"}
                    </span>
                  </button>

                  <button
                    onClick={() => setShowMarkReadModal(true)}
                    className="px-3 py-1.5 bg-[#2C5338] hover:bg-[#23422C] text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-xs transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Kitob qo'shish</span>
                  </button>
                </div>
              </div>

              {/* Pin Banner Info */}
              <div className="flex items-center justify-between px-3 py-1.5 bg-[#FAF3E6]/80 border border-[#EAD6B3] rounded-xl text-[11px] text-[#8C5D19]">
                <div className="flex items-center gap-1.5 font-medium">
                  <span className="text-xs">📌</span>
                  <span>
                    Qadalgan kitoblar har doim ro'yxatning eng yuqori qismida (1-, 2-, 3-o'rinlarda) turadi.
                    <span className="font-bold ml-1 text-[#A07024]">(Faqat Premium tarifda)</span>
                  </span>
                </div>

                <button
                  onClick={() => setShowAllReadBooks(!showAllReadBooks)}
                  className="text-[10px] font-bold text-[#2C5338] bg-white/90 hover:bg-white px-2 py-0.5 rounded-md border border-[#E8D4B0] transition-colors ml-2 whitespace-nowrap"
                >
                  {showAllReadBooks ? "Sahifalab ko'rish" : "Hammasini ko'rsatish (23 ta)"}
                </button>
              </div>
            </div>

            {/* Long Modal Window Opener Card */}
            <div
              id="open-read-books-long-window-btn"
              onClick={() => {
                setShowReadBooksModal(true);
                fetchAllReadBooksForModal();
              }}
              className="flex items-center justify-between p-3.5 bg-gradient-to-r from-[#22442E] via-[#2A5237] to-[#1E3C28] hover:from-[#1B3624] hover:to-[#172E1F] text-white rounded-2xl shadow-sm border border-[#3E6B4A] transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-[#E8B96A] shadow-inner flex-shrink-0">
                  <BookCheck className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs sm:text-sm font-bold">To'liq uzun oynada ko'rish</span>
                    <span className="text-[10px] font-extrabold bg-[#E8B96A] text-[#2D2A26] px-2 py-0.5 rounded-md shadow-2xs">
                      {booksReadCount} ta kitob
                    </span>
                  </div>
                  <p className="text-[11px] text-[#D8E6DC] mt-0.5">
                    📌 1-, 2-, 3-o'rinlarda saralangan kitoblar qadalgan holda ochiladi
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs font-bold text-[#E8B96A] bg-white/10 px-2.5 py-1.5 rounded-xl border border-white/15 group-hover:bg-white/20 transition-colors whitespace-nowrap ml-2">
                <span>Oynani ochish</span>
                <ChevronRight className="w-4 h-4 transform group-hover:translate-x-0.5 transition-transform" />
              </div>
            </div>

            {isLoadingReadBooks ? (
              <div className="py-12 text-center text-xs text-[#757268]">Kitoblar yuklanmoqda...</div>
            ) : !profileData || profileData.readBooks.items.length === 0 ? (
              <div className="py-8 text-center bg-[#FAF8F5] rounded-2xl border border-[#E6E1D6] p-4">
                <BookCheck className="w-8 h-8 text-[#8F8B7F] mx-auto mb-2" />
                <p className="text-xs text-[#757268]">O'qilgan kitoblar ro'yxati bo'sh</p>
                <button
                  onClick={() => setShowMarkReadModal(true)}
                  className="mt-3 px-3.5 py-1.5 bg-[#2C5338] text-white text-xs font-bold rounded-xl inline-flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>O'qilgan kitobni belgilash</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {profileData.readBooks.items.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      if (onSelectBook) {
                        onSelectBook({
                          id: item.bookId,
                          title: item.title,
                          author: item.author,
                          cover: item.coverImage,
                          rating: item.rating,
                          available: true,
                          genre: item.genre,
                          description: item.description,
                        });
                      }
                    }}
                    className={`rounded-2xl p-3 flex flex-col gap-2 transition-all group cursor-pointer ${
                      item.isPinned
                        ? 'bg-gradient-to-r from-[#FAF5EC] via-[#FCF9F3] to-[#FAF8F5] border-2 border-[#E2BC75] ring-2 ring-[#E5C384]/20 shadow-xs'
                        : 'bg-[#FAF8F5] border border-[#E6E1D6] hover:border-[#2C5338]/40 shadow-2xs'
                    }`}
                  >
                    {/* If Pinned: Special Prominent Header with 📌 Rank & Unpin Button */}
                    {item.isPinned && (
                      <div className="flex items-center justify-between pb-2 border-b border-[#EAD5AB]/60">
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-[#F5E4BE] text-[#7A4E11] border border-[#E0BC73] text-[11px] font-black shadow-2xs">
                            <span className="text-xs">📌</span>
                            <span>{item.pinnedOrder || 1}-o'rinda qadalgan</span>
                          </div>
                          <span className="text-[10px] text-[#A07024] font-semibold bg-[#FAF1DF] px-2 py-0.5 rounded-md border border-[#EBDCBF]">
                            Asosiy tavsiya
                          </span>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleTogglePin(item);
                          }}
                          disabled={pinningBookId === item.bookId}
                          className="text-[10.5px] font-bold text-[#8C5D19] hover:text-red-700 hover:bg-red-50 px-2.5 py-1 rounded-lg border border-[#E2C78A] hover:border-red-200 transition-colors flex items-center gap-1 bg-white/90 shadow-2xs"
                          title="Qadalganlikni bekor qilish"
                        >
                          <PinOff className="w-3 h-3 text-[#A07024]" />
                          <span>Qadalganlikni bekor qilish</span>
                        </button>
                      </div>
                    )}

                    <div className="flex items-start gap-3">
                      <div className="relative flex-shrink-0">
                        <img
                          src={item.coverImage}
                          alt={item.title}
                          className={`w-13 h-18 rounded-xl object-cover shadow-xs group-hover:scale-103 transition-transform ${
                            item.isPinned ? 'ring-2 ring-[#E5C687]' : ''
                          }`}
                          referrerPolicy="no-referrer"
                        />
                        {item.isPinned && (
                          <div className="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-[#FAF0DC] border border-[#E5C687] text-[#8C5D19] flex items-center justify-center text-[10px] font-black shadow-2xs">
                            📌
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4
                            className={`text-xs font-bold truncate ${
                              item.isPinned
                                ? 'text-[#3B2C15] group-hover:text-[#B87D1B]'
                                : 'text-[#2D2B26] group-hover:text-[#2C5338]'
                            } transition-colors`}
                          >
                            {item.title}
                          </h4>

                          <div className="flex items-center gap-2 flex-shrink-0">
                            <div className="flex items-center text-[#D49A3D] text-[11px] font-bold">
                              <Star className="w-3.5 h-3.5 fill-[#D49A3D] text-[#D49A3D] mr-0.5" />
                              <span>{item.rating}.0</span>
                            </div>

                            {/* If not pinned: Pin button */}
                            {!item.isPinned && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleTogglePin(item);
                                }}
                                disabled={pinningBookId === item.bookId}
                                className="px-2.5 py-1 rounded-lg text-[10.5px] font-bold bg-white hover:bg-[#FAF1DF] text-[#5A574F] hover:text-[#8C5D19] border border-[#DDD7CD] hover:border-[#E5C687] transition-all flex items-center gap-1 shadow-2xs"
                                title="Profilingiz yuqorisiga qadash (Faqat Premium tarifda)"
                              >
                                <span>📌</span>
                                <span>Qadash</span>
                              </button>
                            )}
                          </div>
                        </div>

                        <p className="text-[11px] text-[#757268]">{item.author}</p>

                        <div className="flex items-center gap-2 mt-1.5 text-[10px] text-[#8F8B7F] flex-wrap">
                          <span
                            className={`px-2 py-0.5 rounded-md font-medium border ${
                              item.isPinned
                                ? 'bg-[#FAF0DC] text-[#8C5D19] border-[#E8DFC8]'
                                : 'bg-[#FAF2E3] text-[#8C5D19] border-[#E8DFC8]'
                            }`}
                          >
                            {item.genre}
                          </span>
                          <span>•</span>
                          <span>O'qilgan: {item.readAt?.split('T')[0] || item.readAt}</span>
                          {item.libraryName && (
                            <>
                              <span>•</span>
                              <span>{item.libraryName}</span>
                            </>
                          )}
                        </div>

                        {item.notes && (
                          <p
                            className={`text-[11px] p-2 rounded-xl mt-2 italic line-clamp-2 border ${
                              item.isPinned
                                ? 'bg-white/80 text-[#54432A] border-[#EAD5AB]'
                                : 'text-[#5A574F] bg-[#F5EFE6]/60 border-[#EAE4D8]'
                            }`}
                          >
                            "{item.notes}"
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {/* Pagination Controls */}
                {!showAllReadBooks && profileData.readBooks.total > profileData.readBooks.limit && (
                  <div className="flex items-center justify-between pt-2 px-1 text-xs">
                    <span className="text-[#757268] text-[11px]">
                      Sahifa {profileData.readBooks.page} / {Math.ceil(profileData.readBooks.total / profileData.readBooks.limit)} ({profileData.readBooks.total} ta kitob)
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleReadBooksPageChange(readBooksPage - 1)}
                        disabled={readBooksPage <= 1}
                        className="px-3 py-1 bg-white border border-[#DDD7CD] rounded-xl text-xs font-semibold text-[#4A473F] disabled:opacity-40 hover:bg-[#F2EFE8]"
                      >
                        Oldingi
                      </button>
                      <button
                        onClick={() => handleReadBooksPageChange(readBooksPage + 1)}
                        disabled={!profileData.readBooks.hasMore}
                        className="px-3 py-1 bg-[#2C5338] text-white rounded-xl text-xs font-semibold disabled:opacity-40 hover:bg-[#23422C]"
                      >
                        Keyingi
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Tab 4: Social Following (Obunalar) */}
        {activeTab === 'following' && (
          <div className="space-y-3">
            {/* Subtabs for Following: All, Libraries, Publishers, Bloggers */}
            <div className="flex gap-1.5 bg-[#FAF8F5] p-1 rounded-xl border border-[#E6E1D6] text-[11px] font-bold text-[#5A574F]">
              <button
                onClick={() => setFollowingSubTab('all')}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  followingSubTab === 'all'
                    ? 'bg-[#2C5338] text-white shadow-2xs'
                    : 'hover:text-[#2D2B26]'
                }`}
              >
                Barchasi ({allFollowings.length})
              </button>
              <button
                onClick={() => setFollowingSubTab('libraries')}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  followingSubTab === 'libraries'
                    ? 'bg-[#2C5338] text-white shadow-2xs'
                    : 'hover:text-[#2D2B26]'
                }`}
              >
                Kutubxonalar ({profileData?.followings.libraries.length || 0})
              </button>
              <button
                onClick={() => setFollowingSubTab('publishers')}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  followingSubTab === 'publishers'
                    ? 'bg-[#2C5338] text-white shadow-2xs'
                    : 'hover:text-[#2D2B26]'
                }`}
              >
                Nashriyotlar ({profileData?.followings.publishers.length || 0})
              </button>
              <button
                onClick={() => setFollowingSubTab('bloggers')}
                className={`flex-1 py-1.5 rounded-lg transition-all ${
                  followingSubTab === 'bloggers'
                    ? 'bg-[#2C5338] text-white shadow-2xs'
                    : 'hover:text-[#2D2B26]'
                }`}
              >
                Kitobxonlar ({profileData?.followings.bloggers.length || 0})
              </button>
            </div>

            {filteredFollowings.length === 0 ? (
              <div className="py-8 text-center bg-[#FAF8F5] rounded-2xl border border-[#E6E1D6] p-4">
                <Users className="w-8 h-8 text-[#8F8B7F] mx-auto mb-2" />
                <p className="text-xs text-[#757268]">Obunalar topilmadi</p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredFollowings.map((item) => {
                  const targetType: 'USER' | 'LIBRARY' | 'PUBLISHER' =
                    item.type === 'LIBRARY'
                      ? 'LIBRARY'
                      : item.type === 'PUBLISHER'
                      ? 'PUBLISHER'
                      : 'USER';

                  return (
                    <div
                      key={item.id}
                      className="bg-[#FAF8F5] border border-[#E6E1D6] hover:border-[#2C5338]/30 rounded-2xl p-3 flex items-center justify-between gap-3 shadow-2xs transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={item.avatarOrLogo}
                          alt={item.name}
                          className="w-11 h-11 rounded-xl object-cover border border-[#DDD7CD] flex-shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="text-xs font-bold text-[#2D2B26] truncate">{item.name}</h4>
                            <span
                              className={`text-[9px] px-1.5 py-0.2 rounded-md font-bold ${
                                item.type === 'LIBRARY'
                                  ? 'bg-[#FAF2E3] text-[#8C5D19]'
                                  : item.type === 'PUBLISHER'
                                  ? 'bg-[#EAF3EC] text-[#2C5338]'
                                  : 'bg-[#F2EFE8] text-[#5A574F]'
                              }`}
                            >
                              {item.type === 'LIBRARY'
                                ? 'ARM Kutubxona'
                                : item.type === 'PUBLISHER'
                                ? 'Nashriyot'
                                : 'Kitobxon'}
                            </span>
                          </div>

                          {item.username && (
                            <p className="text-[11px] font-mono text-[#8F8B7F]">@{item.username}</p>
                          )}

                          <p className="text-[11px] text-[#757268] truncate mt-0.5">
                            {item.description}
                          </p>
                        </div>
                      </div>

                      {/* Realtime Follow / Unfollow Button */}
                      <button
                        onClick={() => handleToggleFollow(targetType, item.id, item.name)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer ${
                          item.isFollowing
                            ? 'bg-[#FAF2E3] text-[#8C5D19] border border-[#E8DFC8] hover:bg-[#F2E8D3]'
                            : 'bg-[#2C5338] text-white hover:bg-[#23422C] shadow-2xs'
                        }`}
                      >
                        {item.isFollowing ? (
                          <>
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>Obunadasiz</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3.5 h-3.5" />
                            <span>Obuna bo'lish</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Tab 5: Stats */}
        {activeTab === 'stats' && (
          <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl p-4 space-y-4 shadow-2xs text-xs">
            <h4 className="font-bold text-[#3D3B35] flex items-center gap-2">
              <Award className="w-4 h-4 text-[#D49A3D]" />
              <span>Oylik va yillik mutolaa ko'rsatkichlari</span>
            </h4>

            {/* Reading goal progress */}
            <div className="p-3 bg-white border border-[#EAE4D8] rounded-xl space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-[#2D2B26]">2026 Yillik Maqsad (30 ta kitob)</span>
                <span className="font-bold text-[#2C5338]">{booksReadCount} / 30 ({Math.round((booksReadCount / 30) * 100)}%)</span>
              </div>
              <div className="w-full h-2.5 bg-[#EFECE3] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#2C5338] to-[#458057] rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.round((booksReadCount / 30) * 100))}%` }}
                />
              </div>
            </div>

            <div className="space-y-2.5 text-[#615E54]">
              <div className="flex justify-between items-center py-1 border-b border-[#EAE5DA]">
                <span>O'qilgan sahifalar soni:</span>
                <span className="font-bold text-[#3D3B35]">1,480 bet</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#EAE5DA]">
                <span>Kutubxonaga tashriflar:</span>
                <span className="font-bold text-[#3D3B35]">8 marta</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#EAE5DA]">
                <span>Sevimli janr:</span>
                <span className="font-bold text-[#2C5338]">O'zbek mumtoz adabiyoti & Tarix</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span>Kitob fondiga ehsonlar:</span>
                <span className="font-bold text-[#AD4D39]">50,000 so'm</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 4. Active Library Switcher Card */}
      <div
        id="active-library-profile-card"
        onClick={onOpenLibrarySwitcher}
        className="p-4 bg-[#FAF8F5] border border-[#E6E1D6] hover:border-[#5A5A40]/40 rounded-2xl transition-all cursor-pointer shadow-2xs group"
      >
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-[11px] font-bold text-[#757268] uppercase tracking-wider flex items-center gap-1.5">
            <Landmark className="w-3.5 h-3.5 text-[#5A5A40]" />
            Biriktirilgan Kutubxona (ARM)
          </span>
          <span className="text-[11px] text-[#5A5A40] font-bold group-hover:underline flex items-center gap-0.5">
            <span>O'zgartirish</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-2xs flex-shrink-0"
            style={{ background: activeLibrary.gradient }}
          >
            <Landmark className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-bold text-[#3D3B35] group-hover:text-[#5A5A40] transition-colors truncate">
              {activeLibrary.name}
            </h4>
            <p className="text-[11px] text-[#757268] truncate mt-0.5">{activeLibrary.address}</p>
            <div className="flex items-center gap-2 mt-1.5 text-[10px]">
              <span className="text-[#8C5D19] font-semibold bg-[#FAF2E3] px-2 py-0.5 rounded border border-[#E8DFC8]">
                {activeLibrary.enteredBooks} ta kitob kiritilgan
              </span>
              <span className="text-[#8F8B7F]">{activeLibrary.workingHours}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 5. BookMall Rasmiy Oynasi & Kunning Hikmatlari */}
      {onOpenWelcomeSplash && (
        <div
          id="bookmall-wisdom-profile-card"
          onClick={onOpenWelcomeSplash}
          className="p-4 bg-gradient-to-br from-[#FAF2E3] via-[#FDFBF7] to-[#F5EFE3] border border-[#E8DFC8] hover:border-[#D49A3D]/70 rounded-2xl transition-all cursor-pointer shadow-2xs group relative overflow-hidden"
        >
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-[10.5px] font-bold text-[#8C5D19] uppercase tracking-wider bg-[#FAF2E3] px-2.5 py-0.5 rounded-full border border-[#E8DFC8] flex items-center gap-1.5 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#D49A3D]" />
              BookMall Rasmiy Oynasi
            </span>
            <span className="text-[11px] text-[#8C5D19] font-bold group-hover:underline flex items-center gap-0.5">
              <span>Alohida oynani ochish</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-13 h-13 rounded-2xl overflow-hidden border border-[#E6E1D6] bg-white p-1 shadow-2xs flex-shrink-0 group-hover:scale-105 transition-transform">
              <img
                src={bookmallLogoImg}
                alt="BookMall"
                className="w-full h-full object-contain rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-bold font-serif-book text-[#2D2B26] leading-snug">
                Book<span className="text-[#2C5338]">Mall</span> — Kunning Hikmati & Intro
              </h4>
              <p className="text-[11.5px] text-[#757268] mt-0.5 line-clamp-1 font-serif-book italic">
                Adabiy hikmatlar, 45,000+ fond va 3-kadrli kinematik intro
              </p>
              <div className="flex items-center gap-2 mt-1.5 text-[10px]">
                <span className="text-[#8C5D19] font-semibold bg-[#FAF2E3] px-2 py-0.5 rounded border border-[#E8DFC8]">
                  Kunning hikmati
                </span>
                <span className="text-[#2C5338] font-semibold bg-[#EAF3EC] px-2 py-0.5 rounded border border-[#CFE4D4]">
                  Kinematik intro
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. Settings & Quick Actions Menu */}
      <div className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-2xl overflow-hidden divide-y divide-[#EAE5DA] shadow-2xs">
        <button
          onClick={onOpenLibrarySwitcher}
          className="w-full p-3.5 flex items-center justify-between hover:bg-[#F2EFE8] transition-colors text-xs font-medium text-[#3D3B35] cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <Landmark className="w-4 h-4 text-[#5A5A40]" />
            <span>Kutubxona manzilini o'zgartirish</span>
          </div>
          <ChevronRight className="w-4 h-4 text-[#8F8B7F]" />
        </button>

        <button
          onClick={onOpenDonationModal}
          className="w-full p-3.5 flex items-center justify-between hover:bg-[#F2EFE8] transition-colors text-xs font-medium text-[#3D3B35] cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <Heart className="w-4 h-4 text-[#AD4D39]" />
            <span>Kitob fondiga ehson qilish</span>
          </div>
          <ChevronRight className="w-4 h-4 text-[#8F8B7F]" />
        </button>

        {/* Library Admin Dashboard Access Button with RBAC Verification */}
        <button
          onClick={() => setActiveAppView('admin')}
          className="w-full p-3.5 flex items-center justify-between hover:bg-[#F2EFE8] transition-colors text-xs font-bold text-[#2D2A26] cursor-pointer bg-[#F5F2EB]/60 border-t border-[#ECE7DC]"
        >
          <div className="flex items-center gap-2.5">
            <LayoutDashboard className="w-4 h-4 text-[#5A5A40]" />
            <div className="text-left">
              <span className="text-[#2D2A26]">Kutubxona Admin Paneli</span>
              <p className="text-[10px] font-normal text-[#8C8677]">
                {currentUser.role === 'LIBRARY_ADMIN'
                  ? "Kutubxona boshqaruviga o'tish"
                  : "Faqat LIBRARY_ADMIN uchun (RBAC 403 test)"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                currentUser.role === 'LIBRARY_ADMIN'
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {currentUser.role === 'LIBRARY_ADMIN' ? 'Ruxsat bor' : '403 Himoya'}
            </span>
            <ChevronRight className="w-4 h-4 text-[#8F8B7F]" />
          </div>
        </button>

        <button
          onClick={() => alert("BookMall Qo'llab-quvvatlash xizmati: @bookmall_uz (Telegram)")}
          className="w-full p-3.5 flex items-center justify-between hover:bg-[#F2EFE8] transition-colors text-xs font-medium text-[#3D3B35] cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <HelpCircle className="w-4 h-4 text-[#5A5850]" />
            <span>Yordam va qo'llab-quvvatlash</span>
          </div>
          <ChevronRight className="w-4 h-4 text-[#8F8B7F]" />
        </button>
      </div>

      {/* Profile Edit Modal */}
      {showEditProfileModal && (
        <EditProfileModal
          user={currentUser}
          onClose={() => setShowEditProfileModal(false)}
          onSuccess={(updatedUser) => {
            updateCurrentUser(updatedUser);
            fetchProfile();
            setActionSuccessMsg("Profil ma'lumotlari muvaffaqiyatli yangilandi");
            setTimeout(() => setActionSuccessMsg(null), 3000);
          }}
        />
      )}

      {/* Change Avatar Modal */}
      {showChangeAvatarModal && (
        <ChangeAvatarModal
          currentAvatar={currentUser.avatar}
          onClose={() => setShowChangeAvatarModal(false)}
          onSuccess={(newAvatar) => {
            updateCurrentUser({ avatar: newAvatar });
            fetchProfile();
            setActionSuccessMsg("Profil rasmi yangilandi");
            setTimeout(() => setActionSuccessMsg(null), 3000);
          }}
        />
      )}

      {/* Mark Book as Read Modal */}
      {showMarkReadModal && (
        <MarkReadBookModal
          onClose={() => setShowMarkReadModal(false)}
          onSuccess={() => {
            fetchProfile(readBooksPage);
            fetchAllReadBooksForModal();
            setActionSuccessMsg("Kitob o'qilganlar ro'yxatiga qo'shildi!");
            setTimeout(() => setActionSuccessMsg(null), 3000);
          }}
        />
      )}

      {/* Premium Plan Modal */}
      {showPremiumModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#E8DFC8] relative animate-in fade-in zoom-in-95 duration-150 space-y-5">
            {/* Top decorative badge */}
            <div className="text-center space-y-2">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-[#FAF0DC] via-[#F7E2B5] to-[#FAF0DC] border border-[#E5C687] flex items-center justify-center shadow-xs">
                <Crown className="w-7 h-7 text-[#B87D1B]" />
              </div>
              <h3 className="text-base font-extrabold text-[#2D2B26]">
                Kitobni qadash — Premium Tarif
              </h3>
              <p className="text-xs text-[#757268] leading-relaxed max-w-sm mx-auto">
                O'qilgan kitoblarni ro'yxatning eng yuqori qismiga qadash imkoniyati faqat
                <span className="font-bold text-[#8C5D19]"> Premium tarif</span> a'zolari uchun mavjud.
              </p>
            </div>

            {/* Feature Points */}
            <div className="space-y-2.5 bg-[#FAF8F5] p-3.5 rounded-2xl border border-[#EAE3D2]">
              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-lg bg-[#FAF0DC] text-[#8C5D19] border border-[#E5C687] flex items-center justify-center flex-shrink-0 text-xs font-bold">
                  📌
                </div>
                <div className="text-xs text-[#3D3A33]">
                  <p className="font-bold text-[#2D2B26]">1-, 2-, 3-o'rinlarda doimiy qadash</p>
                  <p className="text-[11px] text-[#757268]">
                    Qadalgan sara kitoblar har doim o'qilganlar ro'yxatining eng yuqorisida saqlanadi.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-lg bg-[#FAF0DC] text-[#8C5D19] border border-[#E5C687] flex items-center justify-center flex-shrink-0 text-xs font-bold">
                  ⭐
                </div>
                <div className="text-xs text-[#3D3A33]">
                  <p className="font-bold text-[#2D2B26]">Maxsus nishon va qadalganlik tartibi</p>
                  <p className="text-[11px] text-[#757268]">
                    Kitob ustida maxsus 📌 belgisi va uning 1-, 2-, 3-qadalganlik tartib raqami ko'rinadi.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-lg bg-[#FAF0DC] text-[#8C5D19] border border-[#E5C687] flex items-center justify-center flex-shrink-0 text-xs font-bold">
                  ⚡
                </div>
                <div className="text-xs text-[#3D3A33]">
                  <p className="font-bold text-[#2D2B26]">Qulay boshqaruv</p>
                  <p className="text-[11px] text-[#757268]">
                    Istalgan vaqtda yangi kitobni qadashingiz yoki qadalganlikni bekor qilishingiz mumkin.
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-1">
              <button
                onClick={() => handleSwitchPlan('PREMIUM')}
                className="w-full py-3 px-4 bg-gradient-to-r from-[#D49A3D] via-[#C5862B] to-[#B3741E] hover:opacity-95 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Crown className="w-4 h-4 text-amber-100" />
                <span>Premium Tarifni Faollashtirish (Sinov)</span>
              </button>

              <button
                onClick={() => setShowPremiumModal(false)}
                className="w-full py-2.5 px-4 bg-white hover:bg-[#F2EFE8] text-[#5A574F] font-bold text-xs rounded-xl border border-[#DDD7CD] transition-colors cursor-pointer"
              >
                Keyinroq
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Long Read Books Modal (1, 2, 3 kitoblar qadalgan) */}
      <ReadBooksListModal
        isOpen={showReadBooksModal}
        onClose={() => setShowReadBooksModal(false)}
        books={allReadBooksList.length > 0 ? allReadBooksList : (profileData?.readBooks.items || [])}
        totalBooksCount={booksReadCount}
        isPremiumUser={currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM' || currentUser.subscriptionPlan === 'VIP'}
        onTogglePin={handleTogglePin}
        pinningBookId={pinningBookId}
        onSelectBook={onSelectBook}
        onOpenAddBook={() => {
          setShowReadBooksModal(false);
          setShowMarkReadModal(true);
        }}
        onSwitchPlan={() => {
          setShowReadBooksModal(false);
          setShowPremiumModal(true);
        }}
      />
    </div>
  );
};
