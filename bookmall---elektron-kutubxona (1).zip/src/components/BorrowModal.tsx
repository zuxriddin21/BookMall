import React, { useState, useEffect } from 'react';
import { X, BookOpen, Calendar, MapPin, CheckCircle, ShieldCheck, UserCheck, ChevronRight, AlertCircle, Loader2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Book, LibraryItem } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

interface BorrowModalProps {
  book: Book | null;
  libraries: LibraryItem[];
  activeLibrary: LibraryItem;
  onClose: () => void;
  onSuccess: (book: Book, durationDays: number, selectedLibrary: string) => void;
}

export const BorrowModal: React.FC<BorrowModalProps> = ({
  book,
  libraries,
  activeLibrary,
  onClose,
  onSuccess,
}) => {
  const { user, token } = useAuth();
  const [selectedLib, setSelectedLib] = useState(activeLibrary.name);
  const [durationDays, setDurationDays] = useState<number>(14);
  const [fullName, setFullName] = useState(user?.name || 'Durbek Rahmonov');
  const [phone, setPhone] = useState(user?.phone || '+998 90 123-45-67');
  const [readerCardId] = useState(user?.id ? `LIB-${user.id.slice(-5).toUpperCase()}` : 'LIB-84920');
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      if (user.name) setFullName(user.name);
      if (user.phone) setPhone(user.phone);
    }
  }, [user]);

  if (!book) return null;

  const returnDate = new Date();
  returnDate.setDate(returnDate.getDate() + durationDays);
  const returnDateStr = returnDate.toLocaleDateString('uz-UZ', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsSubmitting(true);

    try {
      // Direct call to backend with concurrency lock
      const targetLib = libraries.find((l) => l.name === selectedLib) || activeLibrary;
      await api.loans.borrow(
        {
          bookId: book.id,
          durationDays,
          libraryId: targetLib.id,
          fullName,
          phone,
          bookTitle: book.title,
          bookAuthor: book.author,
          bookCover: book.cover,
          genre: book.genre,
        },
        token
      );

      setSubmitted(true);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
      setTimeout(() => {
        onSuccess(book, durationDays, selectedLib);
        onClose();
      }, 1800);
    } catch (err: any) {
      console.error('Borrow error:', err);
      // Handles: "Kitob hozir boshqa foydalanuvchiga berildi yoki mavjud emas."
      setErrorMessage(err.message || "Kitob hozir boshqa foydalanuvchiga berildi yoki mavjud emas.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="borrow-modal"
        className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Kitobni band qilish</h3>
              <p className="text-[11px] text-slate-500">Elektron buyurtma va qabul qilish</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 flex flex-col items-center text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center animate-bounce">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Muvaffaqiyatli band qilindi!</h3>
            <p className="text-xs text-slate-600 max-w-xs">
              Sizning buyurtmangiz qabul qilindi. 24 soat ichida <b>{selectedLib}</b>dan kitobingizni olib ketishingiz mumkin.
            </p>
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-800 w-full text-left space-y-1">
              <p>📌 <b>Qaytarish muddati:</b> {returnDateStr}</p>
              <p>🪪 <b>Kitobxon ID:</b> {readerCardId}</p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleConfirm} className="p-5 space-y-4 overflow-y-auto max-h-[80vh]">
            {/* Selected Book Summary */}
            <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200/70">
              <div
                className="w-12 h-16 rounded-md flex-shrink-0 flex items-center justify-center p-1 text-center shadow-xs"
                style={{
                  background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
                    ? book.cover
                    : `url(${book.cover}) center/cover no-repeat`,
                }}
              >
                <span className={`text-[8px] font-serif-book font-bold line-clamp-2 ${book.light ? 'text-slate-900' : 'text-white'}`}>
                  {book.title}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-slate-900 truncate">{book.title}</h4>
                <p className="text-[11px] text-slate-500 truncate">{book.author}</p>
                <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-md mt-1 ${
                  book.available ? 'text-emerald-700 bg-emerald-100/80' : 'text-red-700 bg-red-100/80'
                }`}>
                  {book.available ? "Mavjud nusxa bor" : "Hozircha mavjud emas"}
                </span>
              </div>
            </div>

            {/* Error Alert if Concurrency rejection or out of stock */}
            {errorMessage && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-800 animate-in fade-in duration-200">
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold text-red-900">Buyurtma rad etildi</p>
                  <p className="text-[11px] mt-0.5 leading-relaxed">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* Library Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-blue-600" />
                Olib ketish manzili (Kutubxona)
              </label>
              <select
                value={selectedLib}
                onChange={(e) => setSelectedLib(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                {libraries.map((lib) => (
                  <option key={lib.id} value={lib.name}>
                    {lib.name} ({lib.address})
                  </option>
                ))}
              </select>
            </div>

            {/* Borrow Duration */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                Ijara muddati
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[10, 14, 30].map((days) => (
                  <button
                    key={days}
                    type="button"
                    onClick={() => setDurationDays(days)}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border transition-all ${
                      durationDays === days
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {days} kun
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5">
                Topshirish oxirgi sanasi: <b className="text-slate-800">{returnDateStr}</b>
              </p>
            </div>

            {/* Reader Card Verification */}
            <div className="bg-blue-50/60 border border-blue-100 rounded-xl p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-blue-900 flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5 text-blue-600" /> Kitobxon kartasi:
                </span>
                <span className="font-mono font-bold text-blue-700">{readerCardId}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-slate-500 block">F.I.O</label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full text-xs p-1.5 bg-white border border-slate-200 rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-500 block">Telefon</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full text-xs p-1.5 bg-white border border-slate-200 rounded-lg"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Rule note */}
            <div className="flex items-start gap-2 text-[11px] text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              <span>Kitobni belgilangan muddatda qaytarish kafolatlanadi. Kutubxona xizmati mutlaqo bepul.</span>
            </div>

            {/* Submit button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-blue-600/20 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Tekshirilmoqda va band qilinmoqda...</span>
                  </>
                ) : (
                  <>
                    <span>Band qilishni tasdiqlash</span>
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
