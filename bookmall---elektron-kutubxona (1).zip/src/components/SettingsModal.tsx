import React, { useState, useEffect } from 'react';
import {
  X,
  Settings,
  Moon,
  Sun,
  Crown,
  Sparkles,
  BookOpen,
  User as UserIcon,
  AtSign,
  Check,
  Loader2,
  Edit3
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';

interface SettingsModalProps {
  onClose: () => void;
  onOpenDonationModal?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const { currentUser, updateCurrentUser, token } = useAuth();

  // Settings states with localStorage persistence
  const [theme, setTheme] = useState<'light' | 'sepia' | 'dark'>(() => {
    return (localStorage.getItem('bookmall_theme') as any) || 'sepia';
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isSwitchingTariff, setIsSwitchingTariff] = useState(false);

  // Profile Edit states
  const [nameInput, setNameInput] = useState(currentUser.name || '');
  const [usernameInput, setUsernameInput] = useState(currentUser.username || '');
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [profileSaveSuccess, setProfileSaveSuccess] = useState(false);

  // Synchronize inputs when currentUser changes
  useEffect(() => {
    setNameInput(currentUser.name || '');
    setUsernameInput(currentUser.username || '');
  }, [currentUser.name, currentUser.username]);

  // Show temporary toast notification
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Update theme
  const handleThemeChange = (newTheme: 'light' | 'sepia' | 'dark') => {
    setTheme(newTheme);
    localStorage.setItem('bookmall_theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    showToast(
      newTheme === 'light'
        ? "Yorug' (Oq) mavzu faollashtirildi"
        : newTheme === 'dark'
        ? "Tungi (Qorong'i) mavzu tanlandi"
        : "Klassik kitob qog'ozi (Sepia) mavzusi tanlandi"
    );
  };

  // Cycle theme: sepia -> light -> dark -> sepia
  const cycleTheme = () => {
    let nextTheme: 'sepia' | 'light' | 'dark' = 'light';
    if (theme === 'sepia') nextTheme = 'light';
    else if (theme === 'light') nextTheme = 'dark';
    else nextTheme = 'sepia';
    handleThemeChange(nextTheme);
  };

  // Toggle subscription plan directly from settings
  const handleToggleTariff = async () => {
    setIsSwitchingTariff(true);
    const newPlan = currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM' ? 'FREE' : 'PREMIUM';
    try {
      const res = await api.profile.setSubscriptionPlan(newPlan, token);
      updateCurrentUser({
        isPremium: newPlan === 'PREMIUM',
        subscriptionPlan: newPlan,
      });
      showToast(res.message);
    } catch (err: any) {
      showToast("Tarifni o'zgartirishda xatolik yuz berdi");
    } finally {
      setIsSwitchingTariff(false);
    }
  };

  // Check whether name or username was modified
  const currentCleanUsername = (currentUser.username || '').replace(/^@/, '').trim().toLowerCase();
  const inputCleanUsername = usernameInput.replace(/^@/, '').trim().toLowerCase();
  const hasChanges = (nameInput.trim() !== (currentUser.name || '').trim()) || (inputCleanUsername !== currentCleanUsername);

  // Save profile changes (Name and Username)
  const handleSaveProfile = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmedName = nameInput.trim();
    const cleanUsername = usernameInput.replace(/^@/, '').trim().toLowerCase().replace(/\s+/g, '_');

    if (!trimmedName) {
      showToast("Iltimos, ismingizni kiriting");
      return;
    }

    setIsSavingProfile(true);
    try {
      await api.profile.update(
        {
          name: trimmedName,
          username: cleanUsername || undefined,
        },
        token
      );

      updateCurrentUser({
        name: trimmedName,
        username: cleanUsername || undefined,
      });

      setProfileSaveSuccess(true);
      showToast("Ism va foydalanuvchi nomi muvaffaqiyatli saqlandi!");
      setTimeout(() => setProfileSaveSuccess(false), 2500);
    } catch (err: any) {
      // Fallback local update
      updateCurrentUser({
        name: trimmedName,
        username: cleanUsername || undefined,
      });
      setProfileSaveSuccess(true);
      showToast("Ism va foydalanuvchi nomi yangilandi!");
      setTimeout(() => setProfileSaveSuccess(false), 2500);
    } finally {
      setIsSavingProfile(false);
    }
  };

  const isDark = theme === 'dark';
  const isLight = theme === 'light';

  // Dynamic styling classes for responsive theme adaptation
  const modalBg = isDark
    ? 'bg-[#1C1A17] text-[#EDE8DF] border-[#38332C]'
    : isLight
    ? 'bg-[#FAF9F7] text-[#2D2B26] border-[#E3DDD2]'
    : 'bg-[#FAF8F5] text-[#3D3B35] border-[#E6E1D6]';

  const headerBg = isDark
    ? 'bg-[#25221E]/95 border-[#38332C]'
    : isLight
    ? 'bg-[#F5F3ED]/95 border-[#E2DDD3]'
    : 'bg-[#F2EFE8]/85 border-[#EAE5DA]';

  const cardBg = isDark
    ? 'bg-[#24211D] border-[#3A352D] text-[#EDE8DF]'
    : isLight
    ? 'bg-white border-[#E5E0D6] text-[#2D2B26]'
    : 'bg-white border-[#E6E1D6] text-[#3D3B35]';

  const subCardBg = isDark
    ? 'bg-[#2D2924] border-[#3F3930]'
    : isLight
    ? 'bg-[#F7F5F0] border-[#E8E2D6]'
    : 'bg-[#FAF8F5] border-[#EAE4D8]';

  const inputBg = isDark
    ? 'bg-[#1D1A17] border-[#3F3930] text-[#EDE8DF] placeholder-[#736E64] focus:border-[#4B855B]'
    : isLight
    ? 'bg-[#F9F8F5] border-[#DED7CB] text-[#2D2B26] placeholder-[#A09B8F] focus:border-[#2C5338]'
    : 'bg-[#FDFBF7] border-[#E2DBD0] text-[#3D3B35] placeholder-[#9E988A] focus:border-[#2C5338]';

  const textMuted = isDark ? 'text-[#9E988D]' : 'text-[#757268]';
  const textHeading = isDark ? 'text-[#F5F2EB]' : 'text-[#2D2B26]';
  const sectionLabel = isDark ? 'text-[#A8A398]' : 'text-[#8F8B7F]';

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="settings-modal"
        className={`w-full sm:max-w-md max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300 border transition-colors ${modalBg}`}
      >
        {/* Modal Header */}
        <div className={`flex items-center justify-between px-4 sm:px-5 py-3.5 border-b backdrop-blur-sm transition-colors duration-200 ${headerBg}`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#2C5338] text-white flex items-center justify-center shadow-xs">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className={`text-sm font-extrabold ${textHeading}`}>Ilova Sozlamalari</h3>
              <p className={`text-[10.5px] ${textMuted}`}>BookMall shaxsiy parametrlari</p>
            </div>
          </div>

          {/* Top Right: Compact Theme Switcher (Kitob -> Yorug' -> Tungi) + Close Button */}
          <div className="flex items-center gap-2">
            <button
              id="header-theme-cycle-btn"
              onClick={cycleTheme}
              title={`Mavzu: ${
                theme === 'sepia'
                  ? 'Kitob (Sepia)'
                  : theme === 'light'
                  ? 'Yorug‘ (Oq)'
                  : 'Tungi (Qorong‘i)'
              }. Bosilganda o‘zgaradi`}
              className={`group flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shadow-2xs hover:scale-[1.03] active:scale-95 ${
                theme === 'sepia'
                  ? 'bg-[#FAF0DC] border-[#E5C687] text-[#7A531A] hover:bg-[#F5E6CA]'
                  : theme === 'light'
                  ? 'bg-white border-[#DDD7CD] text-[#2D2B26] hover:bg-[#F9F8F6]'
                  : 'bg-[#2D2A26] border-[#4B463C] text-amber-200 hover:bg-[#36322C]'
              }`}
            >
              <span className="flex items-center justify-center transition-transform duration-200 group-hover:rotate-12">
                {theme === 'sepia' && <BookOpen className="w-3.5 h-3.5 text-[#8C5D19]" />}
                {theme === 'light' && <Sun className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />}
                {theme === 'dark' && <Moon className="w-3.5 h-3.5 text-indigo-300 fill-indigo-300" />}
              </span>
              <span className="text-[11px] font-extrabold tracking-tight">
                {theme === 'sepia' ? 'Kitob' : theme === 'light' ? "Yorug'" : 'Tungi'}
              </span>
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  theme === 'sepia'
                    ? 'bg-[#A07024]'
                    : theme === 'light'
                    ? 'bg-amber-500'
                    : 'bg-indigo-400'
                }`}
              />
            </button>

            <button
              onClick={onClose}
              className={`p-1.5 rounded-full transition-colors cursor-pointer ${
                isDark
                  ? 'text-[#A09B90] hover:text-white hover:bg-[#38332C]'
                  : 'text-[#8F8B7F] hover:text-[#2D2B26] hover:bg-[#EAE5DA]'
              }`}
              title="Yopish"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Settings Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 no-scrollbar">
          {/* Toast Notification Alert inside modal */}
          {toastMessage && (
            <div className="p-2.5 bg-[#2C5338] text-white text-xs font-semibold rounded-xl text-center shadow-xs animate-in fade-in slide-in-from-top-2 duration-200">
              {toastMessage}
            </div>
          )}

          {/* Section 1: User Account & Subscription Status */}
          <div className={`rounded-2xl p-3.5 border shadow-2xs space-y-3 ${cardBg}`}>
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-extrabold uppercase tracking-wider ${sectionLabel}`}>
                Hisob va Tarif
              </span>
              <span className={`text-[10.5px] ${textMuted}`}>ID: {currentUser.id}</span>
            </div>

            <div className={`flex items-center justify-between gap-3 p-3 rounded-xl border ${subCardBg}`}>
              <div className="flex items-center gap-2.5">
                <div className="relative">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-10 h-10 rounded-xl object-cover ring-1 ring-[#DDD7CD]"
                  />
                  {(currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM') && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FAF0DC] text-[#8C5D19] border border-[#E5C687] flex items-center justify-center text-[9px]">
                      ⭐
                    </span>
                  )}
                </div>
                <div>
                  <h4 className={`text-xs font-bold flex items-center gap-1.5 flex-wrap ${textHeading}`}>
                    <span>{currentUser.name}</span>
                    {currentUser.username && (
                      <span className="text-[10.5px] font-semibold text-[#2C5338] bg-[#E3EFE5] px-1.5 py-0.5 rounded-md">
                        @{currentUser.username}
                      </span>
                    )}
                  </h4>
                  <p className={`text-[10px] ${textMuted}`}>{currentUser.email}</p>
                </div>
              </div>

              {/* Tariff Badge */}
              {currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM' ? (
                <div className="text-right">
                  <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#FAF0DC] border border-[#E5C687] text-[#8C5D19] text-[10.5px] font-extrabold shadow-2xs">
                    <Crown className="w-3 h-3 text-[#B87D1B]" />
                    <span>Premium</span>
                  </div>
                  <p className="text-[9px] text-[#2C5338] font-bold mt-0.5">📌 Qadash faol</p>
                </div>
              ) : (
                <div className="text-right">
                  <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border text-[10.5px] font-bold ${
                    isDark ? 'bg-[#35302A] border-[#443E36] text-[#CCC6BA]' : 'bg-[#EFECE6] border-[#DDD8CE] text-[#5A574F]'
                  }`}>
                    <span>Standart</span>
                  </div>
                  <p className="text-[9px] text-[#8C5D19] font-medium mt-0.5">Bepul tarif</p>
                </div>
              )}
            </div>

            {/* Quick Switcher button for testing */}
            <div className="flex items-center justify-between pt-1">
              <p className={`text-[11px] ${textMuted}`}>Tarif sinovi (Free / Premium):</p>
              <button
                onClick={handleToggleTariff}
                disabled={isSwitchingTariff}
                className="px-3 py-1.5 text-[11px] font-bold rounded-xl bg-[#FAF1DF] hover:bg-[#F5E2BE] text-[#8C5D19] border border-[#E5C687] transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#C08528]" />
                <span>
                  {currentUser.isPremium || currentUser.subscriptionPlan === 'PREMIUM'
                    ? "Standart tarifga o'tish"
                    : "⭐ Premiumni yoqish"}
                </span>
              </button>
            </div>
          </div>

          {/* Section: Profile Info (Name and Username Editing) */}
          <div className={`rounded-2xl p-3.5 border shadow-2xs space-y-3 ${cardBg}`}>
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-extrabold uppercase tracking-wider flex items-center gap-1.5 ${sectionLabel}`}>
                <Edit3 className="w-3 h-3" />
                <span>Ism va Foydalanuvchi nomini tahrirlash</span>
              </span>
              {hasChanges && (
                <span className="text-[10px] font-semibold text-[#8C5D19] bg-[#FAF0DC] px-1.5 py-0.5 rounded">
                  O'zgartirildi
                </span>
              )}
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-2.5">
              {/* Name input */}
              <div className="space-y-1">
                <label htmlFor="settings-edit-name" className={`text-[11px] font-bold block ${textHeading}`}>
                  To'liq ism
                </label>
                <div className="relative flex items-center">
                  <div className="absolute left-3 pointer-events-none text-[#8F8B7F]">
                    <UserIcon className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="text"
                    id="settings-edit-name"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="Ismingizni kiriting"
                    className={`w-full text-xs font-semibold pl-8.5 pr-3 py-2 rounded-xl border outline-hidden transition-colors ${inputBg}`}
                    required
                  />
                </div>
              </div>

              {/* Username input */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label htmlFor="settings-edit-username" className={`text-[11px] font-bold block ${textHeading}`}>
                    Foydalanuvchi nomi (Username)
                  </label>
                  <span className={`text-[9.5px] ${textMuted}`}>noyob login</span>
                </div>
                <div className="relative flex items-center">
                  <div className="absolute left-3 pointer-events-none text-[#8F8B7F]">
                    <AtSign className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="text"
                    id="settings-edit-username"
                    value={usernameInput}
                    onChange={(e) => {
                      const val = e.target.value.replace(/^@/, '').toLowerCase().replace(/\s+/g, '_');
                      setUsernameInput(val);
                    }}
                    placeholder="foydalanuvchi_nomi"
                    className={`w-full text-xs font-semibold pl-8.5 pr-3 py-2 rounded-xl border outline-hidden transition-colors ${inputBg}`}
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-1">
                {hasChanges && (
                  <button
                    type="button"
                    onClick={() => {
                      setNameInput(currentUser.name || '');
                      setUsernameInput(currentUser.username || '');
                    }}
                    className={`px-3 py-1.5 text-[11px] font-bold rounded-xl border transition-colors cursor-pointer ${
                      isDark ? 'border-[#3D3830] text-[#A8A398] hover:bg-[#2D2924]' : 'border-[#E2DDD3] text-[#757268] hover:bg-[#F2EFE8]'
                    }`}
                  >
                    Bekor qilish
                  </button>
                )}

                <button
                  type="submit"
                  disabled={isSavingProfile || !nameInput.trim() || !hasChanges}
                  className={`px-3.5 py-1.5 text-xs font-extrabold rounded-xl text-white transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer ${
                    profileSaveSuccess
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : !hasChanges || !nameInput.trim()
                      ? 'bg-[#2C5338]/40 opacity-60 cursor-not-allowed'
                      : 'bg-[#2C5338] hover:bg-[#23422C] active:scale-98'
                  }`}
                >
                  {isSavingProfile ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Saqlanmoqda...</span>
                    </>
                  ) : profileSaveSuccess ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Saqlandi!</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Saqlash</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* App Info & Support */}
          <div className={`p-3.5 rounded-2xl border text-center space-y-1.5 ${subCardBg}`}>
            <div className={`flex items-center justify-center gap-1 text-xs font-extrabold ${textHeading}`}>
              <span>BookMall</span>
              <span className="text-[10px] bg-[#E3EFE5] text-[#2C5338] px-1.5 py-0.5 rounded font-bold">
                v2.4.0
              </span>
            </div>
            <p className={`text-[10.5px] ${textMuted}`}>
              O'zbekiston Milliy Kutubxona tarmog'i va Elektron Fond
            </p>
            <p className="text-[10px] text-[#8F8B7F]">Qo'llab-quvvatlash: @bookmall_uz</p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className={`p-4 border-t ${headerBg}`}>
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 bg-[#2C5338] hover:bg-[#23422C] text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Tayyor (Yopish)
          </button>
        </div>
      </div>
    </div>
  );
};
