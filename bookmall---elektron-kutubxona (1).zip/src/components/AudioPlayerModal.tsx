import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, RotateCw, Volume2, Sparkles, FastForward } from 'lucide-react';
import { Book } from '../types';

interface AudioPlayerModalProps {
  book: Book | null;
  onClose: () => void;
}

export const AudioPlayerModal: React.FC<AudioPlayerModalProps> = ({ book, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(15);
  const [speed, setSpeed] = useState<number>(1.0);
  const [currentTime, setCurrentTime] = useState(42);
  const duration = 285; // 4:45

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000 / speed);
    }
    return () => clearInterval(interval);
  }, [isPlaying, speed]);

  if (!book) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const speeds = [0.8, 1.0, 1.25, 1.5, 2.0];

  const handleSpeedToggle = () => {
    const idx = speeds.indexOf(speed);
    const nextIdx = (idx + 1) % speeds.length;
    setSpeed(speeds[nextIdx]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div
        id="audio-player-modal"
        className="w-full max-w-sm bg-gradient-to-b from-[#2F2D25] via-[#25241E] to-[#1C1B17] text-[#FAF8F5] rounded-3xl shadow-2xl p-6 flex flex-col items-center relative border border-[#434238] animate-in zoom-in-95 duration-300"
      >
        {/* Top Header */}
        <div className="w-full flex items-center justify-between mb-4">
          <span className="text-[10px] uppercase font-bold tracking-widest text-[#E8B96A] bg-[#3B382D]/80 px-2.5 py-1 rounded-full border border-[#544F3F]">
            Audio Namunaviy qism
          </span>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-[#D8D4C8] hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Center Cover */}
        <div className="w-36 h-48 rounded-2xl overflow-hidden shadow-2xl relative my-2 border border-white/15">
          <div
            className="w-full h-full flex flex-col justify-between p-3 relative"
            style={{
              background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
                ? book.cover
                : `url(${book.cover}) center/cover no-repeat`,
            }}
          >
            <div className="my-auto text-center px-1">
              <p className={`font-serif-book text-xs font-bold ${book.light ? 'text-[#2D2B26]' : 'text-white'}`}>
                {book.title}
              </p>
              <p className={`text-[9px] mt-1 opacity-80 ${book.light ? 'text-[#4A473F]' : 'text-[#FAF8F5]'}`}>
                {book.author}
              </p>
            </div>
          </div>
        </div>

        {/* Title and Speaker */}
        <div className="text-center mt-3 w-full">
          <h3 className="font-serif-book text-base font-bold text-white truncate">
            {book.title}
          </h3>
          <p className="text-xs text-[#B5B0A2] mt-0.5">{book.author}</p>
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#E8B96A] mt-2">
            <Volume2 className="w-3.5 h-3.5 text-[#E8B96A]" />
            <span>Suxandon: professional diktor ovozi</span>
          </div>
        </div>

        {/* Audio Visualizer Waves (Simulation) */}
        <div className="flex items-center justify-center gap-1 my-5 h-8 w-full">
          {[40, 70, 95, 60, 85, 45, 90, 75, 30, 65, 80, 50, 100, 60, 40, 75, 90, 55].map((height, i) => (
            <div
              key={i}
              className={`w-1 rounded-full bg-gradient-to-t from-[#8C5D19] to-[#E8B96A] transition-all duration-300 ${
                isPlaying ? 'animate-pulse' : 'opacity-40'
              }`}
              style={{
                height: isPlaying ? `${Math.max(15, (height * ((i % 3) + 1)) % 100)}%` : '20%',
                animationDelay: `${i * 70}ms`,
              }}
            />
          ))}
        </div>

        {/* Time Slider */}
        <div className="w-full space-y-1">
          <input
            type="range"
            min="0"
            max={duration}
            value={currentTime}
            onChange={(e) => setCurrentTime(Number(e.target.value))}
            className="w-full h-1.5 bg-[#434238] rounded-lg appearance-none cursor-pointer accent-[#D49A3D]"
          />
          <div className="flex justify-between text-[11px] font-mono text-[#A8A395]">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center justify-between w-full mt-4 px-2">
          {/* Speed Toggle */}
          <button
            onClick={handleSpeedToggle}
            className="text-xs font-bold px-2 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-[#FAF8F5] transition-colors cursor-pointer"
            title="Tezlikni o'zgartirish"
          >
            {speed}x
          </button>

          {/* 15s Back */}
          <button
            onClick={() => setCurrentTime(Math.max(0, currentTime - 15))}
            className="p-2 text-[#D8D4C8] hover:text-white transition-colors cursor-pointer"
            title="15 soniya orqaga"
          >
            <RotateCcw className="w-5 h-5" />
          </button>

          {/* Big Play/Pause button */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-14 h-14 rounded-full bg-[#5A5A40] hover:bg-[#6D6D4E] text-white flex items-center justify-center shadow-lg shadow-[#5A5A40]/40 transition-transform active:scale-90 cursor-pointer border border-[#787856]"
          >
            {isPlaying ? <Pause className="w-6 h-6 fill-white" /> : <Play className="w-6 h-6 fill-white ml-0.5" />}
          </button>

          {/* 15s Forward */}
          <button
            onClick={() => setCurrentTime(Math.min(duration, currentTime + 15))}
            className="p-2 text-[#D8D4C8] hover:text-white transition-colors cursor-pointer"
            title="15 soniya oldinga"
          >
            <RotateCw className="w-5 h-5" />
          </button>

          {/* Placeholder for balance */}
          <div className="w-7 text-right">
            <Sparkles className="w-4 h-4 text-[#E8B96A] opacity-90 ml-auto" />
          </div>
        </div>
      </div>
    </div>
  );
};
