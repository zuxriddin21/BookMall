import React from 'react';
import { Bookmark, Eye, Star } from 'lucide-react';
import { Book } from '../types';

interface CatalogBookCardProps {
  book: Book;
  onSelect: (book: Book) => void;
  isSaved?: boolean;
  onToggleSave?: (book: Book, e: React.MouseEvent) => void;
}

export const CatalogBookCard: React.FC<CatalogBookCardProps> = ({
  book,
  onSelect,
  isSaved = false,
  onToggleSave,
}) => {
  return (
    <div
      id={`catalog-book-${book.id}`}
      onClick={() => onSelect(book)}
      className="flex-shrink-0 w-36 sm:w-40 flex flex-col cursor-pointer group select-none"
    >
      {/* Book Cover */}
      <div className="relative w-full aspect-[3/4.4] rounded-xl overflow-hidden shadow-xs group-hover:shadow-lg transition-all duration-300 transform group-hover:-translate-y-1 bg-[#EFECE3]">
        <div
          className="w-full h-full flex flex-col justify-between p-3 relative"
          style={{
            background: book.cover.startsWith('linear-gradient') || book.cover.startsWith('#')
              ? book.cover
              : `url(${book.cover}) center/cover no-repeat`,
          }}
        >
          {/* Subtle Book Spine Effect */}
          <div className="absolute top-0 left-0 bottom-0 w-2.5 bg-gradient-to-r from-black/25 via-white/10 to-transparent pointer-events-none" />

          {/* Top Badge & Save */}
          <div className="flex items-start justify-between z-10">
            <span className="text-[9px] font-medium px-1.5 py-0.5 rounded-md bg-black/40 text-white backdrop-blur-xs">
              {book.reads || 120} o'qildi
            </span>

            {onToggleSave && (
              <button
                id={`cat-bookmark-${book.id}`}
                onClick={(e) => onToggleSave(book, e)}
                className={`p-1.5 rounded-full backdrop-blur-md transition-colors ${
                  isSaved
                    ? 'bg-[#D49A3D] text-white'
                    : 'bg-black/30 text-white/80 hover:bg-black/50'
                }`}
              >
                <Bookmark className="w-3 h-3" fill={isSaved ? 'currentColor' : 'none'} />
              </button>
            )}
          </div>

          {/* Title on cover */}
          <div className="my-auto text-center px-1 z-10">
            <p
              className={`font-serif-book text-xs font-bold line-clamp-3 leading-snug ${
                book.light ? 'text-[#2D2B26]' : 'text-white'
              }`}
            >
              {book.title}
            </p>
            <p
              className={`text-[9px] mt-1 line-clamp-1 opacity-80 ${
                book.light ? 'text-[#4A473D]' : 'text-[#FAF6EE]'
              }`}
            >
              {book.author}
            </p>
          </div>

          {/* Status bottom */}
          <div className="flex items-center justify-between z-10 text-[9px]">
            <span
              className={`font-semibold px-1.5 py-0.5 rounded-md ${
                book.available ? 'bg-[#3F6146]/95 text-white' : 'bg-[#B34734]/95 text-white'
              }`}
            >
              {book.available ? 'Mavjud' : 'Band'}
            </span>

            <div className="flex items-center gap-0.5 text-[#F5CA7B] font-bold bg-black/40 px-1 py-0.5 rounded-md">
              <Star className="w-2.5 h-2.5 fill-[#D49A3D] text-[#D49A3D]" />
              <span>{book.rating || '4.8'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Info below cover */}
      <div className="mt-2 flex flex-col">
        <h4 className="text-xs font-semibold text-[#3D3B35] line-clamp-1 group-hover:text-[#5A5A40] transition-colors">
          {book.title}
        </h4>
        <p className="text-[11px] text-[#757268] line-clamp-1 mt-0.5">
          {book.author}
        </p>
        <span className="text-[10px] text-[#5A5A40] font-medium line-clamp-1 mt-0.5">
          {book.genre || 'Kutubxona fondi'}
        </span>
      </div>
    </div>
  );
};
