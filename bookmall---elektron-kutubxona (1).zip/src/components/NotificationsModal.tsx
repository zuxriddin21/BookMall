import React from 'react';
import { X, Bell, CheckCheck, Clock, BookOpen, Heart, Landmark, Info } from 'lucide-react';
import { NotificationItem } from '../types';

interface NotificationsModalProps {
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onClearAll: () => void;
  onClose: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  notifications,
  onMarkAllRead,
  onClearAll,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        id="notifications-modal"
        className="bg-[#FAF8F5] text-[#3D3B35] w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in slide-in-from-bottom duration-300 border border-[#E6E1D6]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#EAE5DA] bg-[#F2EFE8]/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#ECEAE1] text-[#5A5A40] flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#3D3B35]">Bildirishnomalar</h3>
              <p className="text-[11px] text-[#757268]">Muddati va yangiliklar</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#8F8B7F] hover:text-[#2D2B26] hover:bg-[#EAE5DA] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Row */}
        {notifications.length > 0 && (
          <div className="flex items-center justify-between px-5 py-2.5 bg-[#F2EFE8] border-b border-[#EAE5DA] text-xs">
            <button
              onClick={onMarkAllRead}
              className="text-[#5A5A40] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>O'qilgan deb belgilash</span>
            </button>
            <button
              onClick={onClearAll}
              className="text-[#8F8B7F] hover:text-[#AD4D39] transition-colors cursor-pointer"
            >
              Tozalash
            </button>
          </div>
        )}

        {/* Notification List */}
        <div className="p-4 space-y-2.5 overflow-y-auto max-h-[60vh] custom-scrollbar">
          {notifications.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center">
              <Bell className="w-10 h-10 text-[#8F8B7F]/60 mb-2" />
              <p className="text-xs text-[#757268]">Yangi bildirishnomalar mavjud emas</p>
            </div>
          ) : (
            notifications.map((n) => {
              const getIcon = () => {
                switch (n.type) {
                  case 'borrow':
                    return <Clock className="w-4 h-4 text-[#D49A3D]" />;
                  case 'donation':
                    return <Heart className="w-4 h-4 text-[#AD4D39]" />;
                  case 'library':
                    return <Landmark className="w-4 h-4 text-[#5A5A40]" />;
                  default:
                    return <Info className="w-4 h-4 text-[#5A5850]" />;
                }
              };

              return (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    !n.read
                      ? 'bg-[#F2EFE8] border-[#D9D3C5] shadow-xs'
                      : 'bg-[#FAF8F5] border-[#E6E1D6]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-xl bg-[#FAF8F5] shadow-xs border border-[#E6E1D6] flex items-center justify-center flex-shrink-0 mt-0.5">
                      {getIcon()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-[#3D3B35]">{n.title}</h4>
                        <span className="text-[10px] text-[#8F8B7F]">{n.time}</span>
                      </div>
                      <p className="text-xs text-[#615E54] mt-1 leading-relaxed">{n.message}</p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
