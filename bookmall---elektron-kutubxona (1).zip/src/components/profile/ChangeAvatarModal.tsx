import React, { useState, useRef } from 'react';
import { X, Check, Camera, Upload, Link, AlertCircle } from 'lucide-react';
import { api } from '../../services/api';

interface ChangeAvatarModalProps {
  currentAvatar?: string;
  onClose: () => void;
  onSuccess: (newAvatar: string) => void;
}

const PRESET_AVATARS = [
  {
    id: 'a1',
    label: 'Kitobxon yigit',
    url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'a2',
    label: 'Zukko talaba',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'a3',
    label: 'Kitobxon qiz',
    url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'a4',
    label: 'Yosh tadqiqotchi',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'a5',
    label: 'Estetik mutolaa',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'a6',
    label: 'Mumtoz adib',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'a7',
    label: 'Ziyo tarqatuvchi',
    url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=300&auto=format&fit=crop&q=80',
  },
  {
    id: 'a8',
    label: 'Tahlilchi kitobxon',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80',
  },
];

export const ChangeAvatarModal: React.FC<ChangeAvatarModalProps> = ({
  currentAvatar,
  onClose,
  onSuccess,
}) => {
  const [selectedAvatar, setSelectedAvatar] = useState(
    currentAvatar || PRESET_AVATARS[0].url
  );
  const [customUrl, setCustomUrl] = useState('');
  const [activeTab, setActiveTab] = useState<'presets' | 'upload' | 'url'>('presets');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError("Iltimos, rasm formatidagi fayl tanlang (JPG, PNG)");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError("Rasm hajmi 5MB dan oshmasligi kerak");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setSelectedAvatar(event.target.result);
        setError(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleApplyUrl = () => {
    if (!customUrl.trim()) return;
    setSelectedAvatar(customUrl.trim());
    setError(null);
  };

  const handleSubmit = async () => {
    if (!selectedAvatar) return;
    setIsSubmitting(true);
    setError(null);

    try {
      await api.profile.update({ avatar: selectedAvatar });
      onSuccess(selectedAvatar);
      onClose();
    } catch (err: any) {
      setError(err.message || "Rasmni saqlashda xatolik");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div
        className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-[#E6E1D6] flex items-center justify-between bg-[#F5EFE6]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#2C5338]/10 flex items-center justify-center text-[#2C5338]">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#2D2B26]">Profil rasmini tanlash</h3>
              <p className="text-xs text-[#757268]">O'zingizga yoqqan rasmni tanlang yoki yuklang</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#757268] hover:bg-black/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-2 text-red-700 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Current Avatar Preview */}
          <div className="flex flex-col items-center justify-center">
            <div className="relative group">
              <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-[#2C5338] via-[#8C5D19] to-[#E6E1D6] shadow-lg">
                <img
                  src={selectedAvatar}
                  alt="Avatar preview"
                  className="w-full h-full object-cover rounded-full bg-white"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-1 right-1 bg-[#2C5338] text-white p-1.5 rounded-full shadow-md">
                <Camera className="w-3.5 h-3.5" />
              </div>
            </div>
            <span className="text-[11px] text-[#757268] mt-2 font-medium">Yangi rasm ko'rinishi</span>
          </div>

          {/* Tabs */}
          <div className="flex p-1 bg-[#EFEBE3] rounded-xl text-xs font-semibold text-[#5A574F]">
            <button
              type="button"
              onClick={() => setActiveTab('presets')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${
                activeTab === 'presets' ? 'bg-white text-[#2C5338] shadow-xs' : 'hover:text-[#2D2B26]'
              }`}
            >
              Tayyor rasmlar
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${
                activeTab === 'upload' ? 'bg-white text-[#2C5338] shadow-xs' : 'hover:text-[#2D2B26]'
              }`}
            >
              Fayl yuklash
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('url')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${
                activeTab === 'url' ? 'bg-white text-[#2C5338] shadow-xs' : 'hover:text-[#2D2B26]'
              }`}
            >
              Havola (URL)
            </button>
          </div>

          {/* Tab 1: Presets */}
          {activeTab === 'presets' && (
            <div className="grid grid-cols-4 gap-3 max-h-52 overflow-y-auto pr-1">
              {PRESET_AVATARS.map((preset) => {
                const isSelected = selectedAvatar === preset.url;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setSelectedAvatar(preset.url)}
                    className={`relative rounded-2xl overflow-hidden p-1 transition-all group ${
                      isSelected
                        ? 'ring-3 ring-[#2C5338] scale-105 shadow-md bg-white'
                        : 'border border-[#E6E1D6] hover:border-[#2C5338]/50 bg-white/70'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.label}
                      className="w-full aspect-square object-cover rounded-xl"
                      referrerPolicy="no-referrer"
                    />
                    {isSelected && (
                      <div className="absolute inset-0 bg-[#2C5338]/30 flex items-center justify-center rounded-xl">
                        <Check className="w-5 h-5 text-white" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Tab 2: Upload */}
          {activeTab === 'upload' && (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="p-6 border-2 border-dashed border-[#DDD7CD] hover:border-[#2C5338] rounded-2xl bg-white text-center cursor-pointer transition-colors"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div className="w-10 h-10 rounded-full bg-[#2C5338]/10 text-[#2C5338] flex items-center justify-center mx-auto mb-2">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-xs font-bold text-[#2D2B26]">Qurilmadan rasm tanlang</p>
              <p className="text-[11px] text-[#757268] mt-0.5">JPG, PNG yoki WEBP (maks. 5MB)</p>
            </div>
          )}

          {/* Tab 3: URL */}
          {activeTab === 'url' && (
            <div className="space-y-2">
              <label className="block text-xs font-bold text-[#4A473F] flex items-center gap-1.5">
                <Link className="w-3.5 h-3.5 text-[#2C5338]" />
                Rasm veb-manzili (URL)
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  placeholder="https://example.com/avatar.jpg"
                  className="flex-1 px-3.5 py-2 bg-white border border-[#DDD7CD] focus:border-[#2C5338] rounded-xl text-xs text-[#2D2B26] outline-hidden"
                />
                <button
                  type="button"
                  onClick={handleApplyUrl}
                  className="px-3 py-2 bg-[#FAF2E3] text-[#8C5D19] border border-[#E8DFC8] rounded-xl text-xs font-bold hover:bg-[#F5EAD4] transition-colors"
                >
                  Ko'rish
                </button>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-3 flex items-center justify-end gap-2.5 border-t border-[#E6E1D6]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-[#5A574F] hover:bg-black/5 rounded-xl transition-colors"
            >
              Bekor qilish
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="px-5 py-2 bg-[#2C5338] hover:bg-[#23422C] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? "Saqlanmoqda..." : "Rasmni o'rnatish"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
