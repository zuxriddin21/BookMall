import React, { useState, useMemo } from 'react';
import {
  X,
  Search,
  BookCheck,
  Star,
  Pin,
  PinOff,
  Sparkles,
  Crown,
  Calendar,
  Landmark,
  Plus,
  Filter,
  CheckCircle2,
  ExternalLink,
  BookOpen,
  Award
} from 'lucide-react';
import { ProfileReadBookItem, Book } from '../../types';

interface ReadBooksListModalProps {
  isOpen: boolean;
  onClose: () => void;
  books: ProfileReadBookItem[];
  totalBooksCount: number;
  isPremiumUser: boolean;
  onTogglePin: (item: ProfileReadBookItem) => Promise<void>;
  pinningBookId: string | null;
  onSelectBook?: (book: Book) => void;
  onOpenAddBook?: () => void;
  onSwitchPlan?: () => void;
}

export const ReadBooksListModal: React.FC<ReadBooksListModalProps> = ({
  isOpen,
  onClose,
  books,
  totalBooksCount,
  isPremiumUser,
  onTogglePin,
  pinningBookId,
  onSelectBook,
  onOpenAddBook,
  onSwitchPlan,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<string>('all');

  if (!isOpen) return null;

  // Filter books based on search query and category/pinned filter
  const filteredBooks = useMemo(() => {
    return books.filter((item) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.author.toLowerCase().includes(q) ||
        (item.genre && item.genre.toLowerCase().includes(q)) ||
        (item.notes && item.notes.toLowerCase().includes(q));

      if (!matchesSearch) return false;

      if (selectedFilter === 'all') return true;
      if (selectedFilter === 'pinned') return !!item.isPinned;
      if (selectedFilter === 'fiction') {
        return item.genre.toLowerCase().includes('badiiy') || item.genre.toLowerCase().includes('roman');
      }
      if (selectedFilter === 'psychology') {
        return item.genre.toLowerCase().includes('psixologiya') || item.genre.toLowerCase().includes('rivojlanish');
      }
      if (selectedFilter === 'business') {
        return item.genre.toLowerCase().includes('moliya') || item.genre.toLowerCase().includes('biznes');
      }
      if (selectedFilter === 'detective') {
        return item.genre.toLowerCase().includes('detektiv') || item.genre.toLowerCase().includes('fentezi');
      }

      return true;
    });
  }, [books, searchQuery, selectedFilter]);

  const pinnedBooks = books.filter((b) => b.isPinned);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        id="read-books-long-modal"
        className="bg-[#FAF8F5] text-[#2D2B26] w-full h-full sm:h-[92vh] sm:max-w-2xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-[#E6E1D6] animate-in slide-in-from-bottom duration-300"
      >
        {/* Header with Title and Stats */}
        <div className="p-4 sm:p-5 border-b border-[#EAE5DA] bg-[#F4F1EA] flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#2C5338] text-white flex items-center justify-center shadow-md shadow-emerald-950/15 flex-shrink-0">
              <BookCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-bold text-[#2D2B26]">
                  O'qilgan kitoblar ro'yxati
                </h2>
                <span className="text-[11px] font-extrabold bg-[#2C5338]/10 text-[#2C5338] px-2.5 py-0.5 rounded-full border border-[#2C5338]/20">
                  {totalBooksCount || books.length} ta kitob
                </span>
              </div>
              <p className="text-[11px] text-[#757268] flex items-center gap-1.5 mt-0.5">
                <span>📌 1-, 2-, 3-o'rinlarda saralangan kitoblar qadalgan</span>
                <span className="text-[#C89234] font-bold">({pinnedBooks.length} ta qadalgan)</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenAddBook && (
              <button
                onClick={onOpenAddBook}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-[#2C5338] hover:bg-[#23422C] text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                title="Yangi o'qilgan kitob qo'shish"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Kitob qo'shish</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-2 rounded-full text-[#757268] hover:text-[#2D2B26] hover:bg-[#EAE5DA] transition-colors cursor-pointer"
              title="Yopish"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Pinned Info Banner & Quick Switcher */}
        <div className="px-4 py-2.5 bg-gradient-to-r from-[#FAF3E6] via-[#FFF9EE] to-[#FAF3E6] border-b border-[#EAD6B3] flex items-center justify-between text-xs text-[#8C5D19] flex-wrap gap-2 flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-sm">📌</span>
            <span className="font-semibold text-[11.5px]">
              Eng sara asarlaringiz ro'yxatning eng yuqorisida (1, 2, 3) doimiy qadaladi
            </span>
          </div>

          <div className="flex items-center gap-2">
            {isPremiumUser ? (
              <span className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#FAF0DC] border border-[#E5C687] text-[#8C5D19] text-[10.5px] font-black">
                <Crown className="w-3 h-3 text-[#B87D1B]" />
                <span>Premium Faol</span>
              </span>
            ) : onSwitchPlan ? (
              <button
                onClick={onSwitchPlan}
                className="text-[10.5px] font-bold text-[#8C5D19] underline hover:text-[#A07024] cursor-pointer"
              >
                ⭐ Premiumga o'tish
              </button>
            ) : null}
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-3.5 sm:p-4 border-b border-[#EAE5DA] bg-[#FAF8F5] space-y-2.5 flex-shrink-0">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-[#8F8B7F] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="read-books-modal-search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Kitob nomi, muallif yoki xotiralar bo'yicha qidiruv..."
              className="w-full pl-10 pr-9 py-2.5 text-xs bg-[#F2EFE8] border border-[#E2DDD3] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#2C5338] text-[#2D2B26] placeholder-[#9B978C] shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8F8B7F] hover:text-[#2D2B26] cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Filter Chips */}
          <div className="flex gap-1.5 overflow-x-auto scrollbar-hide pb-0.5">
            {[
              { id: 'all', label: `Barchasi (${books.length})` },
              { id: 'pinned', label: `📌 Qadalganlar (${pinnedBooks.length})` },
              { id: 'fiction', label: 'Badiiy adabiyot' },
              { id: 'psychology', label: 'Psixologiya' },
              { id: 'business', label: 'Biznes va Moliya' },
              { id: 'detective', label: 'Detektiv' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id)}
                className={`text-[11px] font-bold px-3 py-1 rounded-full whitespace-nowrap transition-all cursor-pointer ${
                  selectedFilter === f.id
                    ? 'bg-[#2C5338] text-white shadow-2xs'
                    : 'bg-[#EFECE3] text-[#5A5850] hover:bg-[#E4E0D6]'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* The Long Continuous Scrollable Books List ("Bitta uzun oyna") */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 bg-[#FAF8F5]">
          {filteredBooks.length === 0 ? (
            <div className="py-16 text-center space-y-3 bg-[#FAF8F5] rounded-3xl border border-[#E6E1D6] p-6">
              <div className="w-12 h-12 bg-[#FAF2E3] rounded-2xl flex items-center justify-center mx-auto text-[#D49A3D]">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-[#2D2B26]">Kitoblar topilmadi</h3>
              <p className="text-xs text-[#757268] max-w-xs mx-auto">
                Qidiruv so'rovi bo'yicha hech qanday o'qilgan kitob topilmadi. So'rovni o'zgartirib ko'ring.
              </p>
            </div>
          ) : (
            filteredBooks.map((item, index) => {
              const isPinned = item.isPinned;
              const displayOrder = isPinned ? (item.pinnedOrder || index + 1) : index + 1;

              return (
                <div
                  key={item.id}
                  onClick={() => {
                    if (onSelectBook) {
                      onSelectBook({
                        id: item.bookId,
                        title: item.title,
                        author: item.author,
                        cover: item.coverImage,
                        rating: item.rating,
                        available: true,
                        genre: item.genre,
                        description: item.description,
                      });
                    }
                  }}
                  className={`rounded-2xl p-3.5 sm:p-4 flex flex-col gap-2.5 transition-all group cursor-pointer border ${
                    isPinned
                      ? 'bg-gradient-to-r from-[#FFFBF2] via-[#FFFDF8] to-[#FAF6EE] border-[#DFB86C] ring-2 ring-[#E5C384]/25 shadow-sm'
                      : 'bg-white border-[#E6E1D6] hover:border-[#2C5338]/40 shadow-2xs hover:shadow-xs'
                  }`}
                >
                  {/* Top Bar for Pinned Books (1-, 2-, 3-o'rin) */}
                  {isPinned ? (
                    <div className="flex items-center justify-between pb-2 border-b border-[#EAD5AB]/60">
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-[#F5E4BE] to-[#EED4A2] text-[#7A4E11] border border-[#DFC07D] text-xs font-black shadow-2xs">
                          <span className="text-sm">📌</span>
                          <span>{displayOrder}-o'rinda qadalgan</span>
                        </div>
                        <span className="text-[10.5px] text-[#8C5D19] font-bold bg-[#FAF1DF] px-2 py-0.5 rounded-lg border border-[#E8DFC8]">
                          Tavsiya etilgan asar
                        </span>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onTogglePin(item);
                        }}
                        disabled={pinningBookId === item.bookId}
                        className="text-[11px] font-bold text-[#8C5D19] hover:text-red-700 hover:bg-red-50 px-2.5 py-1 rounded-xl border border-[#E2C78A] hover:border-red-200 transition-colors flex items-center gap-1 bg-white shadow-2xs cursor-pointer"
                        title="Qadalganlikni bekor qilish"
                      >
                        <PinOff className="w-3 h-3 text-[#A07024]" />
                        <span>Qadalganlikni bekor qilish</span>
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between pb-1">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-[#EFECE3] text-[#5A5850] text-[11px] font-bold flex items-center justify-center">
                          {displayOrder}
                        </span>
                        <span className="text-[11px] text-[#757268] font-medium">
                          O'qib tugatilgan
                        </span>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onTogglePin(item);
                        }}
                        disabled={pinningBookId === item.bookId}
                        className="text-[10.5px] font-bold text-[#5A574F] hover:text-[#8C5D19] hover:bg-[#FAF1DF] px-2.5 py-1 rounded-xl border border-[#DDD7CD] hover:border-[#E5C687] transition-all flex items-center gap-1 bg-white shadow-2xs cursor-pointer"
                        title="Profilingiz yuqorisiga qadash (1, 2 yoki 3-o'rin)"
                      >
                        <Pin className="w-3 h-3 text-[#A07024]" />
                        <span>Qadash</span>
                      </button>
                    </div>
                  )}

                  {/* Book Details Row */}
                  <div className="flex items-start gap-3.5">
                    {/* Book Cover */}
                    <div className="relative flex-shrink-0">
                      <img
                        src={item.coverImage}
                        alt={item.title}
                        className={`w-14 h-20 sm:w-16 sm:h-22 rounded-xl object-cover shadow-xs group-hover:scale-103 transition-transform ${
                          isPinned ? 'ring-2 ring-[#E5C687]' : ''
                        }`}
                        referrerPolicy="no-referrer"
                      />
                      {isPinned && (
                        <div className="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-[#FAF0DC] border border-[#E5C687] text-[#8C5D19] flex items-center justify-center text-[10px] font-black shadow-2xs">
                          📌
                        </div>
                      )}
                    </div>

                    {/* Book Text & Info */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4
                            className={`text-xs sm:text-sm font-bold leading-snug line-clamp-1 ${
                              isPinned
                                ? 'text-[#362712] group-hover:text-[#B87D1B]'
                                : 'text-[#2D2B26] group-hover:text-[#2C5338]'
                            } transition-colors`}
                          >
                            {item.title}
                          </h4>
                          <p className="text-[11.5px] text-[#757268] font-medium">{item.author}</p>
                        </div>

                        {/* Rating */}
                        <div className="flex items-center text-[#D49A3D] text-xs font-black bg-[#FAF2E3] px-2 py-0.5 rounded-lg border border-[#E8DFC8] flex-shrink-0">
                          <Star className="w-3.5 h-3.5 fill-[#D49A3D] text-[#D49A3D] mr-1" />
                          <span>{item.rating}.0</span>
                        </div>
                      </div>

                      {/* Meta Tags: Genre, Library, Read Date */}
                      <div className="flex items-center gap-1.5 text-[10px] text-[#757268] flex-wrap pt-0.5">
                        <span className="px-2 py-0.5 rounded-md font-semibold bg-[#EFECE3] text-[#4A473D] border border-[#E0DBD0]">
                          {item.genre}
                        </span>

                        {item.libraryName && (
                          <span className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#FAF8F5] text-[#757268] border border-[#E6E1D6]">
                            <Landmark className="w-2.5 h-2.5 text-[#5A5850]" />
                            <span className="truncate max-w-[120px]">{item.libraryName}</span>
                          </span>
                        )}

                        <span className="flex items-center gap-1 text-[#8F8B7F]">
                          <Calendar className="w-2.5 h-2.5" />
                          <span>
                            {item.readAt
                              ? new Date(item.readAt).toLocaleDateString('uz-UZ', {
                                  day: 'numeric',
                                  month: 'short',
                                  year: 'numeric',
                                })
                              : 'Mutolaa qilingan'}
                          </span>
                        </span>
                      </div>

                      {/* Personal Notes / Quote */}
                      {item.notes && (
                        <div
                          className={`mt-2 p-2 rounded-xl text-[11px] italic leading-relaxed border ${
                            isPinned
                              ? 'bg-[#FAF3E6]/70 border-[#EAD6B3] text-[#6A4815]'
                              : 'bg-[#F7F5F0] border-[#E8E2D6] text-[#55524A]'
                          }`}
                        >
                          "{item.notes}"
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer with summary and close button */}
        <div className="p-3 sm:p-4 border-t border-[#EAE5DA] bg-[#F2EFE8] flex items-center justify-between flex-shrink-0">
          <div className="text-xs text-[#757268]">
            Jami: <b className="text-[#2D2B26]">{filteredBooks.length}</b> ta kitob ko'rsatilmoqda
            {pinnedBooks.length > 0 && (
              <span className="ml-1 text-[#8C5D19] font-bold">
                (📌 {pinnedBooks.length} ta kitob qadalgan)
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#2C5338] hover:bg-[#23422C] text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Tushunarli
          </button>
        </div>
      </div>
    </div>
  );
};
