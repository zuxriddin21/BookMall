import React, { useState, useEffect } from 'react';
import { X, Check, Star, BookOpen, Search, AlertCircle } from 'lucide-react';
import { Book } from '../../types';
import { api } from '../../services/api';

interface MarkReadBookModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export const MarkReadBookModal: React.FC<MarkReadBookModalProps> = ({ onClose, onSuccess }) => {
  const [books, setBooks] = useState<Book[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBookId, setSelectedBookId] = useState('');
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    api.books
      .getAll()
      .then((items) => {
        if (!isMounted) return;
        const mapped: Book[] = items.map((b) => ({
          id: b.id,
          title: b.title,
          author: b.author,
          cover: b.coverImage,
          rating: 4.9,
          available: b.availableCopies > 0,
          genre: b.genre,
          description: b.description,
        }));
        setBooks(mapped);
        if (mapped.length > 0) setSelectedBookId(mapped[0].id);
      })
      .catch(() => {})
      .finally(() => {
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const filteredBooks = books.filter(
    (b) =>
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.author.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedBook = books.find((b) => b.id === selectedBookId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBookId) {
      setError("Iltimos, kitobni tanlang");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await api.profile.markRead(selectedBookId, rating, notes.trim());
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || "Kitobni belgilashda xatolik yuz berdi");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div
        className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-[#E6E1D6] flex items-center justify-between bg-[#F5EFE6]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#2C5338]/10 flex items-center justify-center text-[#2C5338]">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#2D2B26]">Kitobni o'qilgan deb belgilash</h3>
              <p className="text-xs text-[#757268]">O'qib tugatgan kitobingiz va unga bergan bahoyingiz</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#757268] hover:bg-black/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-2 text-red-700 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Book Search and Select */}
          <div>
            <label className="block text-xs font-bold text-[#4A473F] mb-1.5">
              Kitobni qidiring va tanlang
            </label>
            <div className="relative mb-2">
              <Search className="w-4 h-4 text-[#8F8B7F] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Kitob nomi yoki muallifi..."
                className="w-full pl-9 pr-3.5 py-2 bg-white border border-[#DDD7CD] focus:border-[#2C5338] rounded-xl text-xs text-[#2D2B26] outline-hidden"
              />
            </div>

            {isLoading ? (
              <div className="py-6 text-center text-xs text-[#8F8B7F]">Kitoblar yuklanmoqda...</div>
            ) : (
              <div className="max-h-40 overflow-y-auto space-y-1.5 p-1 border border-[#E6E1D6] rounded-2xl bg-white">
                {filteredBooks.length === 0 ? (
                  <p className="p-3 text-center text-xs text-[#8F8B7F]">Kitob topilmadi</p>
                ) : (
                  filteredBooks.map((b) => {
                    const isSelected = selectedBookId === b.id;
                    return (
                      <div
                        key={b.id}
                        onClick={() => setSelectedBookId(b.id)}
                        className={`flex items-center gap-2.5 p-2 rounded-xl cursor-pointer transition-colors ${
                          isSelected ? 'bg-[#FAF2E3] border border-[#D49A3D]/50' : 'hover:bg-[#FAF8F5]'
                        }`}
                      >
                        <img
                          src={b.cover}
                          alt={b.title}
                          className="w-9 h-12 object-cover rounded-md shadow-2xs flex-shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-[#2D2B26] truncate">{b.title}</p>
                          <p className="text-[11px] text-[#757268] truncate">{b.author}</p>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-[#2C5338]" />}
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </div>

          {/* Rating */}
          <div>
            <label className="block text-xs font-bold text-[#4A473F] mb-1.5">
              Kitobga bergan bahoyingiz: {rating} / 5
            </label>
            <div className="flex items-center gap-2 p-2.5 bg-white border border-[#DDD7CD] rounded-2xl">
              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="p-1 text-[#D49A3D] transition-transform hover:scale-110"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        (hoverRating || rating) >= star
                          ? 'fill-[#D49A3D] text-[#D49A3D]'
                          : 'text-[#DDD7CD]'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <span className="text-xs font-semibold text-[#8C5D19] ml-2">
                {rating === 5
                  ? "A'lo darajada!"
                  : rating === 4
                  ? 'Juda yaxshi'
                  : rating === 3
                  ? 'Yaxshi'
                  : 'O‘rtacha'}
              </span>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-[#4A473F] mb-1.5">
              Taqriz yoki xulosa (ixtiyoriy)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Ushbu kitob haqida taassurotlaringiz..."
              className="w-full px-3.5 py-2 bg-white border border-[#DDD7CD] focus:border-[#2C5338] rounded-xl text-xs text-[#2D2B26] outline-hidden resize-none"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5 border-t border-[#E6E1D6]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-[#5A574F] hover:bg-black/5 rounded-xl transition-colors"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !selectedBookId}
              className="px-5 py-2 bg-[#2C5338] hover:bg-[#23422C] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? "Saqlanmoqda..." : "O'qilgan deb saqlash"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
