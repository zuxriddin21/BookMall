import React, { useState } from 'react';
import { X, Check, AtSign, User as UserIcon, AlignLeft, Phone, Sparkles, AlertCircle } from 'lucide-react';
import { User } from '../../types';
import { api } from '../../services/api';

interface EditProfileModalProps {
  user: User;
  onClose: () => void;
  onSuccess: (updatedUser: User) => void;
}

const BIO_SUGGESTIONS = [
  "Kitoblar tahlili va mutolaa zavqi 📖",
  "Mutolaa — qalb va tafakkur ozuqasi 🌿",
  "Haftasiga kamida bitta kitob tahlili ✨",
  "Jahon adabiyoti durdonalarini kashf etamiz 📚",
  "Har bir sahifada yangi olam va falsafa 🧠",
];

export const EditProfileModal: React.FC<EditProfileModalProps> = ({ user, onClose, onSuccess }) => {
  const [name, setName] = useState(user.name || '');
  const [username, setUsername] = useState(user.username || '');
  const [bio, setBio] = useState(user.bio || '');
  const [phone, setPhone] = useState(user.phone || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Ism Familiya bo'sh bo'lishi mumkin emas");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const cleanUsername = username.replace(/^@/, '').trim();
      const res = await api.profile.update({
        name: name.trim(),
        username: cleanUsername,
        bio: bio.trim(),
        phone: phone.trim(),
      });

      onSuccess(res.user);
      onClose();
    } catch (err: any) {
      setError(err.message || "Profilni saqlashda xatolik yuz berdi");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div
        className="bg-[#FAF8F5] border border-[#E6E1D6] rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-[#E6E1D6] flex items-center justify-between bg-[#F5EFE6]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#2C5338]/10 flex items-center justify-center text-[#2C5338]">
              <UserIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#2D2B26]">Profilni tahrirlash</h3>
              <p className="text-xs text-[#757268]">Shaxsiy ma'lumotlar va bio statusini yangilang</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#757268] hover:bg-black/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-2 text-red-700 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Name */}
          <div>
            <label className="block text-xs font-bold text-[#4A473F] mb-1.5 flex items-center gap-1.5">
              <UserIcon className="w-3.5 h-3.5 text-[#2C5338]" />
              Ism va Familiya
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masalan: Muhammadqodir Zuxriddinov"
              required
              className="w-full px-3.5 py-2.5 bg-white border border-[#DDD7CD] focus:border-[#2C5338] focus:ring-2 focus:ring-[#2C5338]/20 rounded-xl text-sm text-[#2D2B26] outline-hidden transition-all"
            />
          </div>

          {/* Username */}
          <div>
            <label className="block text-xs font-bold text-[#4A473F] mb-1.5 flex items-center gap-1.5">
              <AtSign className="w-3.5 h-3.5 text-[#2C5338]" />
              Foydalanuvchi nomi (@username)
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8F8B7F] font-mono text-sm">@</span>
              <input
                type="text"
                value={username.replace(/^@/, '')}
                onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                placeholder="qodir_books"
                className="w-full pl-8 pr-3.5 py-2.5 bg-white border border-[#DDD7CD] focus:border-[#2C5338] focus:ring-2 focus:ring-[#2C5338]/20 rounded-xl text-sm font-mono text-[#2D2B26] outline-hidden transition-all"
              />
            </div>
            <p className="text-[11px] text-[#8F8B7F] mt-1">Lotin harflari, raqamlar va pastki chiziq</p>
          </div>

          {/* Bio */}
          <div>
            <label className="block text-xs font-bold text-[#4A473F] mb-1.5 flex items-center gap-1.5">
              <AlignLeft className="w-3.5 h-3.5 text-[#2C5338]" />
              Bio / Shaxsiy status
            </label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={3}
              placeholder="Kitobxonlik qiziqishlaringiz, sevimli janrlaringiz haqida yozing..."
              className="w-full px-3.5 py-2.5 bg-white border border-[#DDD7CD] focus:border-[#2C5338] focus:ring-2 focus:ring-[#2C5338]/20 rounded-xl text-sm text-[#2D2B26] outline-hidden transition-all resize-none"
            />

            {/* Quick bio suggestions */}
            <div className="mt-2">
              <span className="text-[10px] font-bold text-[#757268] uppercase tracking-wider flex items-center gap-1 mb-1.5">
                <Sparkles className="w-3 h-3 text-[#D49A3D]" />
                Tavsiya etilgan statuslar:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {BIO_SUGGESTIONS.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setBio(item)}
                    className="text-[11px] bg-white border border-[#E6E1D6] hover:border-[#2C5338] hover:text-[#2C5338] text-[#5A574F] px-2.5 py-1 rounded-lg transition-colors text-left"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Phone */}
          <div>
            <label className="block text-xs font-bold text-[#4A473F] mb-1.5 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-[#2C5338]" />
              Telefon raqam
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+998 90 123-45-67"
              className="w-full px-3.5 py-2.5 bg-white border border-[#DDD7CD] focus:border-[#2C5338] focus:ring-2 focus:ring-[#2C5338]/20 rounded-xl text-sm text-[#2D2B26] outline-hidden transition-all"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5 border-t border-[#E6E1D6]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-[#5A574F] hover:bg-black/5 rounded-xl transition-colors"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-[#2C5338] hover:bg-[#23422C] text-white rounded-xl text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? "Saqlanmoqda..." : "Saqlash"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
