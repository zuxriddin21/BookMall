import { Server as HttpServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { RealtimeEventType, RealtimeEventPayloads, RealtimeEvent } from '../src/types';

interface ConnectedClient {
  id: string;
  ws: WebSocket;
  isAlive: boolean;
  libraryId?: string;
  userId?: string;
  connectedAt: Date;
}

class RealtimeHub {
  private wss: WebSocketServer | null = null;
  private clients: Map<string, ConnectedClient> = new Map();
  private heartbeatInterval: NodeJS.Timeout | null = null;

  init(server: HttpServer): WebSocketServer {
    this.wss = new WebSocketServer({
      server,
      path: '/ws',
    });

    this.wss.on('connection', (ws: WebSocket, req) => {
      const clientId = `client-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const client: ConnectedClient = {
        id: clientId,
        ws,
        isAlive: true,
        connectedAt: new Date(),
      };

      this.clients.set(clientId, client);
      console.log(`[Realtime] Client connected: ${clientId} (Total: ${this.clients.size})`);

      // Send initial CONNECTED confirmation
      this.sendToClient(client, 'CONNECTED', {
        clientId,
        timestamp: new Date().toISOString(),
      });

      // Handle message from client (e.g., client identity registration or ping)
      ws.on('message', (message: string) => {
        try {
          const parsed = JSON.parse(message.toString());
          if (parsed.type === 'IDENTIFY') {
            client.userId = parsed.userId;
            client.libraryId = parsed.libraryId;
          } else if (parsed.type === 'PING') {
            this.sendToClient(client, 'PONG', { timestamp: Date.now() });
          }
        } catch {
          // ignore malformed message
        }
      });

      ws.on('pong', () => {
        client.isAlive = true;
      });

      ws.on('close', () => {
        this.clients.delete(clientId);
        console.log(`[Realtime] Client disconnected: ${clientId} (Remaining: ${this.clients.size})`);
      });

      ws.on('error', (err) => {
        console.error(`[Realtime] Client error ${clientId}:`, err.message);
      });
    });

    // Heartbeat check every 30 seconds
    this.heartbeatInterval = setInterval(() => {
      this.clients.forEach((client, id) => {
        if (!client.isAlive) {
          console.log(`[Realtime] Terminating inactive client: ${id}`);
          client.ws.terminate();
          this.clients.delete(id);
          return;
        }
        client.isAlive = false;
        client.ws.ping();
      });
    }, 30000);

    return this.wss;
  }

  // Send typed message to single client
  private sendToClient<T extends RealtimeEventType>(
    client: ConnectedClient,
    type: T,
    data: RealtimeEventPayloads[T]
  ) {
    if (client.ws.readyState === WebSocket.OPEN) {
      const event: RealtimeEvent<T> = {
        type,
        data,
        timestamp: new Date().toISOString(),
      };
      client.ws.send(JSON.stringify(event));
    }
  }

  // Broadcast to all connected clients
  broadcast<T extends RealtimeEventType>(type: T, data: RealtimeEventPayloads[T]) {
    const event: RealtimeEvent<T> = {
      type,
      data,
      timestamp: new Date().toISOString(),
    };
    const payload = JSON.stringify(event);

    let activeCount = 0;
    this.clients.forEach((client) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(payload);
        activeCount++;
      }
    });

    console.log(`[Realtime Broadcast] Event "${type}" sent to ${activeCount} active clients`);
  }

  // Broadcast specifically to clients belonging to a specific library or general
  broadcastToLibrary<T extends RealtimeEventType>(
    libraryId: string,
    type: T,
    data: RealtimeEventPayloads[T]
  ) {
    // For seamless UX, broadcast globally so users and admins across the system stay in sync
    this.broadcast(type, data);
  }

  getConnectedCount(): number {
    return this.clients.size;
  }

  cleanup() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
  }
}

export const realtimeHub = new RealtimeHub();
