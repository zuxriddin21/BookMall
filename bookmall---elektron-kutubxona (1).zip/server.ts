import express from "express";
import http from "http";
import path from "path";
import { createServer as createViteServer } from "vite";
import { apiRouter, authMiddleware } from "./server/routes";
import { realtimeHub } from "./server/realtime";

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const PORT = 3000;

  // Initialize Real-time WebSocket Hub
  realtimeHub.init(server);

  // JSON & URL-encoded parser
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Global Auth Token Extractor
  app.use(authMiddleware);

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      service: "BookMall Library Management API",
      connectedSockets: realtimeHub.getConnectedCount(),
      timestamp: new Date().toISOString(),
    });
  });

  // Mount API Router
  app.use("/api", apiRouter);

  // Vite middleware for development vs static dist for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== "true",
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`BookMall server running with WebSocket on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start BookMall server:", err);
  process.exit(1);
});
